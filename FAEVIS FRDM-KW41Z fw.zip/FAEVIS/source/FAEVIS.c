/***********************************************************************************************************************
 * @author: JAVIER MONREAL TRIGO
 * @project: FAEVIS
 * @version: 15th February 2020
 **********************************************************************************************************************/

#include "math.h"
#include "RNG_Interface.h"
#include "Keyboard.h"
#include "LED.h"
#include "TimersManager.h"
#include "FunctionLib.h"
#include "Panic.h"
#include "SerialManager.h"
#include "MemManager.h"
#include "board.h"
#include "fsl_dac.h"
#include "fsl_adc16.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_pit.h"

/* BLE Host Stack */
#include "gatt_interface.h"
#include "gatt_server_interface.h"
#include "gatt_client_interface.h"
#include "gatt_database.h"
#include "gap_interface.h"
#include "gatt_db_app_interface.h"
#include "gatt_db_handles.h"

/* Profile / Services */
#include <bluetooth/profiles/hermes/hermes_interface.h>
#include <FAEVIS.h>
#include "ble_conn_manager.h"
#include "ble_service_discovery.h"

#include "board.h"
#include "ApplMain.h"
#include "UserFunctions.h"

/************************************************************************************
 *************************************************************************************
 * Private macros
 *************************************************************************************
 ************************************************************************************/

#define mAppUartBufferSize_c   			gAttMaxWriteDataSize_d(gAttMaxMtu_c) /* Local Buffer Size */

#define mAppUartFlushIntervalInMs_c   	(1) 	/* Flush Timeout in ms */

#define mHermesMessageSendInterval_c    (1)//10	/* Poll interval in ms */

#define mZoisISRInterval_c    			(100)	/* Discrete time of the Zois loop in ms */

#define mSetRelayIntervalInMs_c 		(50)	/* Time for setting relay in ms */

#define SERIAL_ON 						0


#define MSG_POS_HEAD 	0
#define MSG_POS_CMD 	1
#define MSG_POS_NSEQ 	2
#define MSG_POS_CHKSUM 	18
#define MSG_POS_END 	19

#define MSG_HEAD 			0xAA
#define MSG_END		 		0xFF
#define MSG_ERROR			0xEE

#define AreYouAlive					 		0x11
#define SetDACValue							0xDD
#define PotentiometryAutocalibration		0xA1
#define CECMAutocalibrationLarge			0xA2
#define CECMAutocalibrationLargeSend		0xB2
#define CECMAutocalibrationPrecision		0xA3
#define SetPotentiometryConfiguration 		0xC1
#define SetVoltammetryConfiguration 		0xC2
#define SetWaveform 						0x58
#define StopTransmission 			  		0x77
#define StartExperience 			  		0x55
#define StopExperience						0xBB
#define StartSendPotentotiometryData  		0x1D
#define StartSendCurrentVoltammetryData  	0x2D
#define StartSendCEVoltageVoltammetryData  	0x3D
#define PotentiometryDataTransfer  		    0x17
#define CurrentVoltammetryDataTransfer  	0x27
#define CEVoltageVoltammetryDataTransfer  	0x37
#define PotentiometryDataTransferEnd  		0x1E
#define CurrentVoltammetryDataTransferEnd  	0x2E
#define CEVoltageVoltammetryDataTransferEnd	0x3E
#define ErrorCommand						0xEE
#define RestartMeasurementCommand			0x8D


#define DACValue8LOW_POS 2
#define DACValue4HIGH_POS 3

#define SetPotentiometryConfiguration_MSG_POS_EXPERIENCE		2
#define SetPotentiometryConfiguration_MSG_POS_TOUT_H			3
#define SetPotentiometryConfiguration_MSG_POS_TOUT_L			4
#define SetPotentiometryConfiguration_MSG_POS_SAMPLERATE_H		5
#define SetPotentiometryConfiguration_MSG_POS_SAMPLERATE_L		6
#define SetPotentiometryConfiguration_MSG_POS_VARV				7
#define SetPotentiometryConfiguration_MSG_POS_AVG_N				8

#define SetVMConfiguration_MSG_POS_EXPERIENCE		2
#define SetVMConfiguration_MSG_POS_OCP				3
#define SetVMConfiguration_MSG_POS_I_SCALE			4
#define SetVMConfiguration_MSG_POS_NCYCLES1			5
#define SetVMConfiguration_MSG_POS_NCYCLES2			6
#define SetVMConfiguration_MSG_POS_SAMPLE1			7
#define SetVMConfiguration_MSG_POS_SAMPLE2			8
#define SetVMConfiguration_MSG_POS_SAMPLE3			9
#define SetVMConfiguration_MSG_POS_SAMPLE4			10
#define SetVMConfiguration_MSG_POS_WFSIZE1			11
#define SetVMConfiguration_MSG_POS_WFSIZE2			12

#define DissolutionPotentiometryExperience				0xDD
#define SubstratumPotentiometryExperience				0x55
#define DissolutionTwoElectrodesVoltammetryExperience	0x21
#define DissolutionThreeElectrodesVoltammetryExperience	0x31
#define SubstratumTwoElectrodesVoltammetryExperience	0x22
#define SubstratumThreeElectrodesVoltammetryExperience	0x32
#define GradientExperience								0x66
#define CurrentInjectionExperience						0x11

#define CurrentScale1	0x11
#define CurrentScale2	0x22

#define SUCCESS 		1
#define FAILURE			0

#define PIT_IRQ_ID PIT_IRQn
/* Get source clock for PIT driver */
#define PIT_SOURCE_CLOCK CLOCK_GetFreq(kCLOCK_BusClk)

#define limitPotSampleTime_us 10000

/************************************************************************************
 *************************************************************************************
 * Private type definitions
 *************************************************************************************
 ************************************************************************************/

typedef enum appEvent_tag{
    mAppEvt_PeerConnected_c,
    mAppEvt_PairingComplete_c,
    mAppEvt_ServiceDiscoveryComplete_c,
    mAppEvt_ServiceDiscoveryFailed_c,
    mAppEvt_GattProcComplete_c,
    mAppEvt_GattProcError_c
}appEvent_t;

typedef enum appState_tag
{
    mAppIdle_c, 
    mAppExchangeMtu_c,	
    mAppServiceDisc_c,
    mAppRunning_c
} appState_t;

typedef struct appPeerInfo_tag
{
    deviceId_t  deviceId;
    bool_t      isBonded;
    hmcConfig_t clientInfo;
    appState_t  appState;
} appPeerInfo_t;

typedef struct advState_tag
{
    bool_t advOn;
} advState_t;

typedef enum SystemState_tag {
    ss_Idle,
	ss_Gradient,
	ss_2eDissolutionVoltammetry,
	ss_2eSubstratumVoltammetry,
	ss_DissolutionPotentiometry,
	ss_SubstratumPotentiometry,
	ss_3eDissolutionVoltammetry,
	ss_3eSubstratumVoltammetry,
	ss_CurrentInjection,
	ss_PotentiometryCalibration
} SystemState_t;

/************************************************************************************
 *************************************************************************************
 * Private memory declarations
 *************************************************************************************
 ************************************************************************************/

static appPeerInfo_t mPeerInformation;
static gapRole_t mGapRole;

#if gAppUseBonding_d
static bool_t mRestoringBondedLink = FALSE;
#endif

/* Adv Parmeters */
static advState_t mAdvState;
static bool_t   mScanningOn = FALSE;

/* Configure writtable attributes that require a callback action */
uint16_t notifiableHandleArray[] = {value_hermes_message};
uint8_t  notifiableHandleCount = sizeof(notifiableHandleArray)/2;

static uint16_t mCharMonitoredHandles[1] = {value_hermes_message};

/* Service Data*/
static hmsConfig_t mHmsServiceConfig = {service_hermes, 0};

static tmrTimerID_t mAppTimerId;
static tmrTimerID_t mUartStreamFlushTimerId;
static tmrTimerID_t mHermesMessagingTimerId;
static tmrTimerID_t mZoisTimerId;
static tmrTimerID_t mSetRelayTimerId;

static uint8_t gAppSerMgrIf;
static uint16_t mAppUartBufferSize = mAppUartBufferSize_c;

/* DAC */
static dac_config_t dacConfigStruct;
volatile uint32_t dacValue;
uint16_t analogValue = 0;

/* ADC */
static adc16_config_t adc16ConfigStruct_CM;
static adc16_config_t adc16ConfigStruct_CE;
static adc16_config_t adc16ConfigStruct_WE;
static adc16_channel_config_t adc16ChannelConfigStruct_CM;
static adc16_channel_config_t adc16ChannelConfigStruct_CE;
static adc16_channel_config_t adc16ChannelConfigStruct_WE;
uint8_t averagingMeasurement = 10;
uint32_t VMTempValue = 0;
uint32_t potTempValue = 0;

/* Structure of initialize PIT */
pit_config_t pitConfig;

/* Hermes */
uint8_t inputHermesMessage[20];  //Received Hermes Message
bool_t newInputMessage = FALSE;	 //New Hermes Message received flag
uint8_t outputHermesMessage[20]; //To Send Hermes Message
bool_t newOutputMessage = FALSE; //New Hermes Message to send flag

uint8_t inputNseq = 0;
uint8_t outputNseqPOT = 0;
uint8_t outputNseqCM = 0;
uint8_t outputNseqCE = 0;
uint8_t inputNseqPOT = 0;
uint8_t inputNseqCM = 0;
uint8_t inputNseqCE = 0;

uint8_t pointsSentCM = 0;
uint8_t pointsSentCE = 0;
uint8_t pointsSentPOT = 0;

uint8_t BYTES[15];

bool_t StopTriggered = FALSE;
bool_t StopNewMessages = FALSE;

bool_t restartMeasurementFlag = FALSE;

/* Calibration */
uint16_t analogValues[9] = {256,768,1280,1792,2048,2304,2816,3328,3840};
uint16_t potentiometryCalibration[9];
uint16_t CMLargeCalibration[9];
uint16_t CMPrecisionCalibration[9];
uint16_t CECalibration[9];
uint8_t ptr_CECMCalibration = 0;
uint8_t ptr_potentiometryCalibration = 0;
uint8_t ptr_CECMTransmission = 0;
bool_t PotentiometryAutocalibration_flag = FALSE;
bool_t CECMAutocalibrationLarge_flag = FALSE;
bool_t CECMAutocalibrationPrecision_flag = FALSE;

/* Waveform */
uint16_t DATA[10];

bool_t WaveformSet = FALSE;

uint32_t ptr_analogWaveform = 0;
uint16_t analogWaveform[1000];
bool_t voltammetryEnded = FALSE;

uint32_t ptr_potentiometryWaveform = 0;
uint16_t potentiometryWaveform[1000];
bool_t potentiometryEnded = FALSE;

uint32_t ptr_currentWaveform = 0;
uint16_t currentWaveform[10000];
uint32_t ptr_countervoltageWaveform = 0;
uint16_t countervoltageWaveform[10000];
uint64_t ptr_cycles = 0;

bool_t sendPotentiometryData = FALSE;
bool_t sendCurrentData = FALSE;
bool_t sendCounterVoltageData = FALSE;
uint32_t ptr_sendPotentiometryWaveform = 0;
uint32_t sendPotentiometryWaveformLoops = 0;
uint32_t potentiometryWaveformLoops = 0;
uint32_t ptr_sendCurrentWaveform = 0;
uint32_t ptr_sendCountervoltageWaveform = 0;

uint32_t MeasuredOCP = 0;

/* Configuration */
bool_t ConfigurationSet = FALSE;

uint8_t Experience = 0;
uint16_t TotalTime = 0;
uint32_t VMSampleTime = 0;
uint16_t WaveformNumberOfPoints = 0;
uint64_t WaveformCycles = 0;
uint8_t CurrentScale = 0;

uint32_t PotentiometryTimeout = 0;
uint16_t PotentiometryTimeBetweenSamples = 0;
uint16_t PotentiometryMaximumVoltageVariation = 0;
uint16_t PotentiometryAveragingSamples = 0;
uint16_t CompensateOCP = 0;
bool_t PotentiometryExperience = FALSE;

bool_t PotentiometryTimeoutON = FALSE;
bool_t PotentiometryAverageON = FALSE;

double period_us = 0;
uint8_t cnt_units = 100; //us

uint16_t PotentiometryTimeout_s = 0;
uint16_t ptr_PotentiometryTimeout_s = 0;
uint32_t cnt_PotentiometryTimeout_toSec = 0;
uint32_t maxCnt_PotentiometryTimeout_toSec = 0;
double potentiometryVariationAverage[2] = {0,0};
double PotentiometryVoltageVariation = 0;

bool_t EXPERIMENT_ON = FALSE;
bool_t EXPERIMENT_ENDED = FALSE;
bool_t CALIBRATION_ON = FALSE;
bool_t calibrationEnded = FALSE;

bool_t PotentiometryOn = FALSE;
bool_t VoltammetryOn = FALSE;

bool_t timeoutReached = FALSE;

bool_t ExperienceStarted = FALSE;

bool_t relaySetterAvailable = TRUE;

uint8_t IdleState[10] = 						{DOWN, DOWN, UP  , UP  ,
											 	 UP  , UP  , DOWN, DOWN,
												 DOWN, DOWN};

uint8_t GradientState[10] = 					{UP  , UP  , UP  , DOWN,
											 	 UP  , UP  , UP  , UP  ,
												 DOWN, DOWN};

uint8_t PotentiometryDissolutionState[10] = 	{DOWN, DOWN, DOWN, UP  ,
											 	 DOWN, DOWN, DOWN, DOWN,
												 DOWN, DOWN};

uint8_t PotentiometrySubstratumState[10] = 		{UP  , DOWN, UP  , UP  ,
											 	 DOWN, DOWN, DOWN, DOWN,
												 DOWN, DOWN};

uint8_t Voltammetry3DissolutionState[10] = 		{DOWN, DOWN, DOWN, DOWN,
											 	 UP  , DOWN, DOWN, DOWN,
												 DOWN, DOWN};

uint8_t Voltammetry3SubstratumState[10] =    	{UP  , DOWN, UP  , DOWN,
											 	 UP  , DOWN, DOWN, DOWN,
												 DOWN, DOWN};

uint8_t Voltammetry2DissolutionState[10] =   	{DOWN, DOWN, DOWN, DOWN,
											 	 UP  , DOWN, UP  , DOWN,
												 DOWN, DOWN};

uint8_t Voltammetry2SubstratumState[10] =    	{UP  , DOWN, UP  , DOWN,
											 	 UP  , DOWN, UP  , DOWN,
												 DOWN, DOWN};


uint8_t CurrentInjectionState[10] =				{UP  , UP  , UP  , UP  ,
												 UP  , UP  , UP  , UP  ,
												 UP  , UP  };

uint8_t allUpState[10] = 						{UP  , UP  , UP  , UP  ,
												 UP  , UP  , UP  , UP  ,
												 UP  , UP  };

uint8_t allDownState[10] = 						{DOWN, DOWN, DOWN, DOWN,
												 DOWN, DOWN, DOWN, DOWN,
												 DOWN, DOWN};

uint8_t potentiometryCalibrationState[10] =      	{UP  , UP  , UP  , UP  ,
											 	 DOWN, DOWN, DOWN, UP  ,
												 DOWN, DOWN};

bool_t alternate = TRUE;

uint8_t ptrRelay = 0;
SystemState_t SystemState;
bool_t settingRelaysFlag = FALSE;

bool_t PIT_StartedFlag = FALSE;

uint8_t forMax = 0;

/************************************************************************************
 *************************************************************************************
 * Private functions prototypes
 *************************************************************************************
 ************************************************************************************/

/* Gatt and Att callbacks */
static void BleApp_AdvertisingCallback(gapAdvertisingEvent_t* pAdvertisingEvent);
static void BleApp_ScanningCallback (gapScanningEvent_t* pScanningEvent);
static void BleApp_ConnectionCallback
(
    deviceId_t peerDeviceId,
    gapConnectionEvent_t* pConnectionEvent
);
static void BleApp_GattServerCallback 
(
   deviceId_t deviceId,
   gattServerEvent_t* pServerEvent
);

static void BleApp_SendAttWriteResponse
(
	deviceId_t* pDeviceId,
	gattServerEvent_t* pGattServerEvent,
	bleResult_t* pResult
);

static void BleApp_GattClientCallback 
(
    deviceId_t              serverDeviceId,
    gattProcedureType_t     procedureType,
    gattProcedureResult_t   procedureResult,
    bleResult_t             error
);

static void BleApp_ServiceDiscoveryCallback
(
    deviceId_t deviceId,
    servDiscEvent_t* pEvent
);

static void BleApp_Config (void);
static void BleApp_Advertise (void);

void BleApp_StateMachineHandler
(
    deviceId_t peerDeviceId,
    uint8_t event
);

static void BleApp_StoreServiceHandles
(
    deviceId_t 	     peerDeviceId,
    gattService_t   *pService
);
static bool_t BleApp_CheckScanEvent (gapScannedDevice_t* pData);

/* Timer Callbacks */
static void ScaningTimerCallback (void *);
static void UartStreamFlushTimerCallback(void *);
static void HermesMessagingTimerCallback (void *);
static void ZoisTimerCallback (void *);
static void setRelayTimerCallback (void *);

/* Uart Tx/Rx Callbacks*/
static void Uart_RxCallBack(void *pData);
static void Uart_TxCallBack(void *pBuffer);

static void BleApp_FlushUartStream(void *pParam);

/* Hardware Init Functions */
void Init_Hw (void);
void configDAC (dac_config_t dacConfigStruct);
void configADC (int ADC_SE, adc16_config_t* adc16ConfigStruct, adc16_channel_config_t* adc16ChannelConfigStruct);

/* Hermes */
void inputMessageTreatment (uint8_t* inputMessage);
uint8_t hermesMessageCalcChecksum (uint8_t* hermesMessage);
void sendHermesError (uint8_t Command, uint8_t additionalInfo);
void sendHermesAck (uint8_t Command, uint8_t Nseq);
void setOutputHermesMessage (uint8_t* message);

void obtainDataPointsFromBytes (uint8_t* inputMessage);
void sendPotentiometryPoints (void);
void sendCurrentVoltammetryPoints (void);
void sendCEVoltageVoltammetryPoints (void);
void sendPotentiometryCalibrationAnswer (void);
void sendCECMCalibrationAnswerLarge (void);
void sendCECMCalibrationAnswerPrecision (void);

void arrcpy (uint8_t* destination, uint8_t* origin, uint8_t len);

/* FAEVIS */
bool_t setRelay(uint8_t relay, uint8_t state);
bool_t setRelayConfiguration (uint8_t* relayConfiguration);

bool_t FAEVIS_FSM (void);

void configPIT (uint32_t period);

/************************************************************************************
*************************************************************************************
* Public functions
*************************************************************************************
************************************************************************************/

/*! *********************************************************************************
* \brief    Initializes application specific functionality before the BLE stack init.
*
********************************************************************************** */

void BleApp_Init(void)
{
	// Init clocks, DAC, ADC & GPIO
	Init_Hw();

#if !CURRENT_SCALE_SELECTOR
#if SERIAL_ON
    // UI
    SerialManager_Init();

    // Register Serial Manager interface
    Serial_InitInterface(&gAppSerMgrIf, APP_SERIAL_INTERFACE_TYPE, APP_SERIAL_INTERFACE_INSTANCE);

    Serial_SetBaudRate(gAppSerMgrIf, gUARTBaudRate115200_c);

    // Install Controller Events Callback handler
    Serial_SetRxCallBack(gAppSerMgrIf, Uart_RxCallBack, NULL);
#endif
#endif
    /* Start Relay Setter Timer */
	mSetRelayTimerId = TMR_AllocateTimer();

	/* Set relays to IDLE config */
	for(uint8_t i = 1; i<9; i++)
	{
		setRelay(i, IdleState[i-1]);
		while(!relaySetterAvailable);
	}

    /* Start ZOIS Timer */
    mZoisTimerId = TMR_AllocateTimer();
    TMR_StartLowPowerTimer(mZoisTimerId,
                		   gTmrLowPowerIntervalMillisTimer_c,
						   mZoisISRInterval_c,
    					   ZoisTimerCallback, NULL);
}

/*! *********************************************************************************
 * \brief    Starts the BLE application.
 *
 * \param[in]    mGapRole    GAP Start Role (Central or Peripheral).
 ********************************************************************************** */

void BleApp_Start (gapRole_t mGapRole)
{
    switch (mGapRole)
    {
        case gGapCentral_c:
        {
            gPairingParameters.localIoCapabilities = gIoKeyboardDisplay_c;
            App_StartScanning(&gScanParams, BleApp_ScanningCallback, TRUE);
            break;
        }
        case gGapPeripheral_c:
        {
            gPairingParameters.localIoCapabilities = gIoDisplayOnly_c;
            BleApp_Advertise();
            break;
        }
        default:
            break;
    }
}


/*! *********************************************************************************
* \brief        Handles BLE generic callback.
*
* \param[in]    pGenericEvent    Pointer to gapGenericEvent_t.
********************************************************************************** */

void BleApp_GenericCallback (gapGenericEvent_t* pGenericEvent)
{
    /* Call BLE Conn Manager */
    BleConnManager_GenericEvent(pGenericEvent);
    
    switch (pGenericEvent->eventType)
    {
        case gInitializationComplete_c:    
        {
            BleApp_Config();
        }
        break;    
        
        case gAdvertisingParametersSetupComplete_c:
        {
            App_StartAdvertising(BleApp_AdvertisingCallback, BleApp_ConnectionCallback);
        }
        break;         

        default: 
            break;
    }
}

/************************************************************************************
*************************************************************************************
* Private functions
*************************************************************************************
************************************************************************************/

/*! *********************************************************************************
* \brief        Configures BLE Stack after initialization. Usually used for
*               configuring advertising, scanning, white list, services, et al.
*
********************************************************************************** */

static void BleApp_Config()
{
    /* Configure as GAP Dual Role */
    BleConnManager_GapDualRoleConfig();
        
    /* Register for callbacks */
    App_RegisterGattServerCallback(BleApp_GattServerCallback);
    App_RegisterGattClientProcedureCallback(BleApp_GattClientCallback);
    GattServer_RegisterHandlesForWriteNotifications(notifiableHandleCount, (uint16_t*)&notifiableHandleArray[0]);
    BleServDisc_RegisterCallback(BleApp_ServiceDiscoveryCallback);
	
    /* By default, always start node as GAP central */
    mAdvState.advOn = FALSE;
    mPeerInformation.appState = mAppIdle_c;
    mScanningOn = FALSE;
    
    mGapRole = gGapCentral_c;

    /* Start services */
    Hms_Start(&mHmsServiceConfig);

    /* Allocate application timer */
    mAppTimerId = TMR_AllocateTimer();
    mUartStreamFlushTimerId = TMR_AllocateTimer();
    mHermesMessagingTimerId = TMR_AllocateTimer();

    BleApp_Start(mGapRole);
}

/*! *********************************************************************************
* \brief        Configures GAP Advertise parameters. Advertise will satrt after
*               the parameters are set.
*
********************************************************************************** */

static void BleApp_Advertise(void)
{
    /* Set advertising parameters*/
    Gap_SetAdvertisingParameters(&gAdvParams);
}

/*! *********************************************************************************
 * \brief        Handles BLE Scanning callback from host stack.
 *
 * \param[in]    pScanningEvent    Pointer to gapScanningEvent_t.
 ********************************************************************************** */

static void BleApp_ScanningCallback (gapScanningEvent_t* pScanningEvent)
{
    switch (pScanningEvent->eventType)
    {
        case gDeviceScanned_c:
        {
            if (BleApp_CheckScanEvent(&pScanningEvent->eventData.scannedDevice))
            {        
                gConnReqParams.peerAddressType = pScanningEvent->eventData.scannedDevice.addressType;
                FLib_MemCpy(gConnReqParams.peerAddress, 
                            pScanningEvent->eventData.scannedDevice.aAddress,
                            sizeof(bleDeviceAddress_t));
                
                Gap_StopScanning();
#if gAppUsePrivacy_d
                gConnReqParams.usePeerIdentityAddress = pScanningEvent->eventData.scannedDevice.advertisingAddressResolved;
#endif
                App_Connect(&gConnReqParams, BleApp_ConnectionCallback);
            }
        }        
        break;
        
        case gScanStateChanged_c:
        {
            mScanningOn = !mScanningOn;
            
            /* Node starts scanning */
            if (mScanningOn)
            { 
                /* Start advertising timer */
                TMR_StartLowPowerTimer(mAppTimerId, 
                           gTmrLowPowerSecondTimer_c,
                           TmrSeconds(gScanningTime_c),
                           ScaningTimerCallback, NULL);  
#if gLEDSupported_d
                Led1Flashing();
#endif
            }
            /* Node is not scanning */
            else
            {                
                TMR_StopTimer(mAppTimerId);
#if gLEDSupported_d
                Led1Flashing();
                Led2Flashing();
                Led3Flashing();
                Led4Flashing();
#endif
            }
        }
        break;
    case gScanCommandFailed_c:
    {
        panic(0, 0, 0, 0);
        break;
    }
    default:
        break;
    }
}

/*! *********************************************************************************
* \brief        Handles BLE Advertising callback from host stack.
*
* \param[in]    pAdvertisingEvent    Pointer to gapAdvertisingEvent_t.
********************************************************************************** */

static void BleApp_AdvertisingCallback (gapAdvertisingEvent_t* pAdvertisingEvent)
{
    switch (pAdvertisingEvent->eventType)
    {
        case gAdvertisingStateChanged_c:
        {
            mAdvState.advOn = !mAdvState.advOn;
#if gLEDSupported_d
            LED_StopFlashingAllLeds();
            Led1Flashing();

            if(!mAdvState.advOn)
            {
                Led2Flashing();
                Led3Flashing();
                Led4Flashing();
            }
#endif
        }
        break;

        case gAdvertisingCommandFailed_c:
        {
            panic(0,0,0,0);
        }
        break;

        default:
            break;
    }
}

/*! *********************************************************************************
* \brief        Handles BLE Connection callback from host stack.
*
* \param[in]    peerDeviceId        Peer device ID.
* \param[in]    pConnectionEvent    Pointer to gapConnectionEvent_t.
********************************************************************************** */

static void BleApp_ConnectionCallback (deviceId_t peerDeviceId, gapConnectionEvent_t* pConnectionEvent)
{
    switch (pConnectionEvent->eventType)
    {
        case gConnEvtConnected_c:
        {
            mPeerInformation.deviceId = peerDeviceId;

            /* Advertising stops when connected */
            mAdvState.advOn = FALSE;

            /* Subscribe client*/
            Hms_Subscribe(peerDeviceId);

            /* UI */
#if gLEDSupported_d
            LED_StopFlashingAllLeds();
            Led1On();
#endif
            /* Stop Advertising Timer*/
            mAdvState.advOn = FALSE;
            TMR_StopTimer(mAppTimerId);
            
            /* Start Hermes Timer */
            TMR_StartLowPowerTimer(mHermesMessagingTimerId,
            			gTmrLowPowerIntervalMillisTimer_c,
						mHermesMessageSendInterval_c,
						HermesMessagingTimerCallback, NULL);

#if gAppUsePairing_d
            
           
#if gAppUseBonding_d            
            Gap_CheckIfBonded(peerDeviceId, &mPeerInformation.isBonded);
            
            if ((mPeerInformation.isBonded) &&
                (gBleSuccess_c == Gap_LoadCustomPeerInformation(peerDeviceId,
                    (void*) &mPeerInformation.clientInfo, 0, sizeof (hmcConfig_t))))
            {
                mRestoringBondedLink = TRUE;
                /* Restored custom connection information. Encrypt link */
                Gap_EncryptLink(peerDeviceId);
            }
            else
#endif /* gAppUseBonding_d*/ 
            {
                if (mGapRole == gGapCentral_c)
                {
//                    Gap_Pair(peerDeviceId, &gPairingParameters);
                }
            }
#endif /* gAppUsePairing_d */            
            BleApp_StateMachineHandler(mPeerInformation.deviceId, mAppEvt_PeerConnected_c);
        }
        break;

        case gConnEvtDisconnected_c:
        {
            mPeerInformation.appState = mAppIdle_c;
            mAppUartBufferSize        = mAppUartBufferSize_c;  
            /* Unsubscribe client */
            Hms_Unsubscribe();
            
            TMR_StopTimer(mHermesMessagingTimerId);

            /* Reset Service Discovery to be sure*/
            BleServDisc_Stop(peerDeviceId);

            /* UI */
#if gLEDSupported_d
            LED_TurnOffAllLeds();
            LED_StartFlash(LED_ALL);
#endif

            BleApp_Start(mGapRole);
        }
        break;

#if gAppUsePairing_d		
        case gConnEvtPairingComplete_c:
        {
            if (pConnectionEvent->eventData.pairingCompleteEvent.pairingSuccessful)
            {
                BleApp_StateMachineHandler(peerDeviceId, mAppEvt_PairingComplete_c);
            }
        }
        break;
#endif /* gAppUsePairing_d */

    default:
        break;
    }
    
    /* Connection Manager to handle Host Stack interactions */
    if (mGapRole == gGapCentral_c)
    {
        BleConnManager_GapCentralEvent(peerDeviceId, pConnectionEvent);
    }
    else if (mGapRole == gGapPeripheral_c)
    {
        BleConnManager_GapPeripheralEvent(peerDeviceId, pConnectionEvent);
    }
}

static void BleApp_ServiceDiscoveryCallback(deviceId_t peerDeviceId, servDiscEvent_t* pEvent)
{
    switch(pEvent->eventType)
    {
        case gServiceDiscovered_c:
        {
            BleApp_StoreServiceHandles(peerDeviceId, pEvent->eventData.pService);
        }
        break;

        case gDiscoveryFinished_c:
        {
            if (pEvent->eventData.success)
            {
                BleApp_StateMachineHandler(peerDeviceId, mAppEvt_ServiceDiscoveryComplete_c);
            }
            else
            {
                BleApp_StateMachineHandler(peerDeviceId, mAppEvt_ServiceDiscoveryFailed_c);
            }
        }
        break;

        default:
        break;
    }
}

/*! *********************************************************************************
* \brief        Handles GATT client callback from host stack.
*
* \param[in]    serverDeviceId      GATT Server device ID.
* \param[in]    procedureType    	Procedure type.
* \param[in]    procedureResult    	Procedure result.
* \param[in]    error    			Callback result.
********************************************************************************** */

static void BleApp_GattClientCallback(
    deviceId_t              serverDeviceId,
    gattProcedureType_t     procedureType,
    gattProcedureResult_t   procedureResult,
    bleResult_t             error
)
{  
    if (procedureResult == gGattProcError_c)
    {    
        BleApp_StateMachineHandler(serverDeviceId, mAppEvt_GattProcError_c);
    }
    else if (procedureResult == gGattProcSuccess_c)
    {        
    	BleApp_StateMachineHandler(serverDeviceId, mAppEvt_GattProcComplete_c);
    }

    /* Signal Service Discovery Module */
    BleServDisc_SignalGattClientEvent(serverDeviceId, procedureType,procedureResult, error);
}

/*! *********************************************************************************
 * \brief        Handles GATT server callback from host stack.
 *
 * \param[in]    deviceId        Client peer device ID.
 * \param[in]    pServerEvent    Pointer to gattServerEvent_t.
 ********************************************************************************** */

static void BleApp_GattServerCallback (
                                       deviceId_t deviceId,
                                       gattServerEvent_t* pServerEvent)
{
    switch (pServerEvent->eventType)
    {
        case gEvtAttributeWrittenWithoutResponse_c:
        {
        	/*
			Attribute write handler: Create a case for your registered attribute and
			execute callback action accordingly
			*/

            if (pServerEvent->eventData.attributeWrittenEvent.handle == value_hermes_message)
            {
            	bleResult_t result = gBleSuccess_c;

            	//Get written value
				memset(mHmsServiceConfig.messageHermes,0,sizeof(mHmsServiceConfig.messageHermes));
				arrcpy(mHmsServiceConfig.messageHermes, pServerEvent->eventData.attributeWrittenEvent.aValue,20);

				//Send response to client
				BleApp_SendAttWriteResponse(&deviceId, pServerEvent, &result);

#if SERIAL_ON
				//Send through UART
				Serial_Write(gAppSerMgrIf, mHmsServiceConfig.messageHermes, 20, 0);
#endif

				//Store messageHermes in inputMessageHermes
				memset(inputHermesMessage,0,sizeof(inputHermesMessage));
				arrcpy(inputHermesMessage, mHmsServiceConfig.messageHermes,20);
				newInputMessage = TRUE;
            }
            break;
        }
        case gEvtMtuChanged_c:
        {
            /* update stream length with new MTU */
            Gatt_GetMtu(deviceId, &mAppUartBufferSize);
            mAppUartBufferSize = gAttMaxWriteDataSize_d(mAppUartBufferSize);
        }
        break;
    default:
        break;
    }
}

/*! *********************************************************************************
 * \brief        Imitates strcpy function but without stopping when finds \0.
 *
 * \param[in]    destination        Pointer to destination uint8_t array.
 * \param[in]    origin    			Pointer to original uint8_t array.
 * \param[in]    len    			Total bytes to be copied.
 ********************************************************************************** */

void arrcpy (uint8_t* destination, uint8_t* origin, uint8_t len)
{
	for(uint8_t i = 0; i < len; i++)
	{
		destination[i] = origin[i];
	}
}

/*! *********************************************************************************
 * \brief        Writes attribute response.
 *
 * \param[in]    deviceId        Client peer device ID.
 * \param[in]    pServerEvent    Pointer to gattServerEvent_t.
 * \param[in]    pResult   		 Pointer to result of the last action.
 ********************************************************************************** */

static void BleApp_SendAttWriteResponse
(
	deviceId_t* pDeviceId,
	gattServerEvent_t* pGattServerEvent,
	bleResult_t* pResult
)
{
  attErrorCode_t attErrorCode;

  // Determine response to send (OK or Error)
  if(*pResult == gBleSuccess_c)
    attErrorCode = gAttErrCodeNoError_c;
  else{
    attErrorCode = (attErrorCode_t)(*pResult & 0x00FF);
  }
  // Send response to client
  GattServer_SendAttributeWrittenStatus(*pDeviceId, pGattServerEvent->eventData.attributeWrittenEvent.handle, attErrorCode);
}

/*! *********************************************************************************
 * \brief        Finds if there is a coincide in a list.
 *
 * \param[out]   bool_t          Found the element?
 * \param[in]    pElement        Pointer to element.
 * \param[in]    pData			 Pointer to Data.
 * \param[in]    iDataLen  		 Length of Data array.
 ********************************************************************************** */

static bool_t MatchDataInAdvElementList (
                                         gapAdStructure_t *pElement,
                                         void *pData,
                                         uint8_t iDataLen)
{
    uint8_t i;

    for (i = 0; i < pElement->length; i += iDataLen)
    {
        if (FLib_MemCmp(pData, &pElement->aData[i], iDataLen))
        {
            return TRUE;
        }
    }
    return FALSE;
}

/*! *********************************************************************************
 * \brief        Checks Scan data for a device to connect.
 *
 * \param[in]    pData    Pointer to gapScannedDevice_t.
 ********************************************************************************** */

static bool_t BleApp_CheckScanEvent (gapScannedDevice_t* pData)
{
    uint8_t index = 0;
    bool_t foundMatch = FALSE;

    while (index < pData->dataLength)
    {
        gapAdStructure_t adElement;

        adElement.length = pData->data[index];
        adElement.adType = (gapAdType_t) pData->data[index + 1];
        adElement.aData = &pData->data[index + 2];

        /* Search for Temperature Custom Service */
        if ((adElement.adType == gAdIncomplete128bitServiceList_c)
            || (adElement.adType == gAdComplete128bitServiceList_c))
        {
            foundMatch = MatchDataInAdvElementList(&adElement,
                &uuid_service_hermes, 16);
        }

        /* Move on to the next AD elemnt type */
        index += adElement.length + sizeof(uint8_t);
    }

    return foundMatch;
}

/*! *********************************************************************************
 * \brief        Stores handles used by the application.
 *
 * \param[in]    pService    Pointer to gattService_t.
 ********************************************************************************** */
static void BleApp_StoreServiceHandles (deviceId_t peerDeviceId, gattService_t *pService)
{
    /* Found Wireless UART Service */
    mPeerInformation.clientInfo.hService = pService->startHandle;

    if (pService->cNumCharacteristics > 0 &&
        pService->aCharacteristics != NULL)
    {
        /* Found Uart Characteristic */
        mPeerInformation.clientInfo.hUartStream =
            pService->aCharacteristics[0].value.handle;
    }
}

/*! *********************************************************************************
 * \brief        Sends message to peer.
 *
 * \param[in]    deviceId        Client peer device ID.
 * \param[in]    Stream    		 Pointer to the message to be sent.
 * \param[in]    streamSize   	 Length of the stream to be sent.
 ********************************************************************************** */

static void BleApp_SendOTAMessage(deviceId_t deviceId, uint8_t *Stream, uint8_t streamSize)
{
    gattCharacteristic_t characteristic;

    characteristic.value.handle = mPeerInformation.clientInfo.hUartStream;

    GattClient_WriteCharacteristicValue(deviceId, &characteristic,
                                        streamSize, Stream, TRUE,
                                        FALSE, FALSE, NULL);
}

/*! *********************************************************************************
 * \brief        BLE State machine.
 *
 * \param[in]    deviceId        Client peer device ID.
 * \param[in]    event			 Event to treat.
 ********************************************************************************** */

void BleApp_StateMachineHandler(deviceId_t peerDeviceId, uint8_t event)
{
    switch (mPeerInformation.appState)
    {
        case mAppIdle_c:
        {
            if (event == mAppEvt_PeerConnected_c)
            {
                /* Let the central device initiate the Exchange MTU procedure*/
                if (mGapRole == gGapCentral_c)
                {
                    /* Moving to Exchange MTU State */
                    mPeerInformation.appState = mAppExchangeMtu_c;
                    GattClient_ExchangeMtu(peerDeviceId);
                }
                else
                {
                    /* Moving to Service Discovery State*/
                    mPeerInformation.appState = mAppServiceDisc_c;

                    /* Start Service Discovery*/
                    BleServDisc_FindService(peerDeviceId, 
                                            gBleUuidType128_c,
                                            (bleUuid_t*) &uuid_service_hermes);
                }
            }
        }
        break;

        case mAppExchangeMtu_c:
        {
            if (event == mAppEvt_GattProcComplete_c)
            {
                /* update stream length with new MTU */
                Gatt_GetMtu(peerDeviceId, &mAppUartBufferSize);
                mAppUartBufferSize = gAttMaxWriteDataSize_d(mAppUartBufferSize);
				
                /* Moving to Service Discovery State*/
                mPeerInformation.appState = mAppServiceDisc_c;

                /* Start Service Discovery*/
                BleServDisc_FindService(peerDeviceId, 
                                        gBleUuidType128_c,
                                        (bleUuid_t*) &uuid_service_hermes);
            }
            else if (event == mAppEvt_GattProcError_c) 
            {
                Gap_Disconnect(peerDeviceId);
            }
        }
        break;

        case mAppServiceDisc_c:
        {
            if (event == mAppEvt_ServiceDiscoveryComplete_c)
            {            	
                /* Moving to Running State*/
                mPeerInformation.appState = mAppRunning_c;
            }
            else if (event == mAppEvt_ServiceDiscoveryFailed_c)
            {
                Gap_Disconnect(peerDeviceId);
            }
        }
        break;

        case mAppRunning_c:
                break;
        default:
                break;
    }
}

/*! *********************************************************************************
 * \brief        Handles scanning timer callback.
 *
 * \param[in]    pParam        Calback parameters.
 ********************************************************************************** */

static void ScaningTimerCallback (void * pParam)
{
    /* Stop scanning and start advertising */
    Gap_StopScanning();
    
    mGapRole = gGapPeripheral_c;
    gPairingParameters.localIoCapabilities = gIoDisplayOnly_c;

    BleApp_Advertise();
}

/*! *********************************************************************************
 * \brief        Flushes UART stream.
 *
 * \param[in]    pParam        Calback parameters.
 ********************************************************************************** */

static void BleApp_FlushUartStream(void *pParam)
{
	uint8_t *pMsg = NULL;
	uint16_t bytesRead = 0;

    if (mPeerInformation.appState != mAppRunning_c)
    {
        return;
    }

    /* Allocate buffer for GATT Write */
    pMsg = MEM_BufferAlloc(mAppUartBufferSize);
    if (pMsg == NULL)
    {
    	return;
    }
#if SERIAL_ON
    /* Collect the data from the serial manager buffer */
    if (Serial_Read(gAppSerMgrIf, pMsg, mAppUartBufferSize, &bytesRead) == gSerial_Success_c)
    {
        if (bytesRead != 0)
        {
            /* Send data over the air */
            BleApp_SendOTAMessage(mPeerInformation.deviceId, pMsg, bytesRead);
        }
    }
#endif
    /* Free Buffer */
    MEM_BufferFree(pMsg);
}

/*! *********************************************************************************
 * \brief        Callback for flushing UART.
 *
 * \param[in]    pData       Calback parameters.
 ********************************************************************************** */

static void UartStreamFlushTimerCallback(void *pData)
{
    App_PostCallbackMessage(BleApp_FlushUartStream, NULL);
}

/*! *********************************************************************************
* \brief        Handles UART Receive callback.
*
* \param[in]    pData        Parameters.
********************************************************************************** */

static void Uart_RxCallBack(void *pData)
{
    uint16_t byteCount;

    Serial_RxBufferByteCount(gAppSerMgrIf, &byteCount);

    if (byteCount < mAppUartBufferSize)
    {
		/* Restart flush timer */
		TMR_StartLowPowerTimer(mUartStreamFlushTimerId,
			gTmrLowPowerSingleShotMillisTimer_c,
			mAppUartFlushIntervalInMs_c,
			UartStreamFlushTimerCallback, NULL);
    }
    else
    {
    	App_PostCallbackMessage(BleApp_FlushUartStream, NULL);
    }
}

/*! *********************************************************************************
* \brief        Handles UART Transmit callback.
*
* \param[in]    pData        Parameters.
********************************************************************************** */

static void Uart_TxCallBack(void *pData)
{
    MEM_BufferFree(pData);
}


/*! *********************************************************************************
* \brief        Handles Hermes messaging timer callback.
*
* \param[in]    pParam        Calback parameters.
********************************************************************************** */

static void HermesMessagingTimerCallback(void * pParam)
{
	if(newInputMessage)
	{
		newInputMessage = FALSE;
		inputMessageTreatment(inputHermesMessage);
	}

	if(newOutputMessage) // There is a message to be sent
	{
		newOutputMessage = FALSE;
		memset(mHmsServiceConfig.messageHermes,0,sizeof(mHmsServiceConfig.messageHermes));
		arrcpy(mHmsServiceConfig.messageHermes, outputHermesMessage,20);
		BleApp_SendOTAMessage(mPeerInformation.deviceId, mHmsServiceConfig.messageHermes, sizeof(mHmsServiceConfig.messageHermes));
	}
}

/*! *********************************************************************************
* \brief        Sets output message to be send by Hermes services.
*
* \param[in]    message        Pointer to the message string.
********************************************************************************** */

void setOutputHermesMessage(uint8_t* message)
{
	if(!StopNewMessages)
	{
		if(StopTriggered) StopNewMessages = TRUE;
		StopTriggered = FALSE;
		memset(outputHermesMessage,0,sizeof(outputHermesMessage));
		arrcpy(outputHermesMessage, message, 20);
		newOutputMessage = TRUE;
	}
	else
	{
		StopNewMessages = FALSE;
	}
}

/*! *********************************************************************************
* \brief        Treats Hermes input messages according to Protocol.
*
* \param[in]    inputMessage        Input message to analyze.
********************************************************************************** */

void inputMessageTreatment(uint8_t* inputMessage)
{
	uint8_t CHKSUM = inputMessage[MSG_POS_CHKSUM];
	uint8_t CMD = inputMessage[MSG_POS_CMD];
	uint8_t receivedNseq = inputMessage[MSG_POS_NSEQ]&0x0F;

	if(hermesMessageCalcChecksum(inputMessage)!=CHKSUM) sendHermesError(MSG_ERROR,0x00);
	else switch(CMD)
	{
		case AreYouAlive:
		{
			sendHermesAck(CMD,0x00);
			break;
		}
		case SetDACValue:
		{
			DAC_SetBufferValue(OUT, 0U, ((inputMessage[DACValue4HIGH_POS]&0xF)<<8) + inputMessage[DACValue8LOW_POS]);
			CALIBRATION_ON = TRUE;
			Experience = DissolutionThreeElectrodesVoltammetryExperience;
			sendHermesAck(CMD,0x00);
			break;
		}
		case PotentiometryAutocalibration:
		{
			PotentiometryAutocalibration_flag = TRUE;
			CECMAutocalibrationLarge_flag = FALSE;
			CECMAutocalibrationPrecision_flag = FALSE;
			CALIBRATION_ON = TRUE;
			Experience = DissolutionPotentiometryExperience;
			break;
		}
		case CECMAutocalibrationLarge:
		{
			PotentiometryAutocalibration_flag = FALSE;
			CECMAutocalibrationLarge_flag = TRUE;
			CECMAutocalibrationPrecision_flag = FALSE;
			CALIBRATION_ON = TRUE;
			Experience = DissolutionThreeElectrodesVoltammetryExperience;
			break;
		}
		case CECMAutocalibrationPrecision:
		{
			PotentiometryAutocalibration_flag = FALSE;
			CECMAutocalibrationLarge_flag = FALSE;
			CECMAutocalibrationPrecision_flag = TRUE;
			CALIBRATION_ON = TRUE;
			Experience = DissolutionThreeElectrodesVoltammetryExperience;
			break;
		}
		case CECMAutocalibrationLargeSend:
		{
			sendCECMCalibrationAnswerLarge();
			break;
		}
		case SetPotentiometryConfiguration:
		{
			StopNewMessages = FALSE;

			Experience = inputMessage[SetPotentiometryConfiguration_MSG_POS_EXPERIENCE];
			PotentiometryTimeout = ((inputMessage[SetPotentiometryConfiguration_MSG_POS_TOUT_H]<<8)
					+inputMessage[SetPotentiometryConfiguration_MSG_POS_TOUT_L])*250;
			PotentiometryTimeBetweenSamples = (inputMessage[SetPotentiometryConfiguration_MSG_POS_SAMPLERATE_H]<<8)
							+inputMessage[SetPotentiometryConfiguration_MSG_POS_SAMPLERATE_L];
			PotentiometryMaximumVoltageVariation = (uint16_t)((double)(inputMessage[SetPotentiometryConfiguration_MSG_POS_VARV])*4095.0/3000.0);
			PotentiometryAveragingSamples = inputMessage[SetPotentiometryConfiguration_MSG_POS_AVG_N];

			PotentiometryTimeoutON = TRUE;
			PotentiometryAverageON = TRUE;
			if(PotentiometryTimeout==0) PotentiometryTimeoutON = FALSE;
			if(PotentiometryAveragingSamples==0 && PotentiometryMaximumVoltageVariation==0) PotentiometryAverageON = FALSE;

			bool_t coherenceFlag = TRUE;

			if(Experience!=SubstratumPotentiometryExperience			   &&
			   Experience!=DissolutionPotentiometryExperience) coherenceFlag = FALSE;

			CALIBRATION_ON = FALSE;
			PotentiometryExperience = TRUE;
			if(PotentiometryTimeBetweenSamples>PotentiometryTimeout && PotentiometryTimeout>0) coherenceFlag = FALSE;

			if(!coherenceFlag)
			{
				ConfigurationSet = FALSE;
				sendHermesError(CMD,0x00);
			}
			else
			{
				ConfigurationSet = TRUE;
				sendHermesAck(CMD,0x00);
			}

			break;
		}
		case SetVoltammetryConfiguration:
		{
			StopNewMessages = FALSE;
			PotentiometryExperience = FALSE;

			Experience = inputMessage[SetVMConfiguration_MSG_POS_EXPERIENCE];
			CompensateOCP = inputMessage[SetVMConfiguration_MSG_POS_OCP];
			CurrentScale = inputMessage[SetVMConfiguration_MSG_POS_I_SCALE];
			uint64_t nOfCycles = (((inputMessage[SetVMConfiguration_MSG_POS_NCYCLES2]%4)<<8)
										+inputMessage[SetVMConfiguration_MSG_POS_NCYCLES1]);
			uint64_t multipliernOfCycles = (inputMessage[SetVMConfiguration_MSG_POS_NCYCLES2]>>2);
			WaveformCycles = nOfCycles*pow(10,multipliernOfCycles);
			VMSampleTime = (inputMessage[SetVMConfiguration_MSG_POS_SAMPLE4]<<24)
						   +(inputMessage[SetVMConfiguration_MSG_POS_SAMPLE3]<<16)
						   +(inputMessage[SetVMConfiguration_MSG_POS_SAMPLE2]<<8)
						   +inputMessage[SetVMConfiguration_MSG_POS_SAMPLE1];
			WaveformNumberOfPoints = (inputMessage[SetVMConfiguration_MSG_POS_WFSIZE2]<<8)
					+inputMessage[SetVMConfiguration_MSG_POS_WFSIZE1];

			bool_t coherenceFlag = TRUE;

			if(Experience!=DissolutionTwoElectrodesVoltammetryExperience   &&
			   Experience!=DissolutionThreeElectrodesVoltammetryExperience &&
			   Experience!=SubstratumTwoElectrodesVoltammetryExperience    &&
			   Experience!=SubstratumThreeElectrodesVoltammetryExperience  &&
			   Experience!=CurrentInjectionExperience  					   &&
			   Experience!=GradientExperience) coherenceFlag = FALSE;
			if(WaveformNumberOfPoints==0 || WaveformNumberOfPoints>1000) coherenceFlag = FALSE;
			if(CurrentScale!=CurrentScale1 && CurrentScale!=CurrentScale2) coherenceFlag = FALSE;
			if(CompensateOCP!='1'&&CompensateOCP!='0') coherenceFlag = FALSE;
			if(WaveformCycles == 0) /* || (WaveformCycles>10 && (double)(VMSampleTime)/1000<=40)) */ coherenceFlag = FALSE;
			if(VMSampleTime<5) coherenceFlag = FALSE;

			if(!coherenceFlag)
			{
				ConfigurationSet = FALSE;
				sendHermesError(CMD,0x00);
			}
			else
			{
				CALIBRATION_ON = FALSE;
				ConfigurationSet = TRUE;
				sendHermesAck(CMD,0x00);

				//WaveformSet = FALSE;
				ptr_analogWaveform = 0;
				inputNseq = 0;
			}

			break;
		}

		case SetWaveform:
		{
			if(!ConfigurationSet) sendHermesError(CMD,SetVoltammetryConfiguration);
			else
			{
				uint8_t receivedPoints = (inputMessage[MSG_POS_NSEQ]&0xF0)>>4;
				if(receivedNseq!=inputNseq)
					sendHermesError(CMD,inputNseq); // go-back-N
				else if(!(ptr_analogWaveform<WaveformNumberOfPoints))
					sendHermesError(CMD,StopTransmission); // All data points established were saved
				else
				{
					uint8_t forMax = 0; // Set number of points to save
					if(WaveformNumberOfPoints-ptr_analogWaveform>10) forMax = receivedPoints;
					else forMax = WaveformNumberOfPoints-ptr_analogWaveform;

					if(ptr_analogWaveform == 0) memset(analogWaveform, 0, sizeof analogWaveform);

					obtainDataPointsFromBytes(inputMessage);
					for(uint8_t i = 0; i < forMax; i++)	analogWaveform[ptr_analogWaveform++] = DATA[i];

					inputNseq = (inputNseq>=15)?0:inputNseq+1;

					sendHermesAck(CMD,inputNseq + (forMax<<4));
				}
			}

			if(ptr_analogWaveform==WaveformNumberOfPoints)
			{
				WaveformSet = TRUE;
				inputNseq = 0;
			}

			break;
		}
		case StopTransmission:
		{
			sendPotentiometryData = FALSE;
			sendCurrentData = FALSE;
			sendCounterVoltageData = FALSE;
			ptr_sendPotentiometryWaveform = 0;
			sendPotentiometryWaveformLoops = 0;
			potentiometryWaveformLoops = 0;
			ptr_sendCurrentWaveform = 0;
			ptr_sendCountervoltageWaveform = 0;
			memset(potentiometryWaveform, 0, sizeof potentiometryWaveform);
			memset(currentWaveform, 0, sizeof currentWaveform);
			memset(countervoltageWaveform, 0, sizeof countervoltageWaveform);
			EXPERIMENT_ON = FALSE;

			StopNewMessages = FALSE;

			sendHermesAck(CMD,0x00);
			break;
		}
		case StartExperience:
		{
			if(PotentiometryExperience||(ConfigurationSet&&WaveformSet))
			{
				EXPERIMENT_ON = TRUE;
				sendHermesAck(CMD,0x00);
				ptr_sendPotentiometryWaveform = 0;
				sendPotentiometryWaveformLoops = 0;
				potentiometryWaveformLoops = 0;
				ptr_sendCurrentWaveform = 0;
				ptr_sendCountervoltageWaveform = 0;
				ptr_analogWaveform = 0;

				if(PotentiometryExperience)
				{
					potentiometryVariationAverage[0] = -3000;
					potentiometryVariationAverage[1] = 3000;
					ptr_potentiometryWaveform = 0;
					memset(potentiometryWaveform, 0, sizeof potentiometryWaveform);
				}
				else
				{
					ptr_currentWaveform = 0;
					ptr_countervoltageWaveform = 0;
					memset(currentWaveform, 0, sizeof currentWaveform);
					memset(countervoltageWaveform, 0, sizeof countervoltageWaveform);
				}
			}
			else sendHermesError(CMD,0x00);
			break;
		}
		case StopExperience:
		{
			StopTriggered = TRUE;
			EXPERIMENT_ON = FALSE;
			sendHermesAck(CMD,0x00);
			break;
		}
		case StartSendPotentotiometryData:
		{
			ptr_sendPotentiometryWaveform = 0;
			sendPotentiometryWaveformLoops = 0;
			outputNseqPOT = 0;

			if(ptr_potentiometryWaveform>ptr_sendPotentiometryWaveform) //Does it have data?
			{
				sendPotentiometryData = TRUE;
				sendCurrentData = FALSE;
				sendCounterVoltageData = FALSE;

				sendPotentiometryPoints();
			}
			else
			{
				sendPotentiometryData = FALSE;
				sendHermesError(CMD,0x00);
			}
			break;
		}
		case StartSendCurrentVoltammetryData:
		{
			ptr_sendCurrentWaveform = 0;
			outputNseqCM = 0;

			if(ptr_currentWaveform>ptr_sendCurrentWaveform) //Does it have data?
			{
				sendPotentiometryData = FALSE;
				sendCurrentData = TRUE;
				//sendCounterVoltageData = FALSE;

				sendCurrentVoltammetryPoints();
			}
			else
			{
				sendCurrentData = FALSE;
				sendHermesError(CMD,0x00);
			}
			break;
		}
		case StartSendCEVoltageVoltammetryData:
		{
			ptr_sendCountervoltageWaveform = 0;
			outputNseqCE = 0;

			if(ptr_countervoltageWaveform>ptr_sendCountervoltageWaveform) //Does it have data?
			{
				sendPotentiometryData = FALSE;
				//sendCurrentData = FALSE;
				sendCounterVoltageData = TRUE;

				sendCEVoltageVoltammetryPoints();
			}
			else
			{
				sendCounterVoltageData = FALSE;
				sendHermesError(CMD,0x00);
			}
			break;
		}
		case PotentiometryDataTransfer:
		{
			if(!sendPotentiometryData) sendHermesError(CMD,0x00);
			else if(ptr_potentiometryWaveform+1000*potentiometryWaveformLoops>ptr_sendPotentiometryWaveform) //Does it have data?
			{
				inputNseqPOT = receivedNseq;
				uint8_t compNseq = (inputNseqPOT==0)?16:inputNseqPOT;
				if(compNseq-1!=outputNseqPOT)
				{
					ptr_sendPotentiometryWaveform -= pointsSentPOT;
					outputNseqPOT = receivedNseq - 1;
				}

				sendPotentiometryPoints();
			}
			else if(PotentiometryOn && period_us < limitPotSampleTime_us && ptr_potentiometryWaveform == 1000)
			{
				sendPotentiometryData = FALSE;
				outputNseqPOT = 0;
				sendHermesError(PotentiometryDataTransferEnd,0x00);
			}
			else if(PotentiometryOn) sendHermesError(CMD,0x00); // Experiment running but without data to send
			else if(!PotentiometryOn) // Experiment ended and all data has been sent
			{
				sendPotentiometryData = FALSE;
				outputNseqPOT = 0;
				sendHermesError(PotentiometryDataTransferEnd,0x00);
			}
			break;
		}
		case CurrentVoltammetryDataTransfer:
		{
			if(!sendCurrentData) sendHermesError(CMD,0x00);
			else if(ptr_currentWaveform>ptr_sendCurrentWaveform) //Does it have data?
			{
				inputNseqCM = receivedNseq;
				uint8_t compNseq = (inputNseqCM==0)?16:inputNseqCM;
				if(compNseq-1!=outputNseqCM)
				{
					ptr_sendCurrentWaveform -= pointsSentCM;
					outputNseqCM = receivedNseq - 1;
				}

				sendCurrentVoltammetryPoints();
			}
			else if(VoltammetryOn) sendHermesError(CMD,0x00); // Experiment running but without data to send
			else if(!VoltammetryOn) // Experiment ended and all data has been sent
			{
				sendCurrentData = FALSE;
				inputNseqCM = 0;
				sendHermesError(CurrentVoltammetryDataTransferEnd,0x00);
			}
			break;
		}
		case CEVoltageVoltammetryDataTransfer:
		{
			if(!sendCounterVoltageData) sendHermesError(CMD,0x00);
			else if(ptr_countervoltageWaveform>ptr_sendCountervoltageWaveform) //Does it have data?
			{
				inputNseqCE = receivedNseq;
				uint8_t compNseq = (inputNseqCE==0)?16:inputNseqCE;
				if(compNseq-1!=outputNseqCE)
				{
					ptr_sendCountervoltageWaveform -= pointsSentCE;
					outputNseqCE = receivedNseq - 1;
				}

				sendCEVoltageVoltammetryPoints();
			}
			else if(VoltammetryOn) sendHermesError(CMD,0x00); // Experiment running but without data to send
			else if(!VoltammetryOn) // Experiment ended and all data has been sent
			{
				sendCounterVoltageData = FALSE;
				outputNseqCE = 0;
				sendHermesError(CEVoltageVoltammetryDataTransferEnd,0x00);
			}
			break;
		}
		case RestartMeasurementCommand:
		{
			restartMeasurementFlag = TRUE;
			ptr_sendCountervoltageWaveform = 0;
			ptr_sendCurrentWaveform = 0;
			sendHermesAck(CMD,0x00);
			break;
		}
		case ErrorCommand:
		{
			// Resend last message
			setOutputHermesMessage(outputHermesMessage);
			break;
		}
		default:
			break;
	}
}

/*! *********************************************************************************
* \brief        Calculates CHKSUM of the hermesMessage.
*
* \param[in]    hermesMessage        Hermes message to obtain checksum.
* \return		Calculated checksum
********************************************************************************** */

uint8_t hermesMessageCalcChecksum(uint8_t* hermesMessage)
{
	uint16_t SUM = 0;
	for(uint8_t i = 0; i < MSG_POS_CHKSUM; i++)
	{
		SUM += hermesMessage[i];
	}
	return SUM%256;
}

/*! *********************************************************************************
* \brief        Send Hermes error message given the Command that gave error.
*
* \param[in]    Command        		  Hermes message command.
* \param[in]    additionalInfo        Additional Information
********************************************************************************** */

void sendHermesError(uint8_t Command, uint8_t additionalInfo)
{
	uint8_t ErrorString[20] = {MSG_HEAD, MSG_ERROR, 0x00, 0x00, 0x00,
									  0x00, 0x00, 0x00, 0x00, 0x00,
									  0x00, 0x00, 0x00, 0x00, 0x00,
									  0x00, 0x00, 0x00, 0x00, MSG_END};
	ErrorString[2] = Command;
	ErrorString[3] = additionalInfo;
	uint8_t Calc_Chksum = hermesMessageCalcChecksum(ErrorString);
	ErrorString[18] = Calc_Chksum;
	setOutputHermesMessage(ErrorString);
}

/*! *********************************************************************************
* \brief        Send Hermes acknowleadge given the Command that made the request.
*
* \param[in]    Command        Hermes message command.
* \param[in]    Nseq	       Sequence number of data exchange (or 0x00 if not needed)
********************************************************************************** */

void sendHermesAck (uint8_t Command, uint8_t Nseq)
{
	uint8_t AckString[20] = {MSG_HEAD, 0x00, 0x00, 0x00, 0x00,
						     0x00, 0x00, 0x00, 0x00, 0x00,
						     0x00, 0x00, 0x00, 0x00, 0x00,
						     0x00, 0x00, 0x00, 0x00, MSG_END};
	AckString[1] = Command;
	AckString[2] = Nseq;
	uint8_t Calc_Chksum = hermesMessageCalcChecksum(AckString);
	AckString[18] = Calc_Chksum;
	setOutputHermesMessage(AckString);
}

/*! *********************************************************************************
* \brief        Obtains data points ftom bytes
*
* \param[in]    inputMessage        Hermes message input message from where obtaining data.
********************************************************************************** */

void obtainDataPointsFromBytes (uint8_t* inputMessage)
{
	DATA[0] = (inputMessage[3]<<4)+(inputMessage[4]>>4);
	DATA[1] = ((inputMessage[4]&0x0F)<<8)+(inputMessage[5]);
	DATA[2] = (inputMessage[6]<<4)+(inputMessage[7]>>4);
	DATA[3] = ((inputMessage[7]&0x0F)<<8)+(inputMessage[8]);
	DATA[4] = (inputMessage[9]<<4)+(inputMessage[10]>>4);
	DATA[5] = ((inputMessage[10]&0x0F)<<8)+(inputMessage[11]);
	DATA[6] = (inputMessage[12]<<4)+(inputMessage[13]>>4);
	DATA[7] = ((inputMessage[13]&0x0F)<<8)+(inputMessage[14]);
	DATA[8] = (inputMessage[15]<<4)+(inputMessage[16]>>4);
	DATA[9] = ((inputMessage[16]&0x0F)<<8)+(inputMessage[17]);
}

/*! *********************************************************************************
* \brief        Send Potentiometry Voltage Points
********************************************************************************** */
void sendPotentiometryPoints (void)
{
	forMax = 0; // Set number of points to send

	if(ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+0<ptr_potentiometryWaveform)//+1000*potentiometryWaveformLoops)
	{
		BYTES[0]  = ((potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+0]&0xFF0)>>4);
	}
	if(ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+1<ptr_potentiometryWaveform)//+1000*potentiometryWaveformLoops)
	{
		BYTES[1]  = ((potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+0]&0x00F)<<4)
					+((potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+1]&0xF00)>>8);
	}
	if(ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+1<ptr_potentiometryWaveform)//+1000*potentiometryWaveformLoops)
	{
		BYTES[2]  = (potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+1]&0x0FF);
	}
	if(ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+2<ptr_potentiometryWaveform)//+1000*potentiometryWaveformLoops)
	{
		BYTES[3]  = ((potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+2]&0xFF0)>>4);
	}
	if(ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+3<ptr_potentiometryWaveform)//+1000*potentiometryWaveformLoops)
	{
		BYTES[4]  = ((potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+2]&0x00F)<<4)
					+((potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+3]&0xF00)>>8);
	}
	if(ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+3<ptr_potentiometryWaveform)//+1000*potentiometryWaveformLoops)
	{
		BYTES[5]  = (potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+3]&0x0FF);
	}
	if(ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+4<ptr_potentiometryWaveform)//+1000*potentiometryWaveformLoops)
	{
		BYTES[6]  = ((potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+4]&0xFF0)>>4);
	}
	if(ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+5<ptr_potentiometryWaveform)//+1000*potentiometryWaveformLoops)
	{
		BYTES[7]  = ((potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+4]&0x00F)<<4)
					+((potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+5]&0xF00)>>8);
	}
	if(ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+5<ptr_potentiometryWaveform)//+1000*potentiometryWaveformLoops)
	{
		BYTES[8]  = (potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+5]&0x0FF);
	}
	if(ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+6<ptr_potentiometryWaveform)//+1000*potentiometryWaveformLoops)
	{
		BYTES[9]  = ((potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+6]&0xFF0)>>4);
	}
	if(ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+7<ptr_potentiometryWaveform)//+1000*potentiometryWaveformLoops)
	{
		BYTES[10] = ((potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+6]&0x00F)<<4)
					+((potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+7]&0xF00)>>8);
	}
	if(ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+7<ptr_potentiometryWaveform)//+1000*potentiometryWaveformLoops)
	{
		BYTES[11] = (potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+7]&0x0FF);
	}
	if(ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+8<ptr_potentiometryWaveform)//+1000*potentiometryWaveformLoops)
	{
		BYTES[12] = ((potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+8]&0xFF0)>>4);
	}
	if(ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+9<ptr_potentiometryWaveform)//+1000*potentiometryWaveformLoops)
	{
		BYTES[13] = ((potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+8]&0x00F)<<4)
					+((potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+9]&0xF00)>>8);
	}
	if(ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+9<ptr_potentiometryWaveform)//+1000*potentiometryWaveformLoops)
	{
		BYTES[14] = (potentiometryWaveform[ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000+9]&0x0FF);
	}

	if(potentiometryWaveformLoops - sendPotentiometryWaveformLoops > 0) forMax = potentiometryWaveformLoops*1000-ptr_sendPotentiometryWaveform; //999
	else if(ptr_potentiometryWaveform+sendPotentiometryWaveformLoops*1000-ptr_sendPotentiometryWaveform>10) forMax = 10;
	else if(ptr_potentiometryWaveform>0) forMax = ptr_potentiometryWaveform+sendPotentiometryWaveformLoops*1000-ptr_sendPotentiometryWaveform;
	if(forMax > 10) forMax = 10;

	if(forMax!=0) // Data to be sent (wether the experiment is running or not)
	{
		uint8_t strToSend[20] = {MSG_HEAD, 0x00, 0x00, 0x00, 0x00,
								 0x00, 0x00, 0x00, 0x00, 0x00,
								 0x00, 0x00, 0x00, 0x00, 0x00,
								 0x00, 0x00, 0x00, 0x00, MSG_END};
		strToSend[1] = PotentiometryDataTransfer;

		outputNseqPOT = (outputNseqPOT>=15)?0:outputNseqPOT+1;
		strToSend[2] = outputNseqPOT + (forMax<<4);

		for(uint8_t i = 0; i < 15; i++)	strToSend[i+3] = BYTES[i];

		uint8_t Calc_Chksum = hermesMessageCalcChecksum(strToSend);
		strToSend[18] = Calc_Chksum;
		setOutputHermesMessage(strToSend);

		ptr_sendPotentiometryWaveform += forMax;
		pointsSentPOT = forMax;
	}
	else if(PotentiometryOn && forMax==0) // Experiment running but without data to send
	{
		sendHermesError(PotentiometryDataTransfer,0x00);
	}
	else if(!PotentiometryOn && forMax==0) // Experiment ended
	{
		sendPotentiometryData = FALSE;
		outputNseqPOT = 0;
		sendHermesError(PotentiometryDataTransferEnd,0x00);
	}

	if(ptr_sendPotentiometryWaveform-sendPotentiometryWaveformLoops*1000>=1000 &&
			period_us >= limitPotSampleTime_us) sendPotentiometryWaveformLoops++;
}

/*! *********************************************************************************
* \brief        Send Current Voltammetry Points
********************************************************************************** */

void sendCurrentVoltammetryPoints (void)
{
	forMax = 0; // Set number of points to send

	BYTES[0]  = ((currentWaveform[ptr_sendCurrentWaveform+0]&0xFF0)>>4);
	BYTES[1]  = ((currentWaveform[ptr_sendCurrentWaveform+0]&0x00F)<<4)
				+((currentWaveform[ptr_sendCurrentWaveform+1]&0xF00)>>8);
	BYTES[2]  = (currentWaveform[ptr_sendCurrentWaveform+1]&0x0FF);
	BYTES[3]  = ((currentWaveform[ptr_sendCurrentWaveform+2]&0xFF0)>>4);
	BYTES[4]  = ((currentWaveform[ptr_sendCurrentWaveform+2]&0x00F)<<4)
				+((currentWaveform[ptr_sendCurrentWaveform+3]&0xF00)>>8);
	BYTES[5]  = (currentWaveform[ptr_sendCurrentWaveform+3]&0x0FF);
	BYTES[6]  = ((currentWaveform[ptr_sendCurrentWaveform+4]&0xFF0)>>4);
	BYTES[7]  = ((currentWaveform[ptr_sendCurrentWaveform+4]&0x00F)<<4)
				+((currentWaveform[ptr_sendCurrentWaveform+5]&0xF00)>>8);
	BYTES[8]  = (currentWaveform[ptr_sendCurrentWaveform+5]&0x0FF);
	BYTES[9]  = ((currentWaveform[ptr_sendCurrentWaveform+6]&0xFF0)>>4);
	BYTES[10] = ((currentWaveform[ptr_sendCurrentWaveform+6]&0x00F)<<4)
				+((currentWaveform[ptr_sendCurrentWaveform+7]&0xF00)>>8);
	BYTES[11] = (currentWaveform[ptr_sendCurrentWaveform+7]&0x0FF);
	BYTES[12] = ((currentWaveform[ptr_sendCurrentWaveform+8]&0xFF0)>>4);
	BYTES[13] = ((currentWaveform[ptr_sendCurrentWaveform+8]&0x00F)<<4)
				+((currentWaveform[ptr_sendCurrentWaveform+9]&0xF00)>>8);
	BYTES[14] = (currentWaveform[ptr_sendCurrentWaveform+9]&0x0FF);

	if(ptr_currentWaveform-ptr_sendCurrentWaveform>10) forMax = 10;
	else forMax = ptr_currentWaveform-ptr_sendCurrentWaveform;

	if(forMax!=0)
	{
		uint8_t strToSend[20] = {MSG_HEAD, 0x00, 0x00, 0x00, 0x00,
								 0x00, 0x00, 0x00, 0x00, 0x00,
								 0x00, 0x00, 0x00, 0x00, 0x00,
								 0x00, 0x00, 0x00, 0x00, MSG_END};
		strToSend[1] = CurrentVoltammetryDataTransfer;

		outputNseqCM = (outputNseqCM>=15)?0:outputNseqCM+1;
		strToSend[2] = outputNseqCM + (forMax<<4);

		for(uint8_t i = 0; i < 15; i++)	strToSend[i+3] = BYTES[i];

		uint8_t Calc_Chksum = hermesMessageCalcChecksum(strToSend);
		strToSend[18] = Calc_Chksum;
		setOutputHermesMessage(strToSend);

		ptr_sendCurrentWaveform += forMax;
		pointsSentCM = forMax;
	}
	else if(VoltammetryOn && forMax==0) // Experiment running but without data to send
	{
		sendHermesError(CEVoltageVoltammetryDataTransfer,0x00);
	}
	else if(!VoltammetryOn && forMax==0) // Experiment ended
	{
		sendCurrentData = FALSE;
		outputNseqCM = 0;
		sendHermesError(CurrentVoltammetryDataTransferEnd,0x00);
	}
}

/*! *********************************************************************************
* \brief        Send CE Voltage Voltammetry Points
********************************************************************************** */

void sendCEVoltageVoltammetryPoints (void)
{
	forMax = 0; // Set number of points to send

	BYTES[0]  = ((countervoltageWaveform[ptr_sendCountervoltageWaveform+0]&0xFF0)>>4);
	BYTES[1]  = ((countervoltageWaveform[ptr_sendCountervoltageWaveform+0]&0x00F)<<4)
				+((countervoltageWaveform[ptr_sendCountervoltageWaveform+1]&0xF00)>>8);
	BYTES[2]  = (countervoltageWaveform[ptr_sendCountervoltageWaveform+1]&0x0FF);
	BYTES[3]  = ((countervoltageWaveform[ptr_sendCountervoltageWaveform+2]&0xFF0)>>4);
	BYTES[4]  = ((countervoltageWaveform[ptr_sendCountervoltageWaveform+2]&0x00F)<<4)
				+((countervoltageWaveform[ptr_sendCountervoltageWaveform+3]&0xF00)>>8);
	BYTES[5]  = (countervoltageWaveform[ptr_sendCountervoltageWaveform+3]&0x0FF);
	BYTES[6]  = ((countervoltageWaveform[ptr_sendCountervoltageWaveform+4]&0xFF0)>>4);
	BYTES[7]  = ((countervoltageWaveform[ptr_sendCountervoltageWaveform+4]&0x00F)<<4)
				+((countervoltageWaveform[ptr_sendCountervoltageWaveform+5]&0xF00)>>8);
	BYTES[8]  = (countervoltageWaveform[ptr_sendCountervoltageWaveform+5]&0x0FF);
	BYTES[9]  = ((countervoltageWaveform[ptr_sendCountervoltageWaveform+6]&0xFF0)>>4);
	BYTES[10] = ((countervoltageWaveform[ptr_sendCountervoltageWaveform+6]&0x00F)<<4)
				+((countervoltageWaveform[ptr_sendCountervoltageWaveform+7]&0xF00)>>8);
	BYTES[11] = (countervoltageWaveform[ptr_sendCountervoltageWaveform+7]&0x0FF);
	BYTES[12] = ((countervoltageWaveform[ptr_sendCountervoltageWaveform+8]&0xFF0)>>4);
	BYTES[13] = ((countervoltageWaveform[ptr_sendCountervoltageWaveform+8]&0x00F)<<4)
				+((countervoltageWaveform[ptr_sendCountervoltageWaveform+9]&0xF00)>>8);
	BYTES[14] = (countervoltageWaveform[ptr_sendCountervoltageWaveform+9]&0x0FF);

	if(ptr_countervoltageWaveform-ptr_sendCountervoltageWaveform>10) forMax = 10;
	else forMax = ptr_countervoltageWaveform-ptr_sendCountervoltageWaveform;

	if(forMax!=0)
	{
		uint8_t strToSend[20] = {MSG_HEAD, 0x00, 0x00, 0x00, 0x00,
								 0x00, 0x00, 0x00, 0x00, 0x00,
								 0x00, 0x00, 0x00, 0x00, 0x00,
								 0x00, 0x00, 0x00, 0x00, MSG_END};
		strToSend[1] = CEVoltageVoltammetryDataTransfer;

		outputNseqCE = (outputNseqCE>=15)?0:outputNseqCE+1;
		strToSend[2] = outputNseqCE + (forMax<<4);

		for(uint8_t i = 0; i < 15; i++)	strToSend[i+3] = BYTES[i];

		uint8_t Calc_Chksum = hermesMessageCalcChecksum(strToSend);
		strToSend[18] = Calc_Chksum;
		setOutputHermesMessage(strToSend);

		ptr_sendCountervoltageWaveform += forMax;
		pointsSentCE = forMax;
	}
	else if(VoltammetryOn && forMax==0) // Experiment running but without data to send
	{
		sendHermesError(CEVoltageVoltammetryDataTransfer,0x00);
	}
	else if(!VoltammetryOn && forMax==0) // Experiment ended
	{
		sendCounterVoltageData = FALSE;
		outputNseqCE = 0;
		sendHermesError(CEVoltageVoltammetryDataTransferEnd,0x00);
	}
}

/*! *********************************************************************************
* \brief        sprintf manually implemented
*
* \param[in]    str        	  Pointer to string to save.
* \param[in]    pParam        Length of the string to save.
* \param[in]    pParam        Number to convert.
********************************************************************************** */

void pstruint(uint8_t* str, uint8_t len, uint16_t val)
{
	uint8_t i = 0;

	for(i=1; i<=len; i++)
	{
		str[len-i] = val % 10 + '0';
		val /=10;
	}
	str[i-1]='\0';
}

/*! *********************************************************************************
* \brief        Handles ZOIS timer callback.
*
* \param[in]    pParam        Calback parameters.
********************************************************************************** */
uint16_t aCnt = 0;
static void ZoisTimerCallback (void * pParam)
{
	/* if(alternate)
	{
		if(aCnt++==0) setGPIORelay(RELAY8,DOWN);
		else if(aCnt++>5)
		{
			setAllGPIO(DOWN);
			if(aCnt++>20)
			{
				aCnt = 0;
				alternate = FALSE;
			}
		}
	}
	else
	{
		if(aCnt++==0) setGPIORelay(RELAY8,UP);
		else if(aCnt++>5)
		{
			setAllGPIO(DOWN);
			if(aCnt++>20)
			{
				aCnt = 0;
				alternate = TRUE;
			}
		}
	} */
	if(FAEVIS_FSM() || settingRelaysFlag)
	{ // State changed - INIT STATE
		if(!settingRelaysFlag)
		{
			if(SystemState == ss_DissolutionPotentiometry ||
			   SystemState == ss_SubstratumPotentiometry)
			{
				period_us = (double)(PotentiometryTimeBetweenSamples)*1000;
				PotentiometryTimeout_s = (double)(PotentiometryTimeout)/1000;
				maxCnt_PotentiometryTimeout_toSec = 1e6; // Timer each 100 us, 1e6 us is 1 sec
			}
			else
			{
				period_us = (double)(VMSampleTime);
			}

			if(SystemState == ss_DissolutionPotentiometry ||
			   SystemState == ss_SubstratumPotentiometry)
			{
				ptr_potentiometryWaveform = 0;
				memset(potentiometryWaveform,0,sizeof(potentiometryWaveform));
				cnt_PotentiometryTimeout_toSec = 0;
				ptr_PotentiometryTimeout_s = 0;
				PotentiometryOn = TRUE;
			}
			else if(SystemState == ss_Gradient 							||
				    SystemState == ss_CurrentInjection					||
				    SystemState == ss_2eDissolutionVoltammetry 			||
				    SystemState == ss_3eDissolutionVoltammetry 			||
				    SystemState == ss_2eSubstratumVoltammetry 			||
				    SystemState == ss_3eSubstratumVoltammetry)
			{
#if CURRENT_SCALE_SELECTOR
				if(CurrentScale==CurrentScale1) setGPIO(SEL_CM, HIGH);
				else							setGPIO(SEL_CM, LOW);
#endif
				ptr_currentWaveform = 0;
				memset(currentWaveform,0,sizeof(currentWaveform));
				ptr_countervoltageWaveform = 0;
				memset(countervoltageWaveform,0,sizeof(countervoltageWaveform));
				ptr_cycles = 0;
				VoltammetryOn = TRUE;
			}
		}
		switch(SystemState)
		{
			case ss_Idle:
			{
				if(setRelayConfiguration(IdleState))
				{
					if(ptrRelay == 0) settingRelaysFlag = FALSE;
					else settingRelaysFlag = TRUE;
				}
				else settingRelaysFlag = TRUE;

				if(MeasuredOCP!=0) DAC_SetBufferValue(OUT, 0U, MeasuredOCP);
				else DAC_SetBufferValue(OUT, 0U, 2048);
			} break;

			case ss_Gradient:
			{
				if(setRelayConfiguration(GradientState))
				{
					if(ptrRelay == 0) settingRelaysFlag = FALSE;
					else settingRelaysFlag = TRUE;
				}
				else settingRelaysFlag = TRUE;
			} break;

			case ss_CurrentInjection:
			{
				if(setRelayConfiguration(CurrentInjectionState))
				{
					if(ptrRelay == 0) settingRelaysFlag = FALSE;
					else settingRelaysFlag = TRUE;
				}
				else settingRelaysFlag = TRUE;
			} break;

			case ss_2eDissolutionVoltammetry:
			{
				if(setRelayConfiguration(Voltammetry2DissolutionState))
				{
					if(ptrRelay == 0) settingRelaysFlag = FALSE;
					else settingRelaysFlag = TRUE;
				}
				else settingRelaysFlag = TRUE;
			} break;

			case ss_2eSubstratumVoltammetry:
			{
				if(setRelayConfiguration(Voltammetry2SubstratumState))
				{
					if(ptrRelay == 0) settingRelaysFlag = FALSE;
					else settingRelaysFlag = TRUE;
				}
				else settingRelaysFlag = TRUE;
			} break;

			case ss_3eDissolutionVoltammetry:
			{
				if(setRelayConfiguration(Voltammetry3DissolutionState))
				{
					if(ptrRelay == 0) settingRelaysFlag = FALSE;
					else settingRelaysFlag = TRUE;
				}
				else settingRelaysFlag = TRUE;
			} break;

			case ss_3eSubstratumVoltammetry:
			{
				if(setRelayConfiguration(Voltammetry3SubstratumState))
				{
					if(ptrRelay == 0) settingRelaysFlag = FALSE;
					else settingRelaysFlag = TRUE;
				}
				else settingRelaysFlag = TRUE;
			} break;

			case ss_DissolutionPotentiometry:
			{
				if(setRelayConfiguration(PotentiometryDissolutionState))
				{
					if(ptrRelay == 0) settingRelaysFlag = FALSE;
					else settingRelaysFlag = TRUE;
				}
				else settingRelaysFlag = TRUE;
			} break;

			case ss_SubstratumPotentiometry:
			{
				if(setRelayConfiguration(PotentiometrySubstratumState))
				{
					if(ptrRelay == 0) settingRelaysFlag = FALSE;
					else settingRelaysFlag = TRUE;
				}
				else settingRelaysFlag = TRUE;
			} break;
			case ss_PotentiometryCalibration:
			{
				if(setRelayConfiguration(potentiometryCalibrationState))
				{
					if(ptrRelay == 0) settingRelaysFlag = FALSE;
					else settingRelaysFlag = TRUE;
				}
				else settingRelaysFlag = TRUE;
			} break;
		}
	}
	else
	{ // PROCESS STATE
		if(((PotentiometryOn || VoltammetryOn) && !ExperienceStarted) || CALIBRATION_ON)
		{
			if(PIT_StartedFlag)
			{
				PIT_DisableInterrupts(PIT, kPIT_Chnl_0, kPIT_TimerInterruptEnable);
				PIT_Deinit(PIT);
				PIT_StartedFlag = FALSE;
			}
			timeoutReached = FALSE;
			if(CALIBRATION_ON) configPIT(1000);
			else if(PotentiometryOn) configPIT(100);
			else configPIT(VMSampleTime);
		}
	}
}

/*! *********************************************************************************
* \brief        Initializes de rutine to set a relay.
*
* \param[in]    relay        Selects the relay to be set.
* \param[in]	state		 UP or DOWN.
*
* \return		SUCCESS (1) if the setter was available, else FAILURE (0).
********************************************************************************** */

bool_t setRelay (uint8_t relay, uint8_t state)
{
	if(relaySetterAvailable)
	{
		relaySetterAvailable = FALSE;
		TMR_StartLowPowerTimer(mSetRelayTimerId,
					gTmrLowPowerSingleShotMillisTimer_c,
					mSetRelayIntervalInMs_c,
					setRelayTimerCallback, NULL);
		setGPIORelay(relay, state);
		return SUCCESS;
	}
	else return FAILURE;
}

/*! *********************************************************************************
* \brief        Sets the system in determined configuration.
*
* \param[in]    relayConfiguration*        Selects the system configuration to be set.
* \return		SUCCESS if could access to relay setting, FAILURE if not.
********************************************************************************** */

bool_t setRelayConfiguration (uint8_t* relayConfiguration)
{
	if(relaySetterAvailable)
	{
		if(ptrRelay == 0) ptrRelay = 1;
		setRelay(ptrRelay,relayConfiguration[ptrRelay-1]);
		ptrRelay++;
		if(ptrRelay >= 11) ptrRelay = 0;
		return SUCCESS;
	}
	else return FAILURE;
}

/*! *********************************************************************************
* \brief        Handles Relay Setter timer callback.
*
* \param[in]    pParam        Calback parameters.
********************************************************************************** */

static void setRelayTimerCallback (void * pParam)
{
	setGPIORelay(RELAYSTOP, LOW);
	relaySetterAvailable = TRUE;
}

/*! *********************************************************************************
* \brief        Finite State Machine of the FAEVIS System.
*
* \return   	TRUE if state has changed, FALSE if not
********************************************************************************** */

bool_t FAEVIS_FSM (void)
{
	if(EXPERIMENT_ENDED)
	{
		PotentiometryExperience = FALSE;
		ConfigurationSet = FALSE;
		//WaveformSet = FALSE;
		EXPERIMENT_ENDED = FALSE;
	}
	if(!EXPERIMENT_ON && !CALIBRATION_ON)
	{
		if(SystemState == ss_Idle)	return FALSE;
		else
		{
			SystemState = ss_Idle;
			return TRUE;
		}
	}
	else
	{
		switch(Experience)
		{
			case GradientExperience:
			{
				if(SystemState == ss_Gradient)
				{
					if(voltammetryEnded)
					{
						SystemState = ss_Idle;
						EXPERIMENT_ENDED = TRUE;
						EXPERIMENT_ON = FALSE;
						voltammetryEnded = FALSE;
						VoltammetryOn = FALSE;
						return TRUE;
					}
					else return FALSE;
				}
				else
				{
					SystemState = ss_Gradient;
					return TRUE;
				}
			} break;

			case CurrentInjectionExperience:
			{
				if(SystemState == ss_CurrentInjection)
				{
					if(voltammetryEnded)
					{
						SystemState = ss_Idle;
						EXPERIMENT_ENDED = TRUE;
						EXPERIMENT_ON = FALSE;
						voltammetryEnded = FALSE;
						VoltammetryOn = FALSE;
						return TRUE;
					}
					else return FALSE;
				}
				else
				{
					SystemState = ss_CurrentInjection;
					return TRUE;
				}
			} break;

			case DissolutionTwoElectrodesVoltammetryExperience:
			{
				if(SystemState == ss_2eDissolutionVoltammetry)
				{
					if(voltammetryEnded)
					{
						SystemState = ss_Idle;
						EXPERIMENT_ENDED = TRUE;
						EXPERIMENT_ON = FALSE;
						voltammetryEnded = FALSE;
						VoltammetryOn = FALSE;
						return TRUE;
					}
					else return FALSE;
				}
				else
				{
					SystemState = ss_2eDissolutionVoltammetry;
					return TRUE;
				}
			} break;

			case SubstratumTwoElectrodesVoltammetryExperience:
			{
				if(SystemState == ss_2eSubstratumVoltammetry)
				{
					if(voltammetryEnded)
					{
						SystemState = ss_Idle;
						EXPERIMENT_ENDED = TRUE;
						EXPERIMENT_ON = FALSE;
						voltammetryEnded = FALSE;
						VoltammetryOn = FALSE;
						return TRUE;
					}
					else return FALSE;
				}
				else
				{
					SystemState = ss_2eSubstratumVoltammetry;
					return TRUE;
				}
			} break;

			case DissolutionThreeElectrodesVoltammetryExperience:
			{
				if(!CALIBRATION_ON)
				{
					if(SystemState == ss_Idle)
					{
						SystemState = ss_3eDissolutionVoltammetry;
						VoltammetryOn = TRUE;
						return TRUE;
					}
					if(SystemState == ss_3eDissolutionVoltammetry)
					{
						if(voltammetryEnded)
						{
							SystemState = ss_Idle;
							EXPERIMENT_ENDED = TRUE;
							EXPERIMENT_ON = FALSE;
							voltammetryEnded = FALSE;
							VoltammetryOn = FALSE;
							return TRUE;
						}
						else return FALSE;
					}
				}
				else
				{
					if(SystemState == ss_Idle)
					{
						SystemState = ss_3eDissolutionVoltammetry;
						return TRUE;
					}
					if(SystemState == ss_3eDissolutionVoltammetry)
					{
						if(calibrationEnded)
						{
							calibrationEnded = FALSE;
							CALIBRATION_ON = FALSE;
							return TRUE;
						}
						else return FALSE;
					}
				}
			} break;

			case SubstratumThreeElectrodesVoltammetryExperience:
			{
				if(SystemState == ss_Idle)
				{
					SystemState = ss_3eSubstratumVoltammetry;
					VoltammetryOn = TRUE;
					return TRUE;
				}
				if(SystemState == ss_3eSubstratumVoltammetry)
				{
					if(voltammetryEnded)
					{
						SystemState = ss_Idle;
						EXPERIMENT_ENDED = TRUE;
						EXPERIMENT_ON = FALSE;
						voltammetryEnded = FALSE;
						VoltammetryOn = FALSE;
						return TRUE;
					}
					else return FALSE;
				}
			} break;

			case DissolutionPotentiometryExperience:
			{
				if(!CALIBRATION_ON)
				{
					if(SystemState == ss_Idle)
					{
						SystemState = ss_DissolutionPotentiometry;
						return TRUE;
					}
					if(SystemState == ss_DissolutionPotentiometry)
					{
						if(potentiometryEnded)
						{
							SystemState = ss_Idle;
							potentiometryEnded = FALSE;
							EXPERIMENT_ENDED = TRUE;
							EXPERIMENT_ON = FALSE;
							PotentiometryExperience = FALSE;
							return TRUE;
						}
						else return FALSE;
					}
				}
				else
				{
					if(SystemState == ss_Idle)
					{
						SystemState = ss_PotentiometryCalibration;
						return TRUE;
					}
					if(SystemState == ss_PotentiometryCalibration)
					{
						if(calibrationEnded)
						{
							calibrationEnded = FALSE;
							CALIBRATION_ON = FALSE;
							SystemState = ss_Idle;
							return TRUE;
						}
						else return FALSE;
					}
				}
			} break;

			case SubstratumPotentiometryExperience:
			{
				if(SystemState == ss_Idle)
				{
					SystemState = ss_SubstratumPotentiometry;
					return TRUE;
				}
				if(SystemState == ss_SubstratumPotentiometry)
				{
					if(potentiometryEnded)
					{
						SystemState = ss_Idle;
						potentiometryEnded = FALSE;
						EXPERIMENT_ENDED = TRUE;
						EXPERIMENT_ON = FALSE;
						PotentiometryExperience = FALSE;
						return TRUE;
					}
					else return FALSE;
				}
			} break;

			default:
			{
				SystemState = ss_Idle;
				EXPERIMENT_ON = FALSE;
				return TRUE;
			} break;
		}
	}
	return FALSE;
}

/*! *********************************************************************************
* \brief        Hardware (ADC, DAC, GPIO) initialization function.
********************************************************************************** */

void Init_Hw (void)
{
    /* Board pin, clock, debug console init */
    BOARD_InitPins();
    BOARD_BootClockRUN();

    /* Init GPIO */
    configAllGPIO();

    /* Init DAC */
    configDAC(dacConfigStruct);

    /* Init ADCs */
    configADC(ADC_CM, &adc16ConfigStruct_CM, &adc16ChannelConfigStruct_CM);
    configADC(ADC_WE, &adc16ConfigStruct_WE, &adc16ChannelConfigStruct_WE);
    configADC(ADC_CE, &adc16ConfigStruct_CE, &adc16ChannelConfigStruct_CE);

    setAllGPIO(LOW);
}

/*! *********************************************************************************
* \brief        Configures PIT.
********************************************************************************** */

uint32_t ptr_100us = 0;

void configPIT (uint32_t period)
{
	/* Set up flag */
	PIT_StartedFlag = TRUE;

	/* Init PIT */
	/*
	 * pitConfig.enableRunInDebug = false;
	 */
	PIT_GetDefaultConfig(&pitConfig);

	/* Init pit module */
	PIT_Init(PIT, &pitConfig);

	if(period<=10U) period = 10U;

	/* Set timer period for channel 0 */
	PIT_SetTimerPeriod(PIT, kPIT_Chnl_0, USEC_TO_COUNT(period, PIT_SOURCE_CLOCK));

	/* Enable timer interrupts for channel 0 */
	PIT_EnableInterrupts(PIT, kPIT_Chnl_0, kPIT_TimerInterruptEnable);

	/* Enable at the NVIC */
	EnableIRQ(PIT_IRQ_ID);

	ptr_100us = 0;
	/* Start the timer */
	PIT_StartTimer(PIT, kPIT_Chnl_0);
}

/*! *********************************************************************************
* \brief        Configures DAC.
*
* \param[in]    dacConfigStruct        DAC configuration structure.
********************************************************************************** */

void configDAC(dac_config_t dacConfigStruct)
{
	DAC_GetDefaultConfig(&dacConfigStruct);
	//dacConfigStruct.referenceVoltageSource = kDAC_ReferenceVoltageSourceVref1; /* External reference */
	dacConfigStruct.enableLowPowerMode = false;
	DAC_Init(OUT, &dacConfigStruct);
	DAC_Enable(OUT, true);             // Enable output.
	DAC_SetBufferReadPointer(OUT, 0U); // Make sure the read pointer to the start.
}

/*! *********************************************************************************
* \brief        Configures ADCs.
*
* \param[in]    ADC_SE			        		ADC Singñe-ended.
* \param[in]    adc16ConfigStruct        		ADC configuration structure.
* \param[in]    adc16ChannelConfigStruct        ADC channel configuration structure.
********************************************************************************** */

void configADC(int ADC_SE, adc16_config_t* adc16ConfigStruct, adc16_channel_config_t* adc16ChannelConfigStruct)
{
	ADC16_GetDefaultConfig(adc16ConfigStruct);
    adc16ConfigStruct->referenceVoltageSource = kADC16_ReferenceVoltageSourceValt;
  //adc16ConfigStruct->longSampleMode = kADC16_LongSampleCycle6;
  //adc16ConfigStruct->enableHighSpeed = true;
	ADC16_Init(ADC_BASE, adc16ConfigStruct);
	ADC16_EnableHardwareTrigger(ADC_BASE, false); /* Make sure the software trigger is used. */
#if defined(FSL_FEATURE_ADC16_HAS_CALIBRATION) && FSL_FEATURE_ADC16_HAS_CALIBRATION
	ADC16_DoAutoCalibration(ADC_BASE);
#endif /* FSL_FEATURE_ADC16_HAS_CALIBRATION */
	if(ADC_SE == ADC_CM) adc16ChannelConfigStruct->channelNumber = ADC_CM;
	if(ADC_SE == ADC_CE) adc16ChannelConfigStruct->channelNumber = ADC_CE;
	if(ADC_SE == ADC_WE) adc16ChannelConfigStruct->channelNumber = ADC_WE;
	adc16ChannelConfigStruct->enableInterruptOnConversionCompleted = false;
#if defined(FSL_FEATURE_ADC16_HAS_DIFF_MODE) && FSL_FEATURE_ADC16_HAS_DIFF_MODE
	adc16ChannelConfigStruct->enableDifferentialConversion = false;
#endif /* FSL_FEATURE_ADC16_HAS_DIFF_MODE */
}

/*! *********************************************************************************
* \brief        Handles Signal Capture and Application Interrupt.
********************************************************************************** */

uint32_t pitLoopCnt = 0;
void PIT_IRQHandler (void)
{
	/* Clear interrupt flag.*/
	if(PIT_StartedFlag) PIT_ClearStatusFlags(PIT, kPIT_Chnl_0, kPIT_TimerFlag);
	if(EXPERIMENT_ON || CALIBRATION_ON)
	{
		pitLoopCnt++;
		if(!CALIBRATION_ON)
		{
			if(PotentiometryOn)
			{
				ExperienceStarted = TRUE;

				ptr_100us += 100;
				if(ptr_100us>=period_us)
				{
					ptr_100us = 0;

					if(ptr_potentiometryWaveform==sizeof(potentiometryWaveform)/2)
					{
						if(period_us>=limitPotSampleTime_us) ptr_potentiometryWaveform = 0;
						if(ptr_potentiometryWaveform==0) potentiometryWaveformLoops++;
					}
					if(ptr_potentiometryWaveform<sizeof(potentiometryWaveform)/2) //&& !timeoutReached)
					{
						potTempValue = 0;
						for(uint8_t i = 0; i<averagingMeasurement; i++)
						{
							ADC16_SetChannelConfig(ADC_BASE, ADC_GROUP, &adc16ChannelConfigStruct_WE);
							while (0U == (kADC16_ChannelConversionDoneFlag & ADC16_GetChannelStatusFlags(ADC_BASE, ADC_GROUP)));
							potTempValue += ADC16_GetChannelConversionValue(ADC_BASE, ADC_GROUP);
						}
						potentiometryWaveform[ptr_potentiometryWaveform++] = potTempValue/averagingMeasurement;

						if(PotentiometryAverageON)
						{
							if(ptr_potentiometryWaveform+potentiometryWaveformLoops*1e3-1 < PotentiometryAveragingSamples)
							{
								potentiometryVariationAverage[0] = -5000;
								potentiometryVariationAverage[1] = 5000;
							}
							else
							{
								potentiometryVariationAverage[0] = potentiometryVariationAverage[1];
								potentiometryVariationAverage[1] = 0;
								for (uint8_t i = 0; i < PotentiometryAveragingSamples; i++)
								{
									if(ptr_potentiometryWaveform-i-1>=0)
									{
										potentiometryVariationAverage[1] += potentiometryWaveform[ptr_potentiometryWaveform-i-1];
									}
									else
									{
										potentiometryVariationAverage[1] += potentiometryWaveform[1000-ptr_potentiometryWaveform-i-1];
									}
								}
								potentiometryVariationAverage[1] /= PotentiometryAveragingSamples;
								PotentiometryVoltageVariation = fabs(potentiometryVariationAverage[0] - potentiometryVariationAverage[1]);
								if(PotentiometryVoltageVariation <= PotentiometryMaximumVoltageVariation)
								{
									PotentiometryOn = FALSE;
									potentiometryEnded = TRUE;
									ExperienceStarted = FALSE;
									if(PIT_StartedFlag)
									{
										PIT_StopTimer(PIT, kPIT_Chnl_0);
										PIT_DisableInterrupts(PIT, kPIT_Chnl_0, kPIT_TimerInterruptEnable);
										PIT_Deinit(PIT);
										PIT_StartedFlag = FALSE;
										MeasuredOCP = potentiometryVariationAverage[1];
									}
								}
							}
						}
					}
				}
				if(PotentiometryTimeoutON)
				{
					if(timeoutReached)
					{
						//cnt_PotentiometryTimeout_toSec += cnt_units;
						//if(cnt_PotentiometryTimeout_toSec==period_us + cnt_units)
						if(ptr_100us==0)
						{
							PotentiometryOn = FALSE;
							potentiometryEnded = TRUE;
							ExperienceStarted = FALSE;
							if(PIT_StartedFlag)
							{
								PIT_StopTimer(PIT, kPIT_Chnl_0);
								PIT_DisableInterrupts(PIT, kPIT_Chnl_0, kPIT_TimerInterruptEnable);
								PIT_Deinit(PIT);
								PIT_StartedFlag = FALSE;
								MeasuredOCP = potentiometryVariationAverage[1];
							}
						}
					}
					else
					{
						cnt_PotentiometryTimeout_toSec = (cnt_PotentiometryTimeout_toSec<maxCnt_PotentiometryTimeout_toSec)?
								cnt_PotentiometryTimeout_toSec+cnt_units:0;
						if(cnt_PotentiometryTimeout_toSec==maxCnt_PotentiometryTimeout_toSec-cnt_units) ptr_PotentiometryTimeout_s++;
						if(ptr_PotentiometryTimeout_s >= PotentiometryTimeout_s)
						{
							timeoutReached = TRUE;
							cnt_PotentiometryTimeout_toSec = 0;
						}
					}
				}
			}

			if(VoltammetryOn)
			{
				ExperienceStarted = TRUE;

				if(CompensateOCP=='1')
				{
					analogValue = analogWaveform[ptr_analogWaveform]+potentiometryWaveform[ptr_potentiometryWaveform-1]-2048;
				}
				else analogValue = analogWaveform[ptr_analogWaveform];

				DAC_SetBufferValue(OUT, 0U, analogValue);
				ptr_analogWaveform = (ptr_analogWaveform<WaveformNumberOfPoints-1)?ptr_analogWaveform+1:0;

				if(restartMeasurementFlag && ptr_analogWaveform == 0)
				{
					restartMeasurementFlag = FALSE;
					ptr_countervoltageWaveform = 0;
					ptr_currentWaveform = 0;
					ptr_sendCountervoltageWaveform = 0;
					ptr_sendCurrentWaveform = 0;
				}

				VMTempValue = 0;
				if(ptr_countervoltageWaveform<(sizeof(countervoltageWaveform)/2))
				{
					uint8_t avgM = 1;
					//if((VMSampleTime/averagingMeasurement) < 40) avgM = VMSampleTime/40;
					//avgM = 1;
					for(uint8_t i = 0; i<avgM; i++)
					{
						if(Experience!=CurrentInjectionExperience)
							ADC16_SetChannelConfig(ADC_BASE, ADC_GROUP, &adc16ChannelConfigStruct_CE);
						else
							ADC16_SetChannelConfig(ADC_BASE, ADC_GROUP, &adc16ChannelConfigStruct_WE);
						while (0U == (kADC16_ChannelConversionDoneFlag & ADC16_GetChannelStatusFlags(ADC_BASE, ADC_GROUP)));
						VMTempValue += ADC16_GetChannelConversionValue(ADC_BASE, ADC_GROUP);
					}
					countervoltageWaveform[ptr_countervoltageWaveform++] = VMTempValue/avgM;
				}
				VMTempValue = 0;
				if(ptr_currentWaveform<(sizeof(currentWaveform)/2))
				{
					uint8_t avgM = 1;
					//if((VMSampleTime/averagingMeasurement) < 40) avgM = VMSampleTime/40;
					//avgM = 1;
					for(uint8_t i = 0; i<avgM; i++)
					{
						ADC16_SetChannelConfig(ADC_BASE, ADC_GROUP, &adc16ChannelConfigStruct_CM);
						while (0U == (kADC16_ChannelConversionDoneFlag & ADC16_GetChannelStatusFlags(ADC_BASE, ADC_GROUP)));
						VMTempValue += ADC16_GetChannelConversionValue(ADC_BASE, ADC_GROUP);
					}
					currentWaveform[ptr_currentWaveform++] = VMTempValue/avgM;
				}

				if(ptr_analogWaveform==0) ptr_cycles++;

				if(ptr_cycles >= WaveformCycles)
				{
					ptr_analogWaveform = 0;
					VoltammetryOn = FALSE;
					voltammetryEnded = TRUE;
					ExperienceStarted = FALSE;
					if(PIT_StartedFlag)
					{
						PIT_StopTimer(PIT, kPIT_Chnl_0);
						PIT_DisableInterrupts(PIT, kPIT_Chnl_0, kPIT_TimerInterruptEnable);
						PIT_Deinit(PIT);
						PIT_StartedFlag = FALSE;
					}
				}
			}
		}
		else
		{
			if(PotentiometryAutocalibration_flag)
			{
				if(ptr_potentiometryCalibration==0)
				{
					DAC_SetBufferValue(OUT, 0U, analogValues[0]);
					ptr_potentiometryCalibration++;
				}
				else
				{
					potTempValue = 0;
					for(uint8_t i = 0; i<averagingMeasurement; i++)
					{
						ADC16_SetChannelConfig(ADC_BASE, ADC_GROUP, &adc16ChannelConfigStruct_WE);
						while (0U == (kADC16_ChannelConversionDoneFlag & ADC16_GetChannelStatusFlags(ADC_BASE, ADC_GROUP)));
						potTempValue += ADC16_GetChannelConversionValue(ADC_BASE, ADC_GROUP);
					}
					potentiometryCalibration[ptr_potentiometryCalibration-1] = potTempValue/averagingMeasurement;
					if(ptr_potentiometryCalibration<9) DAC_SetBufferValue(OUT, 0U, analogValues[ptr_potentiometryCalibration]);
					ptr_potentiometryCalibration++;
				}
				if(ptr_potentiometryCalibration>=10)
				{
					if(PIT_StartedFlag)
					{
						PIT_StopTimer(PIT, kPIT_Chnl_0);
						PIT_DisableInterrupts(PIT, kPIT_Chnl_0, kPIT_TimerInterruptEnable);
						PIT_Deinit(PIT);
						PIT_StartedFlag = FALSE;
						ptr_potentiometryCalibration = 0;
						calibrationEnded = TRUE;
						PotentiometryAutocalibration_flag = FALSE;
						sendPotentiometryCalibrationAnswer();
					}
				}
			}
			else if(CECMAutocalibrationLarge_flag)
			{
				if(ptr_CECMCalibration==0)
				{
					setGPIO(SEL_CM, HIGH); // Large Scale Current
					DAC_SetBufferValue(OUT, 0U, analogValues[0]);
					ptr_CECMCalibration++;
				}
				else
				{
					VMTempValue = 0;
					for(uint8_t i = 0; i<averagingMeasurement; i++)
					{
						ADC16_SetChannelConfig(ADC_BASE, ADC_GROUP, &adc16ChannelConfigStruct_CM);
						while (0U == (kADC16_ChannelConversionDoneFlag & ADC16_GetChannelStatusFlags(ADC_BASE, ADC_GROUP)));
						VMTempValue += ADC16_GetChannelConversionValue(ADC_BASE, ADC_GROUP);
					}
					CMLargeCalibration[ptr_CECMCalibration-1] = VMTempValue/averagingMeasurement;

					VMTempValue = 0;
					for(uint8_t i = 0; i<averagingMeasurement; i++)
					{
						ADC16_SetChannelConfig(ADC_BASE, ADC_GROUP, &adc16ChannelConfigStruct_CE);
						while (0U == (kADC16_ChannelConversionDoneFlag & ADC16_GetChannelStatusFlags(ADC_BASE, ADC_GROUP)));
						VMTempValue += ADC16_GetChannelConversionValue(ADC_BASE, ADC_GROUP);
					}
					CECalibration[ptr_CECMCalibration-1] = VMTempValue/averagingMeasurement;

					if(ptr_CECMCalibration<9) DAC_SetBufferValue(OUT, 0U, analogValues[ptr_CECMCalibration]);
					ptr_CECMCalibration++;
				}
				if(ptr_CECMCalibration>=10)
				{
					if(PIT_StartedFlag)
					{
						PIT_StopTimer(PIT, kPIT_Chnl_0);
						PIT_DisableInterrupts(PIT, kPIT_Chnl_0, kPIT_TimerInterruptEnable);
						PIT_Deinit(PIT);
						PIT_StartedFlag = FALSE;
						ptr_CECMCalibration = 0;
						calibrationEnded = TRUE;
						CECMAutocalibrationLarge_flag = FALSE;
						sendCECMCalibrationAnswerLarge();
					}
				}
			}
			else if(CECMAutocalibrationPrecision_flag)
			{
				if(ptr_CECMCalibration==0)
				{
					setGPIO(SEL_CM, LOW); // Precision Scale Current
					DAC_SetBufferValue(OUT, 0U, analogValues[0]);
					ptr_CECMCalibration++;
				}
				else
				{
					VMTempValue = 0;
					for(uint8_t i = 0; i<averagingMeasurement; i++)
					{
						ADC16_SetChannelConfig(ADC_BASE, ADC_GROUP, &adc16ChannelConfigStruct_CM);
						while (0U == (kADC16_ChannelConversionDoneFlag & ADC16_GetChannelStatusFlags(ADC_BASE, ADC_GROUP)));
						VMTempValue += ADC16_GetChannelConversionValue(ADC_BASE, ADC_GROUP);
					}
					CMPrecisionCalibration[ptr_CECMCalibration-1] = VMTempValue/averagingMeasurement;

					if(ptr_CECMCalibration<9) DAC_SetBufferValue(OUT, 0U, analogValues[ptr_CECMCalibration]);
					ptr_CECMCalibration++;
				}
				if(ptr_CECMCalibration>=10)
				{
					if(PIT_StartedFlag)
					{
						PIT_StopTimer(PIT, kPIT_Chnl_0);
						PIT_DisableInterrupts(PIT, kPIT_Chnl_0, kPIT_TimerInterruptEnable);
						PIT_Deinit(PIT);
						PIT_StartedFlag = FALSE;
						ptr_CECMCalibration = 0;
						calibrationEnded = TRUE;
						CECMAutocalibrationPrecision_flag = FALSE;
						sendCECMCalibrationAnswerPrecision();
					}
				}
			}
		}
	}
	else
	{
		PotentiometryOn = FALSE;
		potentiometryEnded = FALSE;
		ExperienceStarted = FALSE;
		VoltammetryOn =  FALSE;
		voltammetryEnded = FALSE;

		PIT_StopTimer(PIT, kPIT_Chnl_0);
		PIT_DisableInterrupts(PIT, kPIT_Chnl_0, kPIT_TimerInterruptEnable);
		PIT_Deinit(PIT);

		PIT_StartedFlag = FALSE;
		pitLoopCnt = 0;
	}
}

/*! *********************************************************************************
* \brief        Send Potentiometry Calibration Points
********************************************************************************** */
void sendPotentiometryCalibrationAnswer (void)
{
	BYTES[0]  = ((potentiometryCalibration[0]&0xFF0)>>4);
	BYTES[1]  = ((potentiometryCalibration[0]&0x00F)<<4)+((potentiometryCalibration[1]&0xF00)>>8);
	BYTES[2]  = (potentiometryCalibration[1]&0x0FF);
	BYTES[3]  = ((potentiometryCalibration[2]&0xFF0)>>4);
	BYTES[4]  = ((potentiometryCalibration[2]&0x00F)<<4)+((potentiometryCalibration[3]&0xF00)>>8);
	BYTES[5]  = (potentiometryCalibration[3]&0x0FF);
	BYTES[6]  = ((potentiometryCalibration[4]&0xFF0)>>4);
	BYTES[7]  = ((potentiometryCalibration[4]&0x00F)<<4)+((potentiometryCalibration[5]&0xF00)>>8);
	BYTES[8]  = (potentiometryCalibration[5]&0x0FF);
	BYTES[9]  = ((potentiometryCalibration[6]&0xFF0)>>4);
	BYTES[10] = ((potentiometryCalibration[6]&0x00F)<<4)+((potentiometryCalibration[7]&0xF00)>>8);
	BYTES[11] = (potentiometryCalibration[7]&0x0FF);
	BYTES[12] = ((potentiometryCalibration[8]&0xFF0)>>4);
	BYTES[13] = ((potentiometryCalibration[8]&0x00F)<<4);
	BYTES[14] = 0;

	uint8_t strToSend[20] = {MSG_HEAD, 0x00, 0x00, 0x00, 0x00,
							 0x00, 0x00, 0x00, 0x00, 0x00,
							 0x00, 0x00, 0x00, 0x00, 0x00,
							 0x00, 0x00, 0x00, 0x00, MSG_END};
	strToSend[1] = PotentiometryAutocalibration;

	for(uint8_t i = 0; i < 15; i++)	strToSend[i+2] = BYTES[i];

	uint8_t Calc_Chksum = hermesMessageCalcChecksum(strToSend);
	strToSend[18] = Calc_Chksum;
	setOutputHermesMessage(strToSend);
}

/*! *********************************************************************************
* \brief        Send CE and CM Calibration Points w/ Large Current Scale
********************************************************************************** */
void sendCECMCalibrationAnswerLarge (void)
{
	if(ptr_CECMTransmission==0)
	{
		BYTES[0]  = ((CECalibration[0]&0xFF0)>>4);
		BYTES[1]  = ((CECalibration[0]&0x00F)<<4)+((CECalibration[1]&0xF00)>>8);
		BYTES[2]  = (CECalibration[1]&0x0FF);
		BYTES[3]  = ((CECalibration[2]&0xFF0)>>4);
		BYTES[4]  = ((CECalibration[2]&0x00F)<<4)+((CECalibration[3]&0xF00)>>8);
		BYTES[5]  = (CECalibration[3]&0x0FF);
		BYTES[6]  = ((CECalibration[4]&0xFF0)>>4);
		BYTES[7]  = ((CECalibration[4]&0x00F)<<4)+((CECalibration[5]&0xF00)>>8);
		BYTES[8]  = (CECalibration[5]&0x0FF);
		BYTES[9]  = ((CECalibration[6]&0xFF0)>>4);
		BYTES[10] = ((CECalibration[6]&0x00F)<<4)+((CECalibration[7]&0xF00)>>8);
		BYTES[11] = (CECalibration[7]&0x0FF);
		BYTES[12] = ((CECalibration[8]&0xFF0)>>4);
		BYTES[13] = ((CECalibration[8]&0x00F)<<4)+((CECalibration[9]&0xF00)>>8);
		BYTES[14] = (CECalibration[9]&0x0FF);
		ptr_CECMTransmission++;
	}
	else if(ptr_CECMTransmission==1)
	{
		BYTES[0]  = ((CMLargeCalibration[0]&0xFF0)>>4);
		BYTES[1]  = ((CMLargeCalibration[0]&0x00F)<<4)+((CMLargeCalibration[1]&0xF00)>>8);
		BYTES[2]  = (CMLargeCalibration[1]&0x0FF);
		BYTES[3]  = ((CMLargeCalibration[2]&0xFF0)>>4);
		BYTES[4]  = ((CMLargeCalibration[2]&0x00F)<<4)+((CMLargeCalibration[3]&0xF00)>>8);
		BYTES[5]  = (CMLargeCalibration[3]&0x0FF);
		BYTES[6]  = ((CMLargeCalibration[4]&0xFF0)>>4);
		BYTES[7]  = ((CMLargeCalibration[4]&0x00F)<<4)+((CMLargeCalibration[5]&0xF00)>>8);
		BYTES[8]  = (CMLargeCalibration[5]&0x0FF);
		BYTES[9]  = ((CMLargeCalibration[6]&0xFF0)>>4);
		BYTES[10] = ((CMLargeCalibration[6]&0x00F)<<4)+((CMLargeCalibration[7]&0xF00)>>8);
		BYTES[11] = (CMLargeCalibration[7]&0x0FF);
		BYTES[12] = ((CMLargeCalibration[8]&0xFF0)>>4);
		BYTES[13] = ((CMLargeCalibration[8]&0x00F)<<4)+((CMLargeCalibration[9]&0xF00)>>8);
		BYTES[14] = (CMLargeCalibration[9]&0x0FF);
		ptr_CECMTransmission = 0;
	}

	uint8_t strToSend[20] = {MSG_HEAD, 0x00, 0x00, 0x00, 0x00,
							 0x00, 0x00, 0x00, 0x00, 0x00,
							 0x00, 0x00, 0x00, 0x00, 0x00,
							 0x00, 0x00, 0x00, 0x00, MSG_END};
	strToSend[1] = CECMAutocalibrationLarge;

	for(uint8_t i = 0; i < 15; i++)	strToSend[i+2] = BYTES[i];

	uint8_t Calc_Chksum = hermesMessageCalcChecksum(strToSend);
	strToSend[18] = Calc_Chksum;
	setOutputHermesMessage(strToSend);
}


/*! *********************************************************************************
* \brief        Send CE and CM Calibration Points w/ Precision Current Scale
********************************************************************************** */
void sendCECMCalibrationAnswerPrecision (void)
{
	BYTES[0]  = ((CMPrecisionCalibration[0]&0xFF0)>>4);
	BYTES[1]  = ((CMPrecisionCalibration[0]&0x00F)<<4)+((CMPrecisionCalibration[1]&0xF00)>>8);
	BYTES[2]  = (CMPrecisionCalibration[1]&0x0FF);
	BYTES[3]  = ((CMPrecisionCalibration[2]&0xFF0)>>4);
	BYTES[4]  = ((CMPrecisionCalibration[2]&0x00F)<<4)+((CMPrecisionCalibration[3]&0xF00)>>8);
	BYTES[5]  = (CMPrecisionCalibration[3]&0x0FF);
	BYTES[6]  = ((CMPrecisionCalibration[4]&0xFF0)>>4);
	BYTES[7]  = ((CMPrecisionCalibration[4]&0x00F)<<4)+((CMPrecisionCalibration[5]&0xF00)>>8);
	BYTES[8]  = (CMPrecisionCalibration[5]&0x0FF);
	BYTES[9]  = ((CMPrecisionCalibration[6]&0xFF0)>>4);
	BYTES[10] = ((CMPrecisionCalibration[6]&0x00F)<<4)+((CMPrecisionCalibration[7]&0xF00)>>8);
	BYTES[11] = (CMPrecisionCalibration[7]&0x0FF);
	BYTES[12] = ((CMPrecisionCalibration[8]&0xFF0)>>4);
	BYTES[13] = ((CMPrecisionCalibration[8]&0x00F)<<4)+((CMPrecisionCalibration[9]&0xF00)>>8);
	BYTES[14] = (CMPrecisionCalibration[9]&0x0FF);

	uint8_t strToSend[20] = {MSG_HEAD, 0x00, 0x00, 0x00, 0x00,
							 0x00, 0x00, 0x00, 0x00, 0x00,
							 0x00, 0x00, 0x00, 0x00, 0x00,
							 0x00, 0x00, 0x00, 0x00, MSG_END};
	strToSend[1] = CECMAutocalibrationPrecision;

	for(uint8_t i = 0; i < 15; i++)	strToSend[i+2] = BYTES[i];

	uint8_t Calc_Chksum = hermesMessageCalcChecksum(strToSend);
	strToSend[18] = Calc_Chksum;
	setOutputHermesMessage(strToSend);
}

/*! *********************************************************************************
 * @}
 ********************************************************************************** */
