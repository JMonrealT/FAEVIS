/*
 * Copyright (c) 2015, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "board.h"
#include "fsl_debug_console.h"
#include "fsl_gpio.h"
#include "fsl_dac.h"
#include "fsl_adc16.h"
#include "clock_config.h"
#include "pin_mux.h"
#include "UserFunctions.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
gpio_pin_config_t CD1E_config = {
        kGPIO_DigitalOutput, 0,
    };
gpio_pin_config_t CD12_config = {
        kGPIO_DigitalOutput, 0,
    };
gpio_pin_config_t CD11_config = {
        kGPIO_DigitalOutput, 0,
    };
gpio_pin_config_t CD10_config = {
        kGPIO_DigitalOutput, 0,
    };
gpio_pin_config_t CD2E_config = {
        kGPIO_DigitalOutput, 0,
    };
gpio_pin_config_t CD22_config = {
        kGPIO_DigitalOutput, 0,
    };
gpio_pin_config_t CD21_config = {
        kGPIO_DigitalOutput, 0,
    };
gpio_pin_config_t CD20_config = {
        kGPIO_DigitalOutput, 0,
    };
gpio_pin_config_t CD3E_config = {
        kGPIO_DigitalOutput, 0,
    };
gpio_pin_config_t CD32_config = {
        kGPIO_DigitalOutput, 0,
    };
gpio_pin_config_t CD31_config = {
        kGPIO_DigitalOutput, 0,
    };
gpio_pin_config_t CD30_config = {
        kGPIO_DigitalOutput, 0,
    };
#if CURRENT_SCALE_SELECTOR
gpio_pin_config_t SEL_CM_config = {
        kGPIO_DigitalOutput, 0,
    };
#endif

/*******************************************************************************
 * Functions
 ******************************************************************************/

void delay(void)
{
    volatile uint32_t i = 0;
    for (i = 0; i < 800000; ++i)
    {
        __asm("NOP"); /* delay */
    }
}

void configAllGPIO(void)
{
	GPIO_PinInit(GPIO_CD1E, PIN_CD1E, &CD1E_config);
	GPIO_PinInit(GPIO_CD12, PIN_CD12, &CD12_config);
	GPIO_PinInit(GPIO_CD11, PIN_CD11, &CD11_config);
	GPIO_PinInit(GPIO_CD10, PIN_CD10, &CD10_config);
	GPIO_PinInit(GPIO_CD2E, PIN_CD2E, &CD2E_config);
	GPIO_PinInit(GPIO_CD22, PIN_CD22, &CD22_config);
	GPIO_PinInit(GPIO_CD21, PIN_CD21, &CD21_config);
	GPIO_PinInit(GPIO_CD20, PIN_CD20, &CD20_config);
	GPIO_PinInit(GPIO_CD3E, PIN_CD3E, &CD3E_config);
	GPIO_PinInit(GPIO_CD32, PIN_CD32, &CD32_config);
	GPIO_PinInit(GPIO_CD31, PIN_CD31, &CD31_config);
	GPIO_PinInit(GPIO_CD30, PIN_CD30, &CD30_config);
	#if CURRENT_SCALE_SELECTOR
	GPIO_PinInit(GPIO_SEL_CM, PIN_SEL_CM, &SEL_CM_config);
	#endif
}

void setGPIO(uint8_t selGPIO, uint8_t state)
{
	switch(selGPIO)
	{
		case CD1E:
			GPIO_WritePinOutput(GPIO_CD1E, PIN_CD1E, state);
			break;
		case CD12:
			GPIO_WritePinOutput(GPIO_CD12, PIN_CD12, state);
			break;
		case CD11:
			GPIO_WritePinOutput(GPIO_CD11, PIN_CD11, state);
			break;
		case CD10:
			GPIO_WritePinOutput(GPIO_CD10, PIN_CD10, state);
			break;
		case CD2E:
			GPIO_WritePinOutput(GPIO_CD2E, PIN_CD2E, state);
			break;
		case CD22:
			GPIO_WritePinOutput(GPIO_CD22, PIN_CD22, state);
			break;
		case CD21:
			GPIO_WritePinOutput(GPIO_CD21, PIN_CD21, state);
			break;
		case CD20:
			GPIO_WritePinOutput(GPIO_CD20, PIN_CD20, state);
			break;
		case CD3E:
			GPIO_WritePinOutput(GPIO_CD3E, PIN_CD3E, state);
			break;
		case CD32:
			GPIO_WritePinOutput(GPIO_CD32, PIN_CD32, state);
			break;
		case CD31:
			GPIO_WritePinOutput(GPIO_CD31, PIN_CD31, state);
			break;
		case CD30:
			GPIO_WritePinOutput(GPIO_CD30, PIN_CD30, state);
			break;
		#if CURRENT_SCALE_SELECTOR
		case SEL_CM:
			GPIO_WritePinOutput(BOARD_INITPINS_SEL_CM_GPIO, BOARD_INITPINS_SEL_CM_PIN, state);
			break;
		#endif
	}
}

void setAllGPIO(uint8_t state)
{
	setGPIO(CD1E, state);
	setGPIO(CD12, state);
	setGPIO(CD11, state);
	setGPIO(CD10, state);
	setGPIO(CD2E, state);
	setGPIO(CD22, state);
	setGPIO(CD21, state);
	setGPIO(CD20, state);
	setGPIO(CD3E, state);
	setGPIO(CD32, state);
	setGPIO(CD31, state);
	setGPIO(CD30, state);
}

void setGPIORelay (uint8_t relay, uint8_t state)
{
	setAllGPIO(DOWN);
	switch(relay)
	{
		case RELAY1:
		{
			if(state == UP)
			{
				setGPIO(CD12, LOW);
				setGPIO(CD11, LOW);
				setGPIO(CD10, LOW);
				setGPIO(CD1E, HIGH); setGPIO(CD2E, LOW); setGPIO(CD3E, LOW);
			}
			if(state == DOWN)
			{
				setGPIO(CD12, LOW);
				setGPIO(CD11, LOW);
				setGPIO(CD10, HIGH);
				setGPIO(CD1E, HIGH); setGPIO(CD2E, LOW); setGPIO(CD3E, LOW);
			}
			break;
		}
		case RELAY2:
		{
			if(state == UP)
			{
				setGPIO(CD12, LOW);
				setGPIO(CD11, HIGH);
				setGPIO(CD10, LOW);
				setGPIO(CD1E, HIGH); setGPIO(CD2E, LOW); setGPIO(CD3E, LOW);
			}
			if(state == DOWN)
			{
				setGPIO(CD12, LOW);
				setGPIO(CD11, HIGH);
				setGPIO(CD10, HIGH);
				setGPIO(CD1E, HIGH); setGPIO(CD2E, LOW); setGPIO(CD3E, LOW);
			}
			break;
		}
		case RELAY3:
		{
			if(state == UP)
			{
				setGPIO(CD12, HIGH);
				setGPIO(CD11, LOW);
				setGPIO(CD10, LOW);
				setGPIO(CD1E, HIGH); setGPIO(CD2E, LOW); setGPIO(CD3E, LOW);
			}
			if(state == DOWN)
			{
				setGPIO(CD12, HIGH);
				setGPIO(CD11, LOW);
				setGPIO(CD10, HIGH);
				setGPIO(CD1E, HIGH); setGPIO(CD2E, LOW); setGPIO(CD3E, LOW);
			}
			break;
		}
		case RELAY4:
		{
			if(state == UP)
			{
				setGPIO(CD12, HIGH);
				setGPIO(CD11, HIGH);
				setGPIO(CD10, LOW);
				setGPIO(CD1E, HIGH); setGPIO(CD2E, LOW); setGPIO(CD3E, LOW);
			}
			if(state == DOWN)
			{
				setGPIO(CD12, HIGH);
				setGPIO(CD11, HIGH);
				setGPIO(CD10, HIGH);
				setGPIO(CD1E, HIGH); setGPIO(CD2E, LOW); setGPIO(CD3E, LOW);
			}
			break;
		}
		case RELAY5:
		{
			if(state == UP)
			{
				setGPIO(CD22, LOW);
				setGPIO(CD21, LOW);
				setGPIO(CD20, LOW);
				setGPIO(CD1E, LOW); setGPIO(CD2E, HIGH); setGPIO(CD3E, LOW);
			}
			if(state == DOWN)
			{
				setGPIO(CD22, LOW);
				setGPIO(CD21, LOW);
				setGPIO(CD20, HIGH);
				setGPIO(CD1E, LOW); setGPIO(CD2E, HIGH); setGPIO(CD3E, LOW);
			}
			break;
		}
		case RELAY6:
		{
			if(state == UP)
			{
				setGPIO(CD22, LOW);
				setGPIO(CD21, HIGH);
				setGPIO(CD20, LOW);
				setGPIO(CD1E, LOW); setGPIO(CD2E, HIGH); setGPIO(CD3E, LOW);
			}
			if(state == DOWN)
			{
				setGPIO(CD22, LOW);
				setGPIO(CD21, HIGH);
				setGPIO(CD20, HIGH);
				setGPIO(CD1E, LOW); setGPIO(CD2E, HIGH); setGPIO(CD3E, LOW);
			}
			break;
		}
		case RELAY7:
		{
			if(state == UP)
			{
				setGPIO(CD22, HIGH);
				setGPIO(CD21, LOW);
				setGPIO(CD20, LOW);
				setGPIO(CD1E, LOW); setGPIO(CD2E, HIGH); setGPIO(CD3E, LOW);
			}
			if(state == DOWN)
			{
				setGPIO(CD22, HIGH);
				setGPIO(CD21, LOW);
				setGPIO(CD20, HIGH);
				setGPIO(CD1E, LOW); setGPIO(CD2E, HIGH); setGPIO(CD3E, LOW);
			}
			break;
		}
		case RELAY8:
		{
			if(state == UP)
			{
				setGPIO(CD22, HIGH);
				setGPIO(CD21, HIGH);
				setGPIO(CD20, LOW);
				setGPIO(CD1E, LOW); setGPIO(CD2E, HIGH); setGPIO(CD3E, LOW);
			}
			if(state == DOWN)
			{
				setGPIO(CD22, HIGH);
				setGPIO(CD21, HIGH);
				setGPIO(CD20, HIGH);
				setGPIO(CD1E, LOW); setGPIO(CD2E, HIGH); setGPIO(CD3E, LOW);
			}
			break;
		}
		case RELAY9:
		{
			if(state == UP)
			{
				setGPIO(CD32, LOW);
				setGPIO(CD31, LOW);
				setGPIO(CD30, LOW);
				setGPIO(CD1E, LOW); setGPIO(CD2E, LOW); setGPIO(CD3E, HIGH);
			}
			if(state == DOWN)
			{
				setGPIO(CD32, LOW);
				setGPIO(CD31, LOW);
				setGPIO(CD30, HIGH);
				setGPIO(CD1E, LOW); setGPIO(CD2E, LOW); setGPIO(CD3E, HIGH);
			}
			break;
		}
		case RELAY10:
		{
			if(state == UP)
			{
				setGPIO(CD32, LOW);
				setGPIO(CD31, HIGH);
				setGPIO(CD30, LOW);
				setGPIO(CD1E, LOW); setGPIO(CD2E, LOW); setGPIO(CD3E, HIGH);
			}
			if(state == DOWN)
			{
				setGPIO(CD32, LOW);
				setGPIO(CD31, HIGH);
				setGPIO(CD30, HIGH);
				setGPIO(CD1E, LOW); setGPIO(CD2E, LOW); setGPIO(CD3E, HIGH);
			}
			break;
		}
		case RELAYSTOP:
		{
			setAllGPIO(LOW);
		}
		break;
		default:
		{
			setAllGPIO(LOW);
		}
		break;
	}
}

/*! *********************************************************************************
 * @}
 ********************************************************************************** */
