#ifndef _USERFUNCTIONS_H_
#define _USERFUNCTIONS_H_

#include "fsl_adc16.h"
/*************************************************************************************
**************************************************************************************
* Public macros
**************************************************************************************
*************************************************************************************/

/* A 1 NO PERMITE DEBUGGEAR, COMPARTE PIN CON UART*/
#define CURRENT_SCALE_SELECTOR 1

#define OUT DAC0
#define ADC_BASE ADC0
#define ADC_GROUP 0U
#define ADC_CM 3U	/* PTB2, SE3 */
#define ADC_WE 2U	/* PTB3, SE2 */
#define ADC_CE 1U	/* PTB1, SE1 */

#define HIGH 1
#define LOW 0

#define SEL_CM 	 00
#define CD1E 	 13
#define CD12 	 12
#define CD11 	 11
#define CD10 	 10
#define CD2E 	 23
#define CD22 	 22
#define CD21 	 21
#define CD20 	 20
#define CD3E 	 33
#define CD32 	 32
#define CD31 	 31
#define CD30 	 30

#if CURRENT_SCALE_SELECTOR
#define GPIO_SEL_CM BOARD_INITPINS_SEL_CM_GPIO
#endif
#define GPIO_CD1E BOARD_INITPINS_CD1E_GPIO
#define GPIO_CD12 BOARD_INITPINS_CD12_GPIO
#define GPIO_CD11 BOARD_INITPINS_CD11_GPIO
#define GPIO_CD10 BOARD_INITPINS_CD10_GPIO
#define GPIO_CD2E BOARD_INITPINS_CD2E_GPIO
#define GPIO_CD22 BOARD_INITPINS_CD22_GPIO
#define GPIO_CD21 BOARD_INITPINS_CD21_GPIO
#define GPIO_CD20 BOARD_INITPINS_CD20_GPIO
#define GPIO_CD3E BOARD_INITPINS_CD3E_GPIO
#define GPIO_CD32 BOARD_INITPINS_CD32_GPIO
#define GPIO_CD31 BOARD_INITPINS_CD31_GPIO
#define GPIO_CD30 BOARD_INITPINS_CD30_GPIO

#if CURRENT_SCALE_SELECTOR
#define PIN_SEL_CM BOARD_INITPINS_SEL_CM_PIN
#endif
#define PIN_CD1E BOARD_INITPINS_CD1E_PIN
#define PIN_CD12 BOARD_INITPINS_CD12_PIN
#define PIN_CD11 BOARD_INITPINS_CD11_PIN
#define PIN_CD10 BOARD_INITPINS_CD10_PIN
#define PIN_CD2E BOARD_INITPINS_CD2E_PIN
#define PIN_CD22 BOARD_INITPINS_CD22_PIN
#define PIN_CD21 BOARD_INITPINS_CD21_PIN
#define PIN_CD20 BOARD_INITPINS_CD20_PIN
#define PIN_CD3E BOARD_INITPINS_CD3E_PIN
#define PIN_CD32 BOARD_INITPINS_CD32_PIN
#define PIN_CD31 BOARD_INITPINS_CD31_PIN
#define PIN_CD30 BOARD_INITPINS_CD30_PIN

#define RELAY1 1
#define RELAY2 2
#define RELAY3 3
#define RELAY4 4
#define RELAY5 5
#define RELAY6 6
#define RELAY7 7
#define RELAY8 8
#define RELAY9 9
#define RELAY10 10
#define RELAYSTOP 0

#define UP 	   1
#define DOWN   0
/************************************************************************************
*************************************************************************************
* Public memory declarations
*************************************************************************************
********************************************************************************** */

/************************************************************************************
*************************************************************************************
* Public prototypes
*************************************************************************************
************************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

void delay (void);

void configAllGPIO (void);
void setGPIO (uint8_t selGPIO, uint8_t state);
void setAllGPIO (uint8_t state);
void setGPIORelay (uint8_t relay, uint8_t state);

#ifdef __cplusplus
}
#endif 


#endif /* _USERFUNCTIONS_H_ */

/*! *********************************************************************************
 * @}
 ********************************************************************************** */
