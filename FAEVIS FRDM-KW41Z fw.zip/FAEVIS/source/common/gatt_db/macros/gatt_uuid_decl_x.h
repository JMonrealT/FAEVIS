/*
*
* Custom 128-bit UUIDs declaration
*
*/
        
#define UUID128(name, ...)\
    extern uint8_t name[16];

#include "gatt_uuid128.h"

#undef UUID128

