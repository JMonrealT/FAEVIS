/*
*
* Custom 128-bit UUIDs allocation
*
*/
        
#define UUID128(name, ...)\
    uint8_t name[16] = { __VA_ARGS__ };

#include "gatt_uuid128.h"

#undef UUID128

