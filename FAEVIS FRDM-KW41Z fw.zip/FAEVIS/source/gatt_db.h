PRIMARY_SERVICE(service_gatt, gBleSig_GenericAttributeProfile_d)
        CHARACTERISTIC(char_service_changed, gBleSig_GattServiceChanged_d, (gGattCharPropRead_c | gGattCharPropNotify_c) )
            VALUE(value_service_changed, gBleSig_GattServiceChanged_d, (gPermissionNone_c), 4, 0x00, 0x00, 0x00, 0x00)
            CCCD(cccd_service_changed)

PRIMARY_SERVICE(service_gap, gBleSig_GenericAccessProfile_d)
    CHARACTERISTIC(char_device_name, gBleSig_GapDeviceName_d, (gGattCharPropRead_c) )
            VALUE(value_device_name, gBleSig_GapDeviceName_d, (gPermissionFlagReadable_c), 16, "ZOIS_BLE")
    CHARACTERISTIC(char_appearance, gBleSig_GapAppearance_d, (gGattCharPropRead_c) )
            VALUE(value_appearance, gBleSig_GapAppearance_d, (gPermissionFlagReadable_c), 2, 0x00, 0x00)

PRIMARY_SERVICE_UUID128(service_hermes, uuid_service_hermes)
	CHARACTERISTIC_UUID128(char_hermes_message, uuid_characteristic_hermes_message, (gGattCharPropRead_c | gGattCharPropNotify_c | gGattCharPropWriteWithoutRsp_c))
		VALUE_UUID128(value_hermes_message, uuid_characteristic_hermes_message, (gPermissionFlagReadable_c | gPermissionFlagWritable_c), 20, 0x00)
		CCCD(cccd_hermes)

