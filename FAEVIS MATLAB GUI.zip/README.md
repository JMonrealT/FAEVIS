Steps to launch the GUI:

1. Launch MATLAB environment.
2. Include "functions" folder and subfolder.
3. Execute "part01_general.m".

Parts 1, 2, 3, and 8 are complete. They include electrochemical experiences design and execution, and calibration.
Parts 4, 5, and 6 are partially developed and not functional. They include electrostimulation design and execution, and combined experiences design.
Part 7, combined experiences execution, is yet to be developed.

March 31st, 2023. Javier Monreal Trigo. https://github.com/JMonrealT/FAEVIS