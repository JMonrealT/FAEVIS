%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief receives the current waveform adquired. 	 %
%   @version 26th February 2020                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function currentWaveformReception(handles)
global currentNsequence txStopTransmission voltageCENsequence
global rxBuffer CurrentWaveform CurrentWaveform_ptr alternationFlag
global CalibrationLoaded CMLValuesRead RWEREL EQ1ES0
global CMPValuesRead RWEREP CurrentScale xCalibrated CurrentWaveform_raw
pointsReceived = bitand(rxBuffer(3),hex2dec('F0'))/16;
inputNseq = bitand(rxBuffer(3),hex2dec('0F'));

if(txStopTransmission == 0)
    %if(CurrentWaveform_ptr<10000)
        if(currentNsequence == inputNseq)
            if(currentNsequence+1>15)
                currentNsequence = 0;
            else
                currentNsequence = currentNsequence + 1;
            end

            if(pointsReceived>0)
                CurrentWaveform(CurrentWaveform_ptr) = rxBuffer(4)*(2^4)+...
                    bitand(rxBuffer(5),hex2dec('F0'))*(2^(-4));
            end
            if(pointsReceived>1)
                CurrentWaveform(CurrentWaveform_ptr+1) = ...
                    bitand(rxBuffer(5),hex2dec('0F'))*(2^8)+rxBuffer(6);
            end
            if(pointsReceived>2)
                CurrentWaveform(CurrentWaveform_ptr+2) = rxBuffer(7)*(2^4)+...
                    bitand(rxBuffer(8),hex2dec('F0'))*(2^(-4));
            end
            if(pointsReceived>3)
                CurrentWaveform(CurrentWaveform_ptr+3) = ...
                    bitand(rxBuffer(8),hex2dec('0F'))*(2^8)+rxBuffer(9);
            end
            if(pointsReceived>4)
                CurrentWaveform(CurrentWaveform_ptr+4) = rxBuffer(10)*(2^4)+...
                    bitand(rxBuffer(11),hex2dec('F0'))*(2^(-4));
            end
            if(pointsReceived>5)
                CurrentWaveform(CurrentWaveform_ptr+5) = ...
                    bitand(rxBuffer(11),hex2dec('0F'))*(2^8)+rxBuffer(12);
            end
            if(pointsReceived>6)
                CurrentWaveform(CurrentWaveform_ptr+6) = rxBuffer(13)*(2^4)+...
                    bitand(rxBuffer(14),hex2dec('F0'))*(2^(-4));
            end
            if(pointsReceived>7)
                CurrentWaveform(CurrentWaveform_ptr+7) = ...
                    bitand(rxBuffer(14),hex2dec('0F'))*(2^8)+rxBuffer(15);
            end
            if(pointsReceived>8)
                CurrentWaveform(CurrentWaveform_ptr+8) = rxBuffer(16)*(2^4)+...
                    bitand(rxBuffer(17),hex2dec('F0'))*(2^(-4));
            end
            if(pointsReceived>9)
                CurrentWaveform(CurrentWaveform_ptr+9) = ...
                    bitand(rxBuffer(17),hex2dec('0F'))*(2^8)+rxBuffer(18);
            end
            CurrentWaveform_ptr = CurrentWaveform_ptr + pointsReceived;
            %CurrentWaveform_ptr
            if(CalibrationLoaded)
                x = [256,768,1280,1792,2048,2304,2816,3328,3840];
                x = x+(x-xCalibrated);
                if(CurrentScale==17) % large
                    v = CMLValuesRead;
                    Rr = RWEREL;
                else
                    v = CMPValuesRead;
                    Rr = RWEREP/100;
                end
                xq = 256:3840;
                vq = interp1(x,v,xq,'spline'); 
                xq = [1:255 xq]; vq = [(1:255)*0 vq]; 
                % plot(x,v,'o',xq,vq,':.');
                for i = 1:pointsReceived
                    if(and(CurrentWaveform(CurrentWaveform_ptr-i)>256,...
                            CurrentWaveform(CurrentWaveform_ptr-i)<3840)) 
                        dist = abs(vq - CurrentWaveform(CurrentWaveform_ptr-i));
                        minDist = min(dist);
                        CurrentWaveform(CurrentWaveform_ptr-i) = find(dist == minDist)...
                            -(1-Rr)*(CurrentWaveform(CurrentWaveform_ptr-i)-2048);
                    end
                end
            end
%             if(CurrentWaveform_ptr-1-pointsReceived>5)
%                 for i = (1:pointsReceived)+CurrentWaveform_ptr-1-pointsReceived-2
%                     if((abs(CurrentWaveform(i-2)-CurrentWaveform(i-1))<2))
%                         if((abs(CurrentWaveform(i+2)-CurrentWaveform(i+1))<2))
%                             filteredNoise(i) = CurrentWaveform(i-1);
%                         else
%                             filteredNoise(i) = CurrentWaveform(i);
%                         end
%                     else
%                         filteredNoise(i) = CurrentWaveform(i);
%                     end
%                 end
%                 i = (1:pointsReceived)+CurrentWaveform_ptr-1-pointsReceived-2;
%                 CurrentWaveform(i) = filteredNoise(i);
%             end
            CurrentWaveform_raw((CurrentWaveform_ptr-pointsReceived):(CurrentWaveform_ptr-1)) = ...
                CurrentWaveform((CurrentWaveform_ptr-pointsReceived):(CurrentWaveform_ptr-1));
            if(CurrentWaveform_ptr-1-pointsReceived>5)
                for i = (1:pointsReceived)+CurrentWaveform_ptr-1-pointsReceived-2
                    filteredNoise(i) = mean(CurrentWaveform_raw((i-4):i));
                end
                i = (1:pointsReceived)+CurrentWaveform_ptr-1-pointsReceived-2;
                CurrentWaveform(i) = filteredNoise(i);
            end
        end
        if(EQ1ES0)
            rxState(handles,'sending'); 
            sendHermesMessage('counterAck',voltageCENsequence,handles);
            rxState(handles,'waiting'); 
            alternationFlag = 0;
        else
            rxState(handles,'sending');     
            sendHermesMessage('currentAck',currentNsequence,handles);
            rxState(handles,'waiting');
        end
    %end
end