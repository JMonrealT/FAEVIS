%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief receives the counterelectrode voltage     %
%          and working electrode current data        %
%          waveforms adquired.  	                 %
%   @version 13th December 2019                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function dataCEndCurrentReception(handles)
global eqTransmission CERequest CurrentRequest alternationFlag
    if(eqTransmission==0)
        CERequest = 1; CurrentRequest = 0;
        rxState(handles,'sending'); 
        sendHermesMessage('requestCounterData',0,handles);
        rxState(handles,'waiting');
    elseif(and(CERequest,~CurrentRequest))
        voltageCEWaveformReception(handles);
        CurrentRequest = 1; 
    else
        if(~alternationFlag) % 0 CE, 1 Current
            voltageCEWaveformReception(handles);
        else
            currentWaveformReception(handles);
        end
    end
end