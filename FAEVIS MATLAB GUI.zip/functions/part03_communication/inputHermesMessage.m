%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief handles reception of Hermes protocol.  	 %
%   @version 15th July 2020                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function inputHermesMessage(hObject, eventdata, handles)
global PORT rxBuffer rxWaiting waveformNsequence PotEnded AEEnded RestTime
global pointsToSend WAVEFORM_ptr ExperienceMode txStopTransmission Iterations
global PotentiometryRequested PotentiometryTimeout PotentiometryTimeout_250ms
global PotentiometryWaveform_ptr CurrentWaveform_ptr CEVoltageWaveform_ptr
global CurrentWaveform CEVoltageWaveform PotentiometryWaveform RUA EQ1ES0
global tp tv tc stateFSM WaveformLoadRequested WaveformSent ActiveExperienceEnd
global NumberOfPeriods PeriodNumberOfPoints SampleTime eqTransmission Iterations_cnt
global CERequest CurrentRequest PotentiometrySampleTime limitPotSampleTime_ms
global EndedActiveTimeFlag NumberOfPeriodsMultiplier

global Timer_1s

pause(0);
tmphandles = guihandles(handles.psbStopExperience);
if(tmphandles.psbStopExperience.Value)
    while(PORT.BytesAvailable>0)
        rxBuffer=fread(PORT,20);
    end
    if(isvalid(Timer_1s))
        stop(Timer_1s); delete(Timer_1s); 
        clear Timer_1s
    else
        clear Timer_1s
    end
    sendHermesMessage('stopExperience',0,handles);
    rxWaiting = 1;
elseif(rxWaiting)
    N = PORT.BytesAvailable;
    if N>=20
        rxState(handles,'idle');
        rxBuffer=fread(PORT,20);
        calcChecksum = sum(rxBuffer(1:18));
        calcChecksum = mod(calcChecksum,256);
        if(calcChecksum ~= rxBuffer(19))
            rxState(handles,'sending');
            sendHermesMessage('error');
            rxState(handles,'waiting');
        end
        if(calcChecksum == rxBuffer(19))
            switch rxBuffer(2)
                case hex2dec('11')
                    RUA = 1;
                    handles.phbConnectCOM.ForegroundColor = [0 0.7 0];
                    handles.indWaveformLoaded.BackgroundColor = [0 0.3 0];
                    handles.pumAvailableCOMs.Enable = 'off';
                    handles.phbScanCOMs.Enable = 'off';
                case hex2dec('C1')
                    handles.indExperienceStatus.BackgroundColor = [0 0.3 0];
                    stateFSM = 1;
                    stateMachine(handles)
                case hex2dec('C2')
                    if(WaveformLoadRequested)
                        WaveformLoadRequested = 0;
                        rxState(handles,'sending');
                        sendHermesMessage('setWaveform',0,handles);
                        rxState(handles,'waiting');
                    else
                        handles.indExperienceStatus.BackgroundColor = [0 0.3 0];
                        stateFSM = 1;
                        stateMachine(handles)
                    end
                case hex2dec('58')
                    inputNsequence = bitand(rxBuffer(3),hex2dec('0F'));
                    if(inputNsequence == waveformNsequence)
                        rxState(handles,'sending');
                        waveformTransmision(handles);
                        if(~WaveformSent)
                            rxState(handles,'waiting');
                        else
                            rxState(handles,'idle');
                        end
                    else
                        waveformNsequence = waveformNsequence - 1;
                        WAVEFORM_ptr = WAVEFORM_ptr - pointsToSend;
                        rxState(handles,'sending');
                        waveformTransmision(handles);
                        rxState(handles,'waiting');
                    end
                    handles.indExperienceStatus.BackgroundColor = [0 0.3 0];
                case hex2dec('77')
                    rxState(handles,'idle');
                    stateFSM = 0; txStopTransmission = 0;
                    if(WaveformLoadRequested)
                        rxState(handles,'sending');
                        sendHermesMessage('setVoltammetryConfiguration',0,handles);
                        rxState(handles,'waiting');
                        handles.indYellowLoading.Visible = 'off';
                        handles.indWaveformLoaded.BackgroundColor = [0 0.3 0];
                        handles.psbStartExperience.Enable = 'off';
                        handles.phbSaveResults.Enable = 'off';
                        handles.rdbPotentiometryMode.Enable = 'off';
                        handles.rdbVoltageApplication.Enable = 'off';     
                        if(~EQ1ES0)
                            handles.rdbLargeScale.Enable = 'off';
                            handles.rdbPrecisionScale.Enable = 'off';
                        end
                    else
                        pause(0.6);
                        allInteractivity(handles,'on');
                        handles.psbStartExperience.Enable = 'on';
                        handles.phbSaveResults.Enable = 'on';
                        if(strcmp(ExperienceMode,'Potentiometry'))   
                            PotEnded = 1;
                        else
                            AEEnded = 1;
                        end
                    end
                    pause(0.2);
                case hex2dec('55')         
                    pause(3);
                    rxState(handles,'sending');
                    if(and(~EQ1ES0,Iterations_cnt==0))
                        computePeriod();
                    end
                    handles.indExperienceStatus.BackgroundColor = [0 1 0];
                    if(strcmp(ExperienceMode,'Active'))
                        auxiliar_flag = 0;
                        if(and(~EQ1ES0,Iterations_cnt==0))
                            auxiliar_flag = 1;
                        end
                        if(EQ1ES0)
                            auxiliar_flag = 1;
                        end
                        if(auxiliar_flag)
                            tv = 0; tc = 0;
                            CurrentWaveform_ptr = 1; CEVoltageWaveform_ptr = 1;
                            % CurrentWaveform = 0; CEVoltageWaveform = 0;
                            CurrentWaveform = zeros(1,1e6);
                            CurrentWaveform(:) = NaN;
                            CEVoltageWaveform = zeros(1,1e6);
                            CEVoltageWaveform(:) = NaN;
                        end
                        time = double(SampleTime)/1e6*PeriodNumberOfPoints*NumberOfPeriods*10^NumberOfPeriodsMultiplier;
                        if(~EQ1ES0)
                            time = (time + RestTime)*Iterations;
                        end
                    else
                        time = PotentiometryTimeout;
                        tp = 0; PotentiometryWaveform_ptr = 1;
                        % PotentiometryWaveform = 0;
                        PotentiometryWaveform = zeros(1,1e5);
                        PotentiometryWaveform(:) = NaN;
                        PotentiometryRequested = 0;
                    end
                    handles.lblTimeToEnd.String = ...
                    strcat(datestr(clock,'dd/mm'),{' '},datestr(addtodate(datenum(datestr(...
                    clock,'HH:MM:SS'),'HH:MM:SS'),time,'second'),'HH:MM:SS')); 
                    startActiveTimeTimer(handles);
                    stateFSM = 2;
                    stateMachine(handles);
                case hex2dec('BB')
                    rxState(handles,'idle');
                    handles.indExperienceStatus.BackgroundColor = [0 0.3 0];
                    handles.lblTimeToEnd.String = ' ';
                    sendHermesMessage('stopTransmission',0,handles);
                    if(~EQ1ES0)
                        handles.rdbLargeScale.Enable = 'on';
                        handles.rdbPrecisionScale.Enable = 'on';
                    end
                    rxWaiting = 1;
                case hex2dec('17')
                    PotEnded = 0;
                    PotentiometryRequested = 1;
                    stateMachine(handles);
                case hex2dec('27')
                    AEEnded = 0;
                    eqTransmission = 1; 
                    stateMachine(handles);
                case hex2dec('37')
                    AEEnded = 0;
                    eqTransmission = 1;                
                    stateMachine(handles);
                case hex2dec('8D')
                    stateMachine(handles);
                case hex2dec('EE')
                    switch rxBuffer(3)
                        case hex2dec('55')
                            handles.psbStartExperience.Enable = 'on';
                            handles.phbSaveResults.Enable = 'on';
                            handles.rdbPotentiometryMode.Enable = 'on';
                            handles.rdbVoltageApplication.Enable = 'on';
                            allInteractivity(handles,'on');
                            handles.phbLoadWaveform.Enable = 'on';
                            errorSound(); warndlg('First, load experience.');
                        case hex2dec('C1')   
                            rxState(handles,'idle');
                        case hex2dec('C2')   
                            rxState(handles,'idle');
                        case hex2dec('58')
                            waveformNsequence = 0;
                            WAVEFORM_ptr = 1;
                            rxState(handles,'idle');
                        case hex2dec('1D')
                            rxState(handles,'idle');
                            StartTimer_1s(handles);
                        case hex2dec('2D')
                            rxState(handles,'idle');
                            StartTimer_1s(handles);
                        case hex2dec('3D')
                            rxState(handles,'idle');
                            StartTimer_1s(handles);
                        case hex2dec('17')
                            if(~EndedActiveTimeFlag)
                                rxState(handles,'idle');
                                StartTimer_1s(handles);
                            else
                                rxState(handles,'sending');
                                sendHermesMessage('RestartMeasurement',0,handles);
                                rxState(handles,'waiting');
                            end
                        case hex2dec('27')
                            if(~EndedActiveTimeFlag)
                                rxState(handles,'idle');
                                StartTimer_1s(handles);
                            else
                                rxState(handles,'sending');
                                sendHermesMessage('RestartMeasurement',0,handles);
                                rxState(handles,'waiting');
                            end
                        case hex2dec('37')
                            if(~EndedActiveTimeFlag)
                                rxState(handles,'idle');
                                StartTimer_1s(handles);
                            else
                                rxState(handles,'sending');
                                sendHermesMessage('RestartMeasurement',0,handles);
                                rxState(handles,'waiting');
                            end
                        case hex2dec('1E')
                            PotEnded = 1;
                            PotentiometryRequested = 0;
                            rxState(handles,'idle');
                            stateFSM = 0;
                            if(and(and(PotentiometryWaveform_ptr==1000+1,...
                                    PotentiometrySampleTime<limitPotSampleTime_ms),...
                                    (PotentiometryWaveform_ptr-1)*...
                                    PotentiometrySampleTime<...
                                    PotentiometryTimeout_250ms*250))
                                errorSound(); warndlg('FAEVIS internal memory full.');
                            end
                            allInteractivity(handles,'on');
                            handles.psbStartExperience.Enable = 'on';
                            handles.phbSaveResults.Enable = 'on';
                            endSound();
                        case hex2dec('2E')
                            if(~EQ1ES0)
                                Iterations_cnt = Iterations_cnt + 1;
                            end
                            AEEnded = 1;
                            ActiveExperienceEnd = 1;
                            plotActiveExperience(handles);
                            eqTransmission = 0;
                            CurrentRequest = 0;
                            rxState(handles,'idle');
                            stateFSM = 0;
                            if(or(EQ1ES0,and(~EQ1ES0,Iterations<=Iterations_cnt)))
                                allInteractivity(handles,'on');
                                handles.psbStartExperience.Enable = 'on';
                                handles.phbSaveResults.Enable = 'on';
                            else
                                StartRestTimer(handles,RestTime);
                            end
                        case hex2dec('3E')
                            if(~EQ1ES0)
                                Iterations_cnt = Iterations_cnt + 1;
                            end
                            if(EQ1ES0)
                                AEEnded = 0;
                                eqTransmission = 1; 
                                stateMachine(handles);
                            else
                                AEEnded = 1;
                                ActiveExperienceEnd = 1;
                                plotActiveExperience(handles);
                                eqTransmission = 0;
                                CurrentRequest = 0;
                                rxState(handles,'idle');
                                stateFSM = 0;
                                if(Iterations<=Iterations_cnt)
                                    allInteractivity(handles,'on');
                                    handles.psbStartExperience.Enable = 'on';
                                    handles.phbSaveResults.Enable = 'on';
                                    handles.rdbLargeScale.Enable = 'on';
                                    handles.rdbPrecisionScale.Enable = 'on';
                                else
                                    StartRestTimer(handles,RestTime);
                                end
                            end
                        case hex2dec('8D')
                            AEEnded = 1;
                            ActiveExperienceEnd = 1;
                            plotActiveExperience(handles);
                            eqTransmission = 0;
                            CurrentRequest = 0;
                            rxState(handles,'idle');
                            stateFSM = 0;
                            if(or(EQ1ES0,and(~EQ1ES0,Iterations<=Iterations_cnt)))
                                allInteractivity(handles,'on');
                                handles.psbStartExperience.Enable = 'on';
                                handles.phbSaveResults.Enable = 'on';
                            else
                                StartRestTimer(handles,RestTime);
                            end  
                        otherwise
                            rxState(handles,'idle');
                    end
                otherwise
                    sendHermesMessage('error');
                    rxState(handles,'waiting');
            end
        end
    end    
end