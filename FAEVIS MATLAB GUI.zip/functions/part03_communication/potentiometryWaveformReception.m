%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                       %
%   @project ZOIS                                      %
%   @brief receives the potentiometryc data adquired.  %
%      It also works for V data in I injection ES.     %
%   @version 25th June 2018                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function potentiometryWaveformReception(handles)
global potentiometryNsequence rxBuffer PotentiometryWaveform3V
global PotentiometryWaveform PotentiometryWaveform_ptr pointsReceived
global CalibrationLoaded POTValuesRead xCalibrated 

pointsReceived = bitand(rxBuffer(3),hex2dec('F0'))/16;
inputNseq = bitand(rxBuffer(3),hex2dec('0F'));

if(potentiometryNsequence == inputNseq)
    if(potentiometryNsequence+1>15)
        potentiometryNsequence = 0;
    else
        potentiometryNsequence = potentiometryNsequence + 1;
    end
    
    if(pointsReceived>0)
        PotentiometryWaveform(PotentiometryWaveform_ptr) = rxBuffer(4)*(2^4)+...
            bitand(rxBuffer(5),hex2dec('F0'))*(2^(-4));
    end
    if(pointsReceived>1)
        PotentiometryWaveform(PotentiometryWaveform_ptr+1) = ...
            bitand(rxBuffer(5),hex2dec('0F'))*(2^8)+rxBuffer(6);
    end
    if(pointsReceived>2)
        PotentiometryWaveform(PotentiometryWaveform_ptr+2) = rxBuffer(7)*(2^4)+...
            bitand(rxBuffer(8),hex2dec('F0'))*(2^(-4));
    end
    if(pointsReceived>3)
        PotentiometryWaveform(PotentiometryWaveform_ptr+3) = ...
            bitand(rxBuffer(8),hex2dec('0F'))*(2^8)+rxBuffer(9);
    end
    if(pointsReceived>4)
        PotentiometryWaveform(PotentiometryWaveform_ptr+4) = rxBuffer(10)*(2^4)+...
            bitand(rxBuffer(11),hex2dec('F0'))*(2^(-4));
    end
    if(pointsReceived>5)
        PotentiometryWaveform(PotentiometryWaveform_ptr+5) = ...
            bitand(rxBuffer(11),hex2dec('0F'))*(2^8)+rxBuffer(12);
    end
    if(pointsReceived>6)
        PotentiometryWaveform(PotentiometryWaveform_ptr+6) = rxBuffer(13)*(2^4)+...
            bitand(rxBuffer(14),hex2dec('F0'))*(2^(-4));
    end
    if(pointsReceived>7)
        PotentiometryWaveform(PotentiometryWaveform_ptr+7) = ...
            bitand(rxBuffer(14),hex2dec('0F'))*(2^8)+rxBuffer(15);
    end
    if(pointsReceived>8)
        PotentiometryWaveform(PotentiometryWaveform_ptr+8) = rxBuffer(16)*(2^4)+...
            bitand(rxBuffer(17),hex2dec('F0'))*(2^(-4));
    end
    if(pointsReceived>9)
        PotentiometryWaveform(PotentiometryWaveform_ptr+9) = ...
            bitand(rxBuffer(17),hex2dec('0F'))*(2^8)+rxBuffer(18);
    end
    
    if(CalibrationLoaded)
        x = [256,768,1280,1792,2048,2304,2816,3328,3840];
        v = POTValuesRead;
        xq = 256:3840;
        vq = interp1(x,v,xq,'spline');
        xq = [1:255 xq]; vq = [(1:255)*0 vq]; 
        % plot(x,v,'o',xq,vq,':.');
        for i = 1:pointsReceived
            if(and(PotentiometryWaveform(PotentiometryWaveform_ptr+i-1)>256,...
                    PotentiometryWaveform(PotentiometryWaveform_ptr+i-1)<3840))
                dist = abs(vq - PotentiometryWaveform(PotentiometryWaveform_ptr+i-1));
                minDist = min(dist);
                ADCValuePOT_woDACcalib = find(dist == minDist);
                ind = (round(double(ADCValuePOT_woDACcalib-256)/512)+1);
                PotentiometryWaveform(PotentiometryWaveform_ptr+i-1) = ...
                   ADCValuePOT_woDACcalib+(x(ind)-xCalibrated(ind))/1.5;
            end
        end
    end
    
%     if(PotentiometryWaveform_ptr-1-pointsReceived>5)
%         filteredNoise = PotentiometryWaveform;
%         for i = (1:pointsReceived)+PotentiometryWaveform_ptr-1-pointsReceived-2
%             if(and(and(...
%                     abs(PotentiometryWaveform(i-2)-PotentiometryWaveform(i-1))<2,...
%                     abs(PotentiometryWaveform(i+2)-PotentiometryWaveform(i+1))<2),...
%                     abs(PotentiometryWaveform(i)-PotentiometryWaveform(i-1))>2 ...
%                 ))
%                    filteredNoise(i) = PotentiometryWaveform(i-1);
%             end
%         end
%         i = (1:pointsReceived)+PotentiometryWaveform_ptr-1-pointsReceived-2;
%         PotentiometryWaveform(i) = filteredNoise(i);
%     end
                    
    f = repmat(5000/4095, PotentiometryWaveform_ptr+pointsReceived-1); f = f(1,:);
    offset = repmat(-2500, PotentiometryWaveform_ptr+pointsReceived-1); offset = offset(1,:);
    PotentiometryWaveform3V = PotentiometryWaveform(1:(PotentiometryWaveform_ptr+pointsReceived-1)).*f+offset;
        
    PotentiometryWaveform_ptr = PotentiometryWaveform_ptr + pointsReceived;
end

rxState(handles,'sending'); 
sendHermesMessage('PotentiometryAck',potentiometryNsequence,handles);
rxState(handles,'waiting');

