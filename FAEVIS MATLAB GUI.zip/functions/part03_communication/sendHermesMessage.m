%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief sends message through Hermes COM. 	 	 %
%   @version 15th July 2020                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function sendHermesMessage(message,Nseq,handles)
global PORT AdditionalInfo NumberOfPeriods txBuffer 
global SampleTime PeriodNumberOfPoints PotentiometryTimeout_250ms
global CurrentScale voltageCENsequence txStopTransmission
global VoltageVariationPotentiometry AveragingSamplesPotentiometry NumberOfPeriodsMultiplier
global currentNsequence PotentiometrySampleTime rxBuffer EQ1ES0
global potentiometryNsequence TimeoutChk AverageChk DACValues Iterations_cnt
global CurrentWaveform PotentiometryWaveform CEVoltageWaveform CorrectOCP
global ActiveExperience PotentiometryExperience WaveformSent DACValue

switch message
    case 'areYouAlive'
        txBuffer = [hex2dec('AA') hex2dec('11')]; 
        txBuffer(3:19) = 0;
        for i=1:18
            txBuffer(19) = txBuffer(19) + txBuffer(i);
        end
        txBuffer(19) = uint8(mod(txBuffer(19),256));
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);
        StartRUAliveTimer(handles);
    case 'setPotentiometryConfiguration'
        txBuffer = [hex2dec('AA') hex2dec('C1')];
        switch PotentiometryExperience
            case 'Dissolution Potentiometry'
                txBuffer(3) = hex2dec('DD');
            case 'Substratum Potentiometry'
                txBuffer(3) = hex2dec('55');    
        end
        if(TimeoutChk)
            txBuffer(4) = uint8(bitand(round(PotentiometryTimeout_250ms),hex2dec('FF00'))/256);
            txBuffer(5) = uint8(bitand(round(PotentiometryTimeout_250ms),hex2dec('00FF')));
        else
            txBuffer(4) = 0;
            txBuffer(5) = 0;
        end
        txBuffer(6) = uint8(bitand(round(PotentiometrySampleTime),hex2dec('FF00'))/256);
        txBuffer(7) = uint8(bitand(round(PotentiometrySampleTime),hex2dec('00FF')));
        if(AverageChk)
            txBuffer(8) = uint8(VoltageVariationPotentiometry);
            txBuffer(9) = uint8(AveragingSamplesPotentiometry);
        else
            txBuffer(8) = 0;
            txBuffer(9) = 0;
        end
        txBuffer(10:18) = 0;
        
        txBuffer(19) = 0;
        for i=1:18
            txBuffer(19) = txBuffer(19) + txBuffer(i);
        end
        txBuffer(19) = uint8(mod(txBuffer(19),256));
        
        txBuffer(20) = hex2dec('FF');
        
        fwrite(PORT,txBuffer);
    case 'setVoltammetryConfiguration'
        txBuffer = [hex2dec('AA') hex2dec('C2')];
        switch ActiveExperience
            case 'Gradient'
                txBuffer(3) = hex2dec('66');
            case 'Current Injection'
                txBuffer(3) = hex2dec('11');   
            case 'Dissolution three-electrodes Voltammetry'
                txBuffer(3) = hex2dec('31');
            case 'Substratum three-electrodes Voltammetry'
                txBuffer(3) = hex2dec('32');
            case 'Dissolution two-electrodes Voltammetry'
                txBuffer(3) = hex2dec('21');
            case 'Substratum two-electrodes Voltammetry'
                txBuffer(3) = hex2dec('22');
        end
        txBuffer(4) = uint8(CorrectOCP);
        txBuffer(5) = uint8(CurrentScale);        
        txBuffer(6) = uint8(bitand(NumberOfPeriods,hex2dec('00FF')));
        txBuffer(7) = uint8(bitand(NumberOfPeriods,hex2dec('0300'))/256+NumberOfPeriodsMultiplier*4);
        txBuffer(8) = uint8(bitand(SampleTime,hex2dec('000000FF')));
        txBuffer(9) = uint8(bitand(SampleTime,hex2dec('0000FF00'))/256);
        txBuffer(10) = uint8(bitand(SampleTime,hex2dec('00FF0000'))/256/256);
        txBuffer(11) = uint8(bitand(uint32(SampleTime),uint32(hex2dec('FF000000')))/256/256/256);
        txBuffer(12) = uint8(bitand(PeriodNumberOfPoints,hex2dec('00FF')));
        txBuffer(13) = uint8(bitand(PeriodNumberOfPoints,hex2dec('FF00'))/256);
        
        txBuffer(14:18) = 0;
        
        txBuffer(19) = 0;
        for i=1:18
            txBuffer(19) = txBuffer(19) + txBuffer(i);
        end
        txBuffer(19) = uint8(mod(txBuffer(19),256));
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);
    case 'setWaveform'
        if(~WaveformSent)
            rxState(handles,'sending');
            waveformTransmision(handles);
            rxState(handles,'waiting');
        end
    case 'stopTransmission'
        txStopTransmission = 1;
        while(PORT.BytesAvailable>0)
            rxBuffer=fread(PORT,20);
        end
        txBuffer = [hex2dec('AA') hex2dec('77')];
        txBuffer(19) = txBuffer(1) + txBuffer(2);
        for i=3:18
            txBuffer(i) = 0;
            txBuffer(19) = txBuffer(19) + txBuffer(i);
        end
        txBuffer(19) = mod(txBuffer(19),256);
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);     
    case 'startExperience'
        txBuffer = [hex2dec('AA') hex2dec('55')];
        txBuffer(19) = txBuffer(1) + txBuffer(2);
        for i=3:18
            txBuffer(i) = 0;
            txBuffer(19) = txBuffer(19) + txBuffer(i);
        end
        txBuffer(19) = mod(txBuffer(19),256);
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);
    case 'stopExperience'
        txBuffer = [hex2dec('AA') hex2dec('BB')];
        txBuffer(19) = txBuffer(1) + txBuffer(2);
        for i=3:18
            txBuffer(i) = 0;
            txBuffer(19) = txBuffer(19) + txBuffer(i);
        end
        txBuffer(19) = mod(txBuffer(19),256);
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);
        StartTimer_1s(handles);
    case 'requestPotentiometryData'
        % PotentiometryWaveform = 0;
        PotentiometryWaveform = zeros(1,1e5);
        PotentiometryWaveform(:) = NaN;
        txBuffer = [hex2dec('AA') hex2dec('1D')];
        txBuffer(19) = txBuffer(1) + txBuffer(2);
        for i=3:18
            txBuffer(i) = 0;
            txBuffer(19) = txBuffer(19) + txBuffer(i);
        end
        txBuffer(19) = mod(txBuffer(19),256);
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);
        potentiometryNsequence = 1;
    case 'requestCurrentData'
        % CurrentWaveform = 0;
        if(or(EQ1ES0,and(~EQ1ES0,Iterations_cnt==0)))
            CurrentWaveform = zeros(1,1e6);
            CurrentWaveform(:) = NaN;
        end
        txBuffer = [hex2dec('AA') hex2dec('2D')];
        txBuffer(19) = txBuffer(1) + txBuffer(2);
        for i=3:18
            txBuffer(i) = 0;
            txBuffer(19) = txBuffer(19) + txBuffer(i);
        end
        txBuffer(19) = mod(txBuffer(19),256);
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);
        currentNsequence = 1;
    case 'requestCounterData'
        % CEVoltageWaveform = 0;
        CEVoltageWaveform = zeros(1,1e6);
        CEVoltageWaveform(:) = NaN;
        txBuffer = [hex2dec('AA') hex2dec('3D')];
        txBuffer(19) = txBuffer(1) + txBuffer(2);
        for i=3:18
            txBuffer(i) = 0;
            txBuffer(19) = txBuffer(19) + txBuffer(i);
        end
        txBuffer(19) = mod(txBuffer(19),256);
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);
        voltageCENsequence = 1;
    case 'PotentiometryAck'
        txBuffer = [hex2dec('AA') hex2dec('17')];
        txBuffer(3) = Nseq;
        txBuffer(19) = txBuffer(1) + txBuffer(2) + txBuffer(3);
        for i=4:18
            txBuffer(i) = 0;
            txBuffer(19) = txBuffer(19) + txBuffer(i);
        end
        txBuffer(19) = mod(txBuffer(19),256);
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);
    case 'currentAck'
        txBuffer = [hex2dec('AA') hex2dec('27')];
        txBuffer(3) = Nseq;
        txBuffer(19) = txBuffer(1) + txBuffer(2) + txBuffer(3);
        for i=4:18
            txBuffer(i) = 0;
            txBuffer(19) = txBuffer(19) + txBuffer(i);
        end
        txBuffer(19) = mod(txBuffer(19),256);
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);  
    case 'counterAck'
        txBuffer = [hex2dec('AA') hex2dec('37')];
        txBuffer(3) = Nseq;
        txBuffer(19) = txBuffer(1) + txBuffer(2) + txBuffer(3);
        for i=4:18
            txBuffer(i) = 0;
            txBuffer(19) = txBuffer(19) + txBuffer(i);
        end
        txBuffer(19) = mod(txBuffer(19),256);
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);     
    case 'setDACValue'
        DACValue = Nseq;
        txBuffer(1) = hex2dec('AA');
        txBuffer(2) = hex2dec('DD');
        txBuffer(3) = bitand(uint16(Nseq),hex2dec('FF'));
        txBuffer(4) = uint16(Nseq)/2^8;
        txBuffer(19) = sum(txBuffer(1:4));
        for i=5:18
            txBuffer(i) = 0;
            txBuffer(19) = txBuffer(19) + txBuffer(i);
        end
        txBuffer(19) = mod(txBuffer(19),256);
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);
    case 'potentiometryAutocalibration'
        txBuffer(1) = hex2dec('AA');
        txBuffer(2) = hex2dec('A1');
        txBuffer(3:18) = 0;
        txBuffer(19) = sum(txBuffer(1:18));
        txBuffer(19) = mod(txBuffer(19),256);
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);
    case 'CECMAutocalibrationLargeScale'
        txBuffer(1) = hex2dec('AA');
        txBuffer(2) = hex2dec('A2');
        txBuffer(3:18) = 0;
        txBuffer(19) = sum(txBuffer(1:18));
        txBuffer(19) = mod(txBuffer(19),256);
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);
    case 'CECMAutocalibrationLargeSend'
        txBuffer(1) = hex2dec('AA');
        txBuffer(2) = hex2dec('B2');
        txBuffer(3:18) = 0;
        txBuffer(19) = sum(txBuffer(1:18));
        txBuffer(19) = mod(txBuffer(19),256);
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);
    case 'CECMAutocalibrationPrecisionScale'
        txBuffer(1) = hex2dec('AA');
        txBuffer(2) = hex2dec('A3');
        txBuffer(3:18) = 0;
        txBuffer(19) = sum(txBuffer(1:18));
        txBuffer(19) = mod(txBuffer(19),256);
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);
    case 'RestartMeasurement'
        txBuffer(1) = hex2dec('AA');
        txBuffer(2) = hex2dec('8D');
        txBuffer(3:18) = 0;
        txBuffer(19) = sum(txBuffer(1:18));
        txBuffer(19) = mod(txBuffer(19),256);
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);
    case 'error'
        txBuffer(1) = hex2dec('AA');
        txBuffer(2) = hex2dec('EE');
        txBuffer(3) = AdditionalInfo;
        txBuffer(19) = txBuffer(1) + txBuffer(2) + txBuffer(3);
        for i=4:18
            txBuffer(i) = 0;
            txBuffer(19) = txBuffer(19) + txBuffer(i);
        end
        txBuffer(19) = mod(txBuffer(19),256);
        txBuffer(20) = hex2dec('FF');
        fwrite(PORT,txBuffer);
end