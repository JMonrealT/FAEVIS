%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief receives the counterelectrode voltage     %
%          data waveform adquired. 	                 %
%   @version 15th July 2020                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function voltageCEWaveformReception(handles)
global voltageCENsequence txStopTransmission currentNsequence CurrentRequest
global rxBuffer CEVoltageWaveform CEVoltageWaveform_ptr alternationFlag 
global CalibrationLoaded CEValuesRead xCalibrated EQ1ES0
pointsReceived = bitand(rxBuffer(3),hex2dec('F0'))/16;
inputNseq = bitand(rxBuffer(3),hex2dec('0F'));

if(txStopTransmission == 0)
    %if(CEVoltageWaveform_ptr<10000)
        if(voltageCENsequence == inputNseq)
            if(voltageCENsequence+1>15)
                voltageCENsequence = 0;
            else
                voltageCENsequence = voltageCENsequence + 1;
            end

            if(pointsReceived>0)
                CEVoltageWaveform(CEVoltageWaveform_ptr) = rxBuffer(4)*(2^4)+...
                    bitand(rxBuffer(5),hex2dec('F0'))*(2^(-4));
            end
            if(pointsReceived>1)
                CEVoltageWaveform(CEVoltageWaveform_ptr+1) = ...
                    bitand(rxBuffer(5),hex2dec('0F'))*(2^8)+rxBuffer(6);
            end
            if(pointsReceived>2)
                CEVoltageWaveform(CEVoltageWaveform_ptr+2) = rxBuffer(7)*(2^4)+...
                    bitand(rxBuffer(8),hex2dec('F0'))*(2^(-4));
            end
            if(pointsReceived>3)
                CEVoltageWaveform(CEVoltageWaveform_ptr+3) = ...
                    bitand(rxBuffer(8),hex2dec('0F'))*(2^8)+rxBuffer(9);
            end
            if(pointsReceived>4)
                CEVoltageWaveform(CEVoltageWaveform_ptr+4) = rxBuffer(10)*(2^4)+...
                    bitand(rxBuffer(11),hex2dec('F0'))*(2^(-4));
            end
            if(pointsReceived>5)
                CEVoltageWaveform(CEVoltageWaveform_ptr+5) = ...
                    bitand(rxBuffer(11),hex2dec('0F'))*(2^8)+rxBuffer(12);
            end
            if(pointsReceived>6)
                CEVoltageWaveform(CEVoltageWaveform_ptr+6) = rxBuffer(13)*(2^4)+...
                    bitand(rxBuffer(14),hex2dec('F0'))*(2^(-4));
            end
            if(pointsReceived>7)
                CEVoltageWaveform(CEVoltageWaveform_ptr+7) = ...
                    bitand(rxBuffer(14),hex2dec('0F'))*(2^8)+rxBuffer(15);
            end
            if(pointsReceived>8)
                CEVoltageWaveform(CEVoltageWaveform_ptr+8) = rxBuffer(16)*(2^4)+...
                    bitand(rxBuffer(17),hex2dec('F0'))*(2^(-4));
            end
            if(pointsReceived>9)
                CEVoltageWaveform(CEVoltageWaveform_ptr+9) = ...
                    bitand(rxBuffer(17),hex2dec('0F'))*(2^8)+rxBuffer(18);
            end
            CEVoltageWaveform_ptr = CEVoltageWaveform_ptr + pointsReceived;
            %CEVoltageWaveform_ptr
            if(CalibrationLoaded)
                x = [256,768,1280,1792,2048,2304,2816,3328,3840];
                x = x+(x-xCalibrated);
                v = CEValuesRead;
                xq = 256:3840;
                vq = interp1(x,v,xq,'spline'); 
                xq = [1:255 xq]; vq = [(1:255)*0 vq]; 
                % plot(x,v,'o',xq,vq,':.');
                for i = 1:pointsReceived
                    if(and(CEVoltageWaveform(CEVoltageWaveform_ptr-i)>256,...
                            CEVoltageWaveform(CEVoltageWaveform_ptr-i)<3840))
                        dist = abs(vq - CEVoltageWaveform(CEVoltageWaveform_ptr-i));
                        minDist = min(dist);
                        CEVoltageWaveform(CEVoltageWaveform_ptr-i) = find(dist == minDist)-7;
                        % El "-1" ha sido a mano
                    end
                end
            else
                x = [0,256,768,1280,1792,2048,2304,2816,3328,3840,4095];
                v = flip(x);
                xq = 256:3840;
                vq = interp1(x,v,xq,'spline'); 
                xq = [1:255 xq]; vq = [(1:255)*0 vq]; 
                for i = 1:pointsReceived
                    dist = abs(vq - CEVoltageWaveform(CEVoltageWaveform_ptr-i));
                    minDist = min(dist);
                    CEVoltageWaveform(CEVoltageWaveform_ptr-i) = find(dist == minDist,1,'first')-7;
                    % El "-1" ha sido a mano
                end
            end
%             if(CEVoltageWaveform_ptr-1-pointsReceived>5)
%                 for i = (1:pointsReceived)+CEVoltageWaveform_ptr-1-pointsReceived-2
%                     if((abs(CEVoltageWaveform(i-2)-CEVoltageWaveform(i-1))<2))
%                         if((abs(CEVoltageWaveform(i+2)-CEVoltageWaveform(i+1))<2))
%                             filteredNoise(i) = CEVoltageWaveform(i-1);
%                         else
%                             filteredNoise(i) = CEVoltageWaveform(i);
%                         end
%                     else
%                         filteredNoise(i) = CEVoltageWaveform(i);
%                     end
%                 end
%                 i = (1:pointsReceived)+CEVoltageWaveform_ptr-1-pointsReceived-2;
%                 CEVoltageWaveform(i) = filteredNoise(i);
%             end
        end 
        if(EQ1ES0)
            if(~CurrentRequest)
                rxState(handles,'sending'); 
                sendHermesMessage('requestCurrentData',0,handles);
                rxState(handles,'waiting');
            else
                rxState(handles,'sending');     
                sendHermesMessage('currentAck',currentNsequence,handles);
                rxState(handles,'waiting');
            end
            alternationFlag = 1;
        else
            rxState(handles,'sending'); 
            sendHermesMessage('counterAck',voltageCENsequence,handles);
            rxState(handles,'waiting'); 
        end
    %end
end