%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project ZOIS                                    %
%   @brief sends the generated waveform through      %
%          Hermes with error treatment.              %
%   @version 06th July 2020                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function waveformTransmision(handles)
global WAVEFORM_DAC WAVEFORM_ptr waveformNsequence
global WaveformNumberOfPoints pointsToSend PORT
global txBuffer WaveformSent EQ1ES0
txBuffer = [hex2dec('AA') hex2dec('58')];
handles.rdbPotentiometryMode.Enable = 'off';
handles.rdbVoltageApplication.Enable = 'off';
pointsToSend = WaveformNumberOfPoints+1 - WAVEFORM_ptr;
if(pointsToSend>10)
    pointsToSend = 10;
end
txBuffer(3) = uint8(pointsToSend*(2^4)+waveformNsequence);

if(waveformNsequence<15)
    waveformNsequence = waveformNsequence + 1;
else
    waveformNsequence = 0;
end
if(pointsToSend<10)
    for i = pointsToSend:9
        WAVEFORM_DAC(WAVEFORM_ptr+i) = 0;
    end
end
if(pointsToSend ~= 0)
    txBuffer(4) = uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+0),hex2dec('FF0'))/2^4);
    txBuffer(5) = uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+0),hex2dec('00F'))*2^4)...
        +uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+1),hex2dec('F00'))/2^8);
    txBuffer(6) = uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+1),hex2dec('0FF')));
    txBuffer(7) = uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+2),hex2dec('FF0'))/2^4);
    txBuffer(8) = uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+2),hex2dec('00F'))*2^4)...
        +uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+3),hex2dec('F00'))/2^8);
    txBuffer(9) = uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+3),hex2dec('0FF')));
    txBuffer(10) = uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+4),hex2dec('FF0'))/2^4);
    txBuffer(11) = uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+4),hex2dec('00F'))*2^4)...
        +uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+5),hex2dec('F00'))/2^8);
    txBuffer(12) = uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+5),hex2dec('0FF')));
    txBuffer(13) = uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+6),hex2dec('FF0'))/2^4);
    txBuffer(14) = uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+6),hex2dec('00F'))*2^4)...
        +uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+7),hex2dec('F00'))/2^8);
    txBuffer(15) = uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+7),hex2dec('0FF')));
    txBuffer(16) = uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+8),hex2dec('FF0'))/2^4);
    txBuffer(17) = uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+8),hex2dec('00F'))*2^4)...
        +uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+9),hex2dec('F00'))/2^8);
    txBuffer(18) = uint8(bitand(WAVEFORM_DAC(WAVEFORM_ptr+9),hex2dec('0FF')));
    WAVEFORM_ptr = WAVEFORM_ptr + pointsToSend;
    txBuffer(19) = 0;
    for i=1:18
        txBuffer(19) = txBuffer(19) + txBuffer(i);
    end
    txBuffer(19) = mod(txBuffer(19),256);
    txBuffer(20) = hex2dec('FF');

    fwrite(PORT,txBuffer);
    
    handles.indYellowLoading.Visible = 'on';
    handles.indWaveformLoaded.BackgroundColor = [0 1 0];
    shift = 24.6*((WAVEFORM_ptr-1)/length(WAVEFORM_DAC));
    if(EQ1ES0)
        handles.indYellowLoading.Position = [1.8+shift 7.077 24.6-shift 0.847];
    else
        handles.indYellowLoading.Position = [1.8+shift 11.462 24.6-shift 0.847];
    end
else
    handles.indYellowLoading.Visible = 'off';
    if(EQ1ES0)
        handles.indYellowLoading.Position = [1.8 7.077 24.6 0.847];
    else
        handles.indYellowLoading.Position = [1.6 11.462 24.6 0.847];
    end
    rxState(handles,'idle');
    WaveformSent = 1;
    handles.psbStartExperience.Enable = 'on';
    handles.phbSaveResults.Enable = 'on';
    handles.rdbPotentiometryMode.Enable = 'on';
    handles.rdbVoltageApplication.Enable = 'on';
    handles.phbLoadWaveform.Enable = 'on';
end