function allInteractivity(handles,state)
global TimeoutChk AverageChk
if(and(TimeoutChk,strcmp(state,'on')))
    handles.edtPotentiometryTimeout.Enable = 'on';
else
    handles.edtPotentiometryTimeout.Enable = 'off';
end
if(and(AverageChk,strcmp(state,'on')))
    handles.edtVoltageVariation.Enable = 'on';
    handles.edtAveraginSamples.Enable = 'on';
else
    handles.edtVoltageVariation.Enable = 'off';
    handles.edtAveraginSamples.Enable = 'off';
end
handles.rdbPotentiometryMode.Enable = state;
handles.rdbVoltageApplication.Enable = state;
handles.pumPotentiometrySelection.Enable = state;
handles.edtSampleTime.Enable = state;
handles.pumActiveExperienceSelection.Enable = state;
handles.phbLoadWaveform.Enable = state;
handles.rdbLargeScale.Enable = state;
handles.rdbPrecisionScale.Enable = state;
handles.chkCorrectOCP.Enable = state;
handles.chkVoltageVariation.Enable = state;
handles.chkTimeout.Enable = state;