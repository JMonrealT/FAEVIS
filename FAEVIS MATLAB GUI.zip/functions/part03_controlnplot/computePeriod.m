function computePeriod()

global plotxlinesnow period SampleTime PeriodNumberOfPoints NumberOfPeriods xlv

period = SampleTime*PeriodNumberOfPoints*NumberOfPeriods;
xlv = 0;
if(period>1e4)
    period = double(period) / 1000;
    xlv = 1;
    if(period>1e4)
        period = double(period) / 1000;
        xlv = 2;
        if(period>600)
            period = period / 60; 
            xlv = 3;
        end
    end
end
plotxlinesnow = 0;
