function phbLoadParameters(varargin)
    global LoadParameters
    S = varargin{3};  % Get the structure.
    % set(S.h,'LineStyle',':')
    LoadParameters = 1;
    close(S.f);
end