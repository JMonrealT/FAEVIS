%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief plot active experience registered.        %
%   @version 08th July 2020                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function plotActiveExperience(handles)
global SampleTime AppliedWaveform CurrentWaveform3V CurrentEndOfScale ActiveExperience
global tv tc CurrentWaveform CEVoltageWaveform CEVoltageWaveform3V EQ1ES0 period
global p1 p2 p3 CurrentScale ActiveExperienceEnd toPlotAppliedWaveform AppliedWaveformRep
global Iterations_cnt PeriodNumberOfPoints NumberOfPeriods Iterations xlv xl

if(EQ1ES0)
    sizeCEVoltageWaveform = find(isnan(CEVoltageWaveform),1,'first')-1;
    sizeCurrentWaveform = find(isnan(CurrentWaveform),1,'first')-1;
    if(sizeCEVoltageWaveform>1)
        if(sizeCEVoltageWaveform<=1000)
            iniPlotV = 1;
            tv = SampleTime:SampleTime:sizeCEVoltageWaveform*SampleTime;
        else
            iniPlotV = sizeCEVoltageWaveform-999;
            tv = iniPlotV*SampleTime:SampleTime:sizeCEVoltageWaveform*SampleTime;
        end 
        f = repmat(5000/4095, length(tv)); f = f(1,:);
        offset = repmat(-2500, length(tv)); offset = offset(1,:);
        sizechk = size(iniPlotV:sizeCEVoltageWaveform); sizechk = sizechk(2);
        if(sizechk>1000)
            1+1
        end
        CEVoltageWaveform3V = CEVoltageWaveform(iniPlotV:sizeCEVoltageWaveform).*f+offset;
        toPlotAppliedWaveform = AppliedWaveform(iniPlotV:sizeCEVoltageWaveform);
    end
    if(sizeCurrentWaveform>1)
        if(sizeCurrentWaveform<=1000)
            iniPlotC = 1;
            tc = SampleTime:SampleTime:sizeCurrentWaveform*SampleTime;
        else
            iniPlotC = sizeCurrentWaveform-999;
            tc = iniPlotC*SampleTime:SampleTime:sizeCurrentWaveform*SampleTime;
        end
        if(CurrentScale==hex2dec('22')) % precision scale
            CurrentEndOfScale = 25; % uA
        else
            CurrentEndOfScale = 2.5; % mA
        end
        f = repmat(2*CurrentEndOfScale/4095, length(tc)); f = f(1,:);
        offset = repmat(-CurrentEndOfScale, length(tc)); offset = offset(1,:);
        CurrentWaveform3V=CurrentWaveform(iniPlotC:sizeCurrentWaveform).*f+offset;
    end
    if(isgraphics(p1))
        if(and(max(tv)>0,max(tc)>0))
            if(tv(end)>1e4)
                tv = double(tv) / 1000; tc = double(tc) / 1000;
                xlabel(handles.pltMainPlot,'Time (ms)')
                if(tv(end)>1e4)
                    tv = double(tv) / 1000; tc = double(tc) / 1000;
                    xlabel(handles.pltMainPlot,'Time (s)')
                    if(tv(end)>600)
                        tv = tv / 60; tc = tc / 60;
                        xlabel(handles.pltMainPlot,'Time (minutes)')
                    end
                end
            end
            yyaxis(handles.pltMainPlot,'left')
            try
                set(p1,'XData',tv(1:(end-2)),'YData',CEVoltageWaveform3V(1:(end-2)),'Color','b');
            catch
                set(p1,'XData',tv,'YData',CEVoltageWaveform3V,'Color','b');
            end
                set(p2,'XData',tv,'YData',toPlotAppliedWaveform,'Color','g');
            yyaxis(handles.pltMainPlot,'right')
                set(p3,'XData',tc,'YData',CurrentWaveform3V,'Color','r');  
            handles.pltMainPlot.XLim = [tv(1) max(max(tv),max(tc))];
            if(length(tv)>3)
                handles.pltMainPlot.YAxis(1).Limits = [min(min(CEVoltageWaveform3V(1:(end-2))),...
                    min(toPlotAppliedWaveform))-10 max(max(CEVoltageWaveform3V(1:(end-2))),...
                    max(toPlotAppliedWaveform))+10];
            end
            if(length(tc)>3)
                handles.pltMainPlot.YAxis(2).Limits = ...
                    [min(CurrentWaveform3V)-CurrentEndOfScale/100 ...
                    max(CurrentWaveform3V)+CurrentEndOfScale/100];
            end
        else
            ActiveExperienceEnd = 0;
            yyaxis(handles.pltMainPlot,'left')
                p1 = plot(handles.pltMainPlot,NaN,NaN,'Color','b');
                hold(handles.pltMainPlot,'on');
                p2 = plot(handles.pltMainPlot,NaN,NaN,'Color','g');
                hold(handles.pltMainPlot,'off');
                title(handles.pltMainPlot,'Active Experience Data Plot')
                xlabel(handles.pltMainPlot,'Time (us)')
                ylabel(handles.pltMainPlot,'Voltage (mV)')
            yyaxis(handles.pltMainPlot,'right')
                p3 = plot(handles.pltMainPlot,NaN,NaN,'Color','r'); 
                ylabel(handles.pltMainPlot,'Current (mA)') 
                currentLegend = 'Current (mA)';
            if(CurrentScale==hex2dec('22')) % precision scale
                ylabel(handles.pltMainPlot,'Current (uA)') 
                currentLegend = 'Current (uA)';
            end
            legend(handles.pltMainPlot,'CE Voltage (mV)', 'Applied Voltage (mV)',...
                currentLegend,'Location','northwest')
            handles.pltMainPlot.YAxis(2).Color = [0 0 0];%[0.85 0.325 0.098];
            handles.pltMainPlot.YAxis(1).Color = [0 0 0];%[0 0.447 0.741];
        end
        if(ActiveExperienceEnd)
            if(sizeCEVoltageWaveform>0)
                tv = SampleTime:SampleTime:sizeCEVoltageWaveform*SampleTime;
                f = repmat(5000/4095, length(tv)); f = f(1,:);
                offset = repmat(-2500, length(tv)); offset = offset(1,:);
                CEVoltageWaveform3V = CEVoltageWaveform(1:sizeCEVoltageWaveform).*f+offset;
                toPlotAppliedWaveform = AppliedWaveform(1:sizeCEVoltageWaveform);
            end
            if(sizeCurrentWaveform>0)
                tc = SampleTime:SampleTime:sizeCurrentWaveform*SampleTime;
                if(CurrentScale==hex2dec('22')) % precision scale
                    CurrentEndOfScale = 25; % uA
                else
                    CurrentEndOfScale = 2.5; % mA
                end
                f = repmat(2*CurrentEndOfScale/4095, length(tc)); f = f(1,:);
                offset = repmat(-CurrentEndOfScale, length(tc)); offset = offset(1,:);
                CurrentWaveform3V=CurrentWaveform(1:sizeCurrentWaveform).*f+offset;
            end
            if(and(max(tv)>0,max(tc)>0))
                if(tv(end)>1e4)
                    tv = double(tv) / 1000; tc = double(tc) / 1000;
                    xlabel(handles.pltMainPlot,'Time (ms)')
                    if(tv(end)>1e4)
                        tv = double(tv) / 1000; tc = double(tc) / 1000;
                        xlabel(handles.pltMainPlot,'Time (s)')
                        if(tv(end)>600)
                            tv = tv / 60; tc = tc / 60;
                            xlabel(handles.pltMainPlot,'Time (minutes)')
                        end
                    end
                end
                yyaxis(handles.pltMainPlot,'left')
                    set(p1,'XData',tv,'YData',CEVoltageWaveform3V,'Color','b');
                    set(p2,'XData',tv,'YData',toPlotAppliedWaveform,'Color','g');
                yyaxis(handles.pltMainPlot,'right')
                    set(p3,'XData',tc,'YData',CurrentWaveform3V,'Color','r');    
                handles.pltMainPlot.XLim = [0 max(max(tv),max(tc))];
            end
            endSound();
            ActiveExperienceEnd = 0;
            allInteractivity(handles,'on');
            handles.psbStartExperience.Enable = 'on';
            handles.phbSaveResults.Enable = 'on';
        end
    else
         yyaxis(handles.pltMainPlot,'left')
            p1 = plot(handles.pltMainPlot,NaN,NaN,'Color','b');
            hold(handles.pltMainPlot,'on');
            p2 = plot(handles.pltMainPlot,NaN,NaN,'Color','g');
            hold(handles.pltMainPlot,'off');
            title(handles.pltMainPlot,'Active Experience Data Plot')
            xlabel(handles.pltMainPlot,'Time (us)')
            ylabel(handles.pltMainPlot,'Voltage (mV)')
        yyaxis(handles.pltMainPlot,'right')
            p3 = plot(handles.pltMainPlot,NaN,NaN,'Color','r'); 
            ylabel(handles.pltMainPlot,'Current (mA)') 
            currentLegend = 'Current (mA)';
        if(CurrentScale==hex2dec('22')) % precision scale
            ylabel(handles.pltMainPlot,'Current (uA)') 
            currentLegend = 'Current (uA)';
        end
        legend(handles.pltMainPlot,'CE Voltage (mV)', 'Applied Voltage (mV)',...
            currentLegend,'Location','northwest')
        handles.pltMainPlot.YAxis(2).Color = [0 0 0];%[0.85 0.325 0.098];
        handles.pltMainPlot.YAxis(1).Color = [0 0 0];%[0 0.447 0.741];
        if(sizeCEVoltageWaveform>0)
            tv = SampleTime:SampleTime:sizeCEVoltageWaveform*SampleTime;
            f = repmat(5000/4095, length(tv)); f = f(1,:);
            offset = repmat(-2500, length(tv)); offset = offset(1,:);
            CEVoltageWaveform3V = CEVoltageWaveform(1:sizeCEVoltageWaveform).*f+offset;
            toPlotAppliedWaveform = AppliedWaveform(1:sizeCEVoltageWaveform);
        end
        if(sizeCurrentWaveform>0)
            tc = SampleTime:SampleTime:sizeCurrentWaveform*SampleTime;
            if(CurrentScale==hex2dec('22')) % precision scale
                CurrentEndOfScale = 25; % uA
            else
                CurrentEndOfScale = 2.5; % mA
            end
            f = repmat(2*CurrentEndOfScale/4095, length(tc)); f = f(1,:);
            offset = repmat(-CurrentEndOfScale, length(tc)); offset = offset(1,:);
            CurrentWaveform3V=CurrentWaveform(1:sizeCurrentWaveform).*f+offset;
        end
        if(and(max(tv)>0,max(tc)>0))
            if(tv(end)>1e4)
                tv = double(tv) / 1000; tc = double(tc) / 1000;
                xlabel(handles.pltMainPlot,'Time (ms)')
                if(tv(end)>1e4)
                    tv = double(tv) / 1000; tc = double(tc) / 1000;
                    xlabel(handles.pltMainPlot,'Time (s)')
                    if(tv(end)>600)
                        tv = tv / 60; tc = tc / 60;
                        xlabel(handles.pltMainPlot,'Time (minutes)')
                    end
                end
            end
            yyaxis(handles.pltMainPlot,'left')
                set(p1,'XData',tv,'YData',CEVoltageWaveform3V,'Color','b');
                set(p2,'XData',tv,'YData',toPlotAppliedWaveform,'Color','g');
            yyaxis(handles.pltMainPlot,'right')
                set(p3,'XData',tc,'YData',CurrentWaveform3V,'Color','r');    
            handles.pltMainPlot.XLim = [0 max(max(tv),max(tc))];
        end
    end
else  
    if(strcmp(ActiveExperience,'Gradient'))
        sizeCurrentWaveform = find(isnan(CurrentWaveform),1,'first')-1;
        if(sizeCurrentWaveform>1)
            if(sizeCurrentWaveform<=1000)
                iniPlotC = 1;
                tc = SampleTime:SampleTime:sizeCurrentWaveform*SampleTime;
            else
                iniPlotC = sizeCurrentWaveform-999;
                tc = iniPlotC*SampleTime:SampleTime:sizeCurrentWaveform*SampleTime;
            end
            if(CurrentScale==hex2dec('22')) % precision scale
                CurrentEndOfScale = 25; % uA
            else
                CurrentEndOfScale = 2.5; % mA
            end
            f = repmat(-2*CurrentEndOfScale/4095, length(tc)); f = f(1,:);
            offset = repmat(CurrentEndOfScale, length(tc)); offset = offset(1,:);
            CurrentWaveform3V=CurrentWaveform(iniPlotC:sizeCurrentWaveform).*f+offset;
            try
                toPlotAppliedWaveform = AppliedWaveform(iniPlotC:sizeCurrentWaveform);
            catch
                CurrentWaveform3V=CurrentWaveform(iniPlotC:size(toPlotAppliedWaveform)).*f+offset;
                toPlotAppliedWaveform = AppliedWaveform(iniPlotC:size(toPlotAppliedWaveform));
            end
        end
        if(isgraphics(p1))
            if(max(tc)>0)
                if(tc(end)>1e4)
                    tc = double(tc) / 1000; 
                    xlabel(handles.pltMainPlot,'Time (ms)')
                    if(tc(end)>1e4)
                        tc = double(tc) / 1000; 
                        xlabel(handles.pltMainPlot,'Time (s)')
                        if(tc(end)>600)
                            tc = tc / 60; 
                            xlabel(handles.pltMainPlot,'Time (minutes)')
                        end
                    end
                end
                yyaxis(handles.pltMainPlot,'left')
                    set(p1,'XData',tc,'YData',toPlotAppliedWaveform,'Color','g');
                yyaxis(handles.pltMainPlot,'right')
                    set(p2,'XData',tc,'YData',CurrentWaveform3V,'Color','r');  
                handles.pltMainPlot.XLim = [tc(1) max(tc)];
                if(length(tc)>3)
                    handles.pltMainPlot.YAxis(1).Limits = [min(toPlotAppliedWaveform)-10 ...
                        max(toPlotAppliedWaveform)+10];
                end
                if(length(tc)>3)
                    handles.pltMainPlot.YAxis(2).Limits = ...
                        [min(CurrentWaveform3V)-CurrentEndOfScale/100 ...
                        max(CurrentWaveform3V)+CurrentEndOfScale/100];
                end
            else
                ActiveExperienceEnd = 0;
                yyaxis(handles.pltMainPlot,'left')
                    p1 = plot(handles.pltMainPlot,NaN,NaN,'Color','g');
                    title(handles.pltMainPlot,'V Gradient ES Data Plot')
                    xlabel(handles.pltMainPlot,'Time (us)')
                    ylabel(handles.pltMainPlot,'Voltage (mV)')
                yyaxis(handles.pltMainPlot,'right')
                    p2 = plot(handles.pltMainPlot,NaN,NaN,'Color','r'); 
                    ylabel(handles.pltMainPlot,'Current (mA)') 
                    currentLegend = 'Current (mA)';
                if(CurrentScale==hex2dec('22')) % precision scale
                    ylabel(handles.pltMainPlot,'Current (uA)') 
                    currentLegend = 'Current (uA)';
                end
                legend(handles.pltMainPlot,'Applied Voltage (mV)',...
                    currentLegend,'Location','northwest')
                handles.pltMainPlot.YAxis(2).Color = [0 0 0];%[0.85 0.325 0.098];
                handles.pltMainPlot.YAxis(1).Color = [0 0 0];%[0 0.447 0.741];
            end
            if(ActiveExperienceEnd)
                if(sizeCurrentWaveform>0)
                    tc = SampleTime:SampleTime:sizeCurrentWaveform*SampleTime;
                    if(CurrentScale==hex2dec('22')) % precision scale
                        CurrentEndOfScale = 25; % uA
                    else
                        CurrentEndOfScale = 2.5; % mA
                    end
                    f = repmat(-2*CurrentEndOfScale/4095, length(tc)); f = f(1,:);
                    offset = repmat(CurrentEndOfScale, length(tc)); offset = offset(1,:);
                    CurrentWaveform3V=CurrentWaveform(1:sizeCurrentWaveform).*f+offset;
                    toPlotAppliedWaveform = AppliedWaveform(1:sizeCurrentWaveform);
                end
                if(max(tc)>0)
                    if(tc(end)>1e4)
                        tc = double(tc) / 1000; 
                        xlabel(handles.pltMainPlot,'Time (ms)')
                        if(tc(end)>1e4)
                            tc = double(tc) / 1000;
                            xlabel(handles.pltMainPlot,'Time (s)')
                            if(tc(end)>600)
                                tc = tc / 60; 
                                xlabel(handles.pltMainPlot,'Time (minutes)')
                            end
                        end
                    end
                    yyaxis(handles.pltMainPlot,'left')
                        set(p1,'XData',tc,'YData',toPlotAppliedWaveform,'Color','g');
                    yyaxis(handles.pltMainPlot,'right')
                        set(p2,'XData',tc,'YData',CurrentWaveform3V,'Color','r');    
                    handles.pltMainPlot.XLim = [0 max(tc)];
                end
%                 xl = cell(1,Iterations-1);
%                 for i = 1:(Iterations-1)
%                     xl{1,i} = xline(handles.pltMainPlot,i*period,'HandleVisibility','off','LineWidth',2);
%                 end
%                 drawnow
                endSound();
                ActiveExperienceEnd = 0;
            end
        else
             yyaxis(handles.pltMainPlot,'left')
                p1 = plot(handles.pltMainPlot,NaN,NaN,'Color','g');
                title(handles.pltMainPlot,'V Gradient ES Data Plot')
                xlabel(handles.pltMainPlot,'Time (us)')
                ylabel(handles.pltMainPlot,'Voltage (mV)')
            yyaxis(handles.pltMainPlot,'right')
                p2 = plot(handles.pltMainPlot,NaN,NaN,'Color','r'); 
                ylabel(handles.pltMainPlot,'Current (mA)') 
                currentLegend = 'Current (mA)';
            if(CurrentScale==hex2dec('22')) % precision scale
                ylabel(handles.pltMainPlot,'Current (uA)') 
                currentLegend = 'Current (uA)';
            end
            legend(handles.pltMainPlot,'Applied Voltage (mV)',...
                currentLegend,'Location','northwest')
            handles.pltMainPlot.YAxis(2).Color = [0 0 0];%[0.85 0.325 0.098];
            handles.pltMainPlot.YAxis(1).Color = [0 0 0];%[0 0.447 0.741];
            if(sizeCurrentWaveform>0)
                tc = SampleTime:SampleTime:sizeCurrentWaveform*SampleTime;
                if(CurrentScale==hex2dec('22')) % precision scale
                    CurrentEndOfScale = 25; % uA
                else
                    CurrentEndOfScale = 2.5; % mA
                end
                f = repmat(-2*CurrentEndOfScale/4095, length(tc)); f = f(1,:);
                offset = repmat(CurrentEndOfScale, length(tc)); offset = offset(1,:);
                CurrentWaveform3V=CurrentWaveform(1:sizeCurrentWaveform).*f+offset;
                toPlotAppliedWaveform = AppliedWaveform(1:sizeCurrentWaveform);
            end
            if(max(tc)>0)
                if(tc(end)>1e4)
                    tc = double(tc) / 1000;
                    xlabel(handles.pltMainPlot,'Time (ms)')
                    if(tc(end)>1e4)
                        tc = double(tctv) / 1000; 
                        xlabel(handles.pltMainPlot,'Time (s)')
                        if(tc(end)>600)
                            tc = tc / 60; 
                            xlabel(handles.pltMainPlot,'Time (minutes)')
                        end
                    end
                end
                yyaxis(handles.pltMainPlot,'left')
                    set(p1,'XData',tc,'YData',toPlotAppliedWaveform,'Color','g');
                yyaxis(handles.pltMainPlot,'right')
                    set(p2,'XData',tc,'YData',CurrentWaveform3V,'Color','r');    
                handles.pltMainPlot.XLim = [0 max(tc)];
            end
        end
    else
        sizeCEVoltageWaveform = find(isnan(CEVoltageWaveform),1,'first')-1;
        if(sizeCEVoltageWaveform>1)
            if(sizeCEVoltageWaveform<=1000)
                iniPlotC = 1;
                tc = SampleTime:SampleTime:sizeCEVoltageWaveform*SampleTime;
            else
                iniPlotC = sizeCEVoltageWaveform-999;
                tc = iniPlotC*SampleTime:SampleTime:sizeCEVoltageWaveform*SampleTime;
            end
            CurrentEndOfScale = 208; % uA
            f = repmat(5000/4095, length(tc)); f = f(1,:);
            offset = repmat(-2500, length(tc)); offset = offset(1,:);
            CEVoltageWaveform3V=CEVoltageWaveform(iniPlotC:sizeCEVoltageWaveform).*f+offset;
            toPlotAppliedWaveform = AppliedWaveformRep(iniPlotC:sizeCEVoltageWaveform);
        end
        if(isgraphics(p1))
            if(max(tc)>0)
                if(tc(end)>1e4)
                    tc = double(tc) / 1000; 
                    xlabel(handles.pltMainPlot,'Time (ms)')
                    if(tc(end)>1e4)
                        tc = double(tc) / 1000; 
                        xlabel(handles.pltMainPlot,'Time (s)')
                        if(tc(end)>600)
                            tc = tc / 60; 
                            xlabel(handles.pltMainPlot,'Time (minutes)')
                        end
                    end
                end
                yyaxis(handles.pltMainPlot,'left')
                    set(p1,'XData',tc,'YData',toPlotAppliedWaveform,'Color','r');
                yyaxis(handles.pltMainPlot,'right')
                    set(p2,'XData',tc,'YData',CEVoltageWaveform3V,'Color','b');  
                handles.pltMainPlot.XLim = [tc(1) max(tc)];
                if(length(tc)>3)
                    handles.pltMainPlot.YAxis(1).Limits = [min(toPlotAppliedWaveform)-10 ...
                        max(toPlotAppliedWaveform)+10];
                end
                if(length(tc)>3)
                    handles.pltMainPlot.YAxis(2).Limits = ...
                        [min(CEVoltageWaveform3V)-10 ...
                        max(CEVoltageWaveform3V)+10];
                end
            else
                ActiveExperienceEnd = 0;
                yyaxis(handles.pltMainPlot,'left')
                    p1 = plot(handles.pltMainPlot,NaN,NaN,'Color','r');
                    title(handles.pltMainPlot,'Current Injection ES Data Plot')
                    xlabel(handles.pltMainPlot,'Time (us)')
                    ylabel(handles.pltMainPlot,'Current (uA)') 
                    currentLegend = 'Current (uA)';
                yyaxis(handles.pltMainPlot,'right')
                    p2 = plot(handles.pltMainPlot,NaN,NaN,'Color','b'); 
                    ylabel(handles.pltMainPlot,'Voltage (mV)')
                legend(handles.pltMainPlot,currentLegend,'Applied Voltage (mV)',...
                    'Location','northwest')
                handles.pltMainPlot.YAxis(2).Color = [0 0 0];%[0.85 0.325 0.098];
                handles.pltMainPlot.YAxis(1).Color = [0 0 0];%[0 0.447 0.741];
            end
            if(ActiveExperienceEnd)
                if(sizeCEVoltageWaveform>0)
                    tc = SampleTime:SampleTime:sizeCEVoltageWaveform*SampleTime;
                    CurrentEndOfScale = 208; % uA
                    f = repmat(5000/4095, length(tc)); f = f(1,:);
                    offset = repmat(-2500, length(tc)); offset = offset(1,:);
                    CEVoltageWaveform3V=CEVoltageWaveform(1:sizeCEVoltageWaveform).*f+offset;
                    toPlotAppliedWaveform = repmat(AppliedWaveform, sizeCEVoltageWaveform/length(AppliedWaveform));
                    toPlotAppliedWaveform = toPlotAppliedWaveform(1,:);
                end
                if(max(tc)>0)
                    if(tc(end)>1e4)
                        tc = double(tc) / 1000; 
                        xlabel(handles.pltMainPlot,'Time (ms)')
                        if(tc(end)>1e4)
                            tc = double(tc) / 1000;
                            xlabel(handles.pltMainPlot,'Time (s)')
                            if(tc(end)>600)
                                tc = tc / 60; 
                                xlabel(handles.pltMainPlot,'Time (minutes)')
                            end
                        end
                    end
                    yyaxis(handles.pltMainPlot,'left')
                        set(p1,'XData',tc,'YData',toPlotAppliedWaveform,'Color','r');
                    yyaxis(handles.pltMainPlot,'right')
                        set(p2,'XData',tc,'YData',CEVoltageWaveform3V,'Color','b');    
                    handles.pltMainPlot.XLim = [0 max(tc)];
                end
                endSound();
                ActiveExperienceEnd = 0;
            end
        else
             yyaxis(handles.pltMainPlot,'left')
                p1 = plot(handles.pltMainPlot,NaN,NaN,'Color','r');
                title(handles.pltMainPlot,'Current Injection ES Data Plot')
                xlabel(handles.pltMainPlot,'Time (us)')
                ylabel(handles.pltMainPlot,'Current (mA)') 
                currentLegend = 'Current (uA)';
            yyaxis(handles.pltMainPlot,'right')
                p2 = plot(handles.pltMainPlot,NaN,NaN,'Color','b');
                ylabel(handles.pltMainPlot,'Voltage (mV)')
            legend(handles.pltMainPlot,currentLegend,'Applied Voltage (mV)',...
                'Location','northwest')
            handles.pltMainPlot.YAxis(2).Color = [0 0 0];%[0.85 0.325 0.098];
            handles.pltMainPlot.YAxis(1).Color = [0 0 0];%[0 0.447 0.741];
            if(sizeCEVoltageWaveform>0)
                tc = SampleTime:SampleTime:sizeCEVoltageWaveform*SampleTime;
                CurrentEndOfScale = 208; % uA
                f = repmat(5000/4095, length(tc)); f = f(1,:);
                offset = repmat(-2500, length(tc)); offset = offset(1,:);
                CEVoltageWaveform3V=CEVoltageWaveform(iniPlotC:sizeCEVoltageWaveform).*f+offset;
                toPlotAppliedWaveform = AppliedWaveform(iniPlotC:sizeCEVoltageWaveform);
            end
            if(max(tc)>0)
                if(tc(end)>1e4)
                    tc = double(tc) / 1000;
                    xlabel(handles.pltMainPlot,'Time (ms)')
                    if(tc(end)>1e4)
                        tc = double(tctv) / 1000; 
                        xlabel(handles.pltMainPlot,'Time (s)')
                        if(tc(end)>600)
                            tc = tc / 60; 
                            xlabel(handles.pltMainPlot,'Time (minutes)')
                        end
                    end
                end
                yyaxis(handles.pltMainPlot,'left')
                    set(p1,'XData',tc,'YData',toPlotAppliedWaveform,'Color','r');
                yyaxis(handles.pltMainPlot,'right')
                    set(p2,'XData',tc,'YData',CEVoltageWaveform3V,'Color','b');    
                handles.pltMainPlot.XLim = [0 max(tc)];
            end
        end
    end
end
