%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief plot potentiometry registered.            %
%   @version 09th January 2020                       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function plotPotentiometry(handles)
global PotentiometrySampleTime PotentiometryWaveform
global tp PotentiometryWaveform3V pt p1 p2 p3 
sizePotentiometryWaveform = find(isnan(PotentiometryWaveform),1,'first')-1;
tp = PotentiometrySampleTime:PotentiometrySampleTime:...
            (sizePotentiometryWaveform)*PotentiometrySampleTime;
timeUnits = 'Time (ms)';        
if(and(isgraphics(pt),max(tp)>0))
    if(max(tp)>1e4)
        tp = double(tp) / 1000; timeUnits = 'Time (s)';
        if(max(tp)>600)
            tp = double(tp) / 60; timeUnits = 'Time (min)';
        end
    end
    set(pt,'XData',tp,'YData',PotentiometryWaveform3V,'Color','b');
        handles.pltMainPlot.XLim = [0 max(tp)];
        handles.pltMainPlot.YLim = ...
            [min(PotentiometryWaveform3V)-100 ...
            max(PotentiometryWaveform3V)+100];
    xlabel(handles.pltMainPlot,timeUnits)
    % pause(0) 
else
    itWasEmptyFlag = 0;
    if(~isgraphics(pt))
        itWasEmptyFlag = 1;
    end
    if(~isempty(p1))
        delete(p1); p1 = [];
    end
    if(~isempty(p2))
        delete(p2); p2 = [];
    end
    if(~isempty(p3))
        delete(p3); p3 = [];
    end
    if(length(handles.pltMainPlot.YAxis)==2)
        yyaxis(handles.pltMainPlot,'left')
        handles.pltMainPlot.YAxis(2).Visible='off';
        handles.pltMainPlot.YAxis(1).Color = [0 0 0];
    end
    pt = plot(handles.pltMainPlot,NaN,NaN,'Color','b');
    title(handles.pltMainPlot,'Potentiometry Data Plot')
    xlabel(handles.pltMainPlot,'Time (ms)')
    ylabel(handles.pltMainPlot,'Voltage (mV)')
    legend(handles.pltMainPlot,'Potentiometry (mV)','Location','northwest')
    grid(handles.pltMainPlot, 'on')
    if(itWasEmptyFlag)
        plotPotentiometry(handles);
    end
end