%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                           %
%   @project FAEVIS                                        %
%   @brief Preview loading waveform to EQ or ES experience %
%   @version 06th July 2020                                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function previewLoadingWaveform(handles)
global SampleTime AppliedWaveform LoadParameters EQ1ES0 Stimulation
global NumberOfPeriods PeriodNumberOfPoints limitPotSampleTime_ms NumberOfPeriodsMultiplier

S.f = figure('NumberTitle', 'off', 'Name', 'Waveform to be loaded'); 
set(S.f, 'MenuBar', 'none');
set(S.f, 'ToolBar', 'none');
ta = 0:uint64(SampleTime):uint64((length(AppliedWaveform)-1)*double(SampleTime));
timeUnits = 'Time (us)';
if(ta(end) > 1e4)
    ta = double(ta) / 1000; timeUnits = 'Time (ms)';
    if(ta(end) > 1e4) 
        ta = double(ta) / 1000; timeUnits = 'Time (s)';
        if(ta(end) > 600) 
            ta = ta / 60; timeUnits = 'Time (minutes)';
        end
    end
end     
ax1 = subplot(2,1,1); ax1.Position = [0.13 0.28 0.8 0.65];
S.h = plot(ax1,ta,AppliedWaveform);
    title('Waveform to be loaded')
    xlabel(timeUnits)
    if(EQ1ES0)
        ylabel('Voltage (mV)')
    else
        if(strcmp(Stimulation,'mV'))
            ylabel('Voltage (mV)')
        elseif(strcmp(Stimulation,'uA'))
            ylabel('Current (uA)')
        else
            ylabel('Current (nA)')
        end  
    end
    grid on
smplTime = SampleTime; smplText = 'us';
if(SampleTime>300e6)
    smplTime = smplTime/60e6; smplText = 'minutes';
elseif(SampleTime>1e6)
    smplTime = smplTime/1e6; smplText = 'seconds';
elseif(SampleTime>1e3)
    smplTime = smplTime/1e3; smplText = 'ms';
end 
ttlTime = double(SampleTime)*double(NumberOfPeriods)*double(PeriodNumberOfPoints)*double(10^NumberOfPeriodsMultiplier);
if(ttlTime>300e6)
    ttlTime1 = ttlTime/60e6; ttlText = 'minutes';
elseif(ttlTime>1e6)
    ttlTime1 = ttlTime/1e6; ttlText = 'seconds';
elseif(ttlTime>1e3)
    ttlTime1 = ttlTime/1e3; ttlText = 'ms';
end 
txt = {['Sample time:' ' ' num2str(smplTime) ' ' smplText], ...
    ['Number of points per period:' ' ' num2str(PeriodNumberOfPoints)], ...
    ['Number of periods:' ' ' num2str(NumberOfPeriods*10^NumberOfPeriodsMultiplier)],...
    ['Total time:' ' ' num2str(ttlTime1) ' ' ttlText]}; 
hText = text(ax1,0,0,txt); hText.Units = 'pixels';
hText.Position = [-26 -65 0];
LoadParameters = 0;
S.pb = uicontrol('style','push',...
                 'units','pix',...
                 'position',[380 20 160 30],...
                 'fontsize',14,...
                 'string','Load parameters',...
                 'callback',{@phbLoadParameters,S});
handles.psbStartExperience.Enable = 'off';
handles.phbSaveResults.Enable = 'off';
handles.rdbPotentiometryMode.Enable = 'off';
handles.rdbVoltageApplication.Enable = 'off';
if(SampleTime/1e3<limitPotSampleTime_ms*2)
    if(NumberOfPeriods*10^NumberOfPeriodsMultiplier<=10)
        str = 'Sample time is shorter than transmission time. Plot will not be real-time.';
    else
        str = 'Sample time is shorter than transmission time and memory limits. Only certain periods will be registered and transmited.';
    end
    errorSound(); warndlg(str);
end
uiwait(S.f);
end