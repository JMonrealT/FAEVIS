function rxState(handles,state)
global openedCOM rxWaiting
switch state
    case 'sending'
        rxWaiting = 0;
        handles.indSerial.BackgroundColor = [0 0 1];
    case 'waiting'
        rxWaiting = 1;
        handles.indSerial.BackgroundColor = [1 1 0];
    case 'idle'
        rxWaiting = 0;
        if(openedCOM)
            handles.indSerial.BackgroundColor = [0 1 0];
        else
            handles.indSerial.BackgroundColor = [0 0.3 0];
        end
end