function setTxtTotalTime(handles,PeriodNumberOfPoints,NumberOfPeriods,NumberOfPeriodsMultiplier,SampleTime)
t = (PeriodNumberOfPoints*NumberOfPeriods*10^NumberOfPeriodsMultiplier*SampleTime/1000000);
t_ = mod(t,86400);
dd = (t - t_)/86400;   
hms = sec2hms(t_); splithms = split(hms,':'); splitsecs = splithms{3};
splitsecs = str2num(splitsecs); 
if(splitsecs<10)
    secs = sprintf('0%2.3f',splitsecs);
else
    secs = sprintf('%2.3f',splitsecs);
end
handles.txtTotalTime.String = strcat(num2str(dd),{' '},splithms{1},':',splithms{2},':',secs);
end

