%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief handles the FSM in communication with     %
%          FAEVIS NXP41Z uC.                         %
%   @version 08th July 2020                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% --- Executes for commanding the automatic process of configuration,
% starting experience and asking for values during it.
function stateMachine(handles)
% handles    empty - handles not created until after all CreateFcns called
global ExperienceMode eqTransmission limitPotSampleTime_ms
global PotentiometryRequested TimeoutChk EQ1ES0 CurrentRequest
global stateFSM WaveformSent PotentiometrySampleTime ActiveExperience
global PotentiometryWaveform3V PotentiometryTimeout_250ms VRequest

limitPotSampleTime_ms = 10;
if(stateFSM==0)
    allInteractivity(handles,'off');
    handles.psbStartExperience.Enable = 'off';
    handles.phbSaveResults.Enable = 'off';
    if(~EQ1ES0)
        ExperienceMode = 'Active';
    end
    if(strcmp(ExperienceMode,'Active'))
        if(WaveformSent)
            eqTransmission = 0;
            rxState(handles,'sending');
            sendHermesMessage('setVoltammetryConfiguration',0,handles);
            rxState(handles,'waiting');
        else
            allInteractivity(handles,'on');
            handles.psbStartExperience.Enable = 'on';
            handles.phbSaveResults.Enable = 'on';
            rxState(handles,'idle');
            errorSound(); warndlg('Set waveform to apply before start experience.'); 
        end
    elseif(strcmp(ExperienceMode,'Potentiometry'))
        start = 1;
        if(or(and(and(PotentiometrySampleTime<limitPotSampleTime_ms,...
                PotentiometryTimeout_250ms*250/PotentiometrySampleTime>...
                1000),TimeoutChk),and(PotentiometrySampleTime<limitPotSampleTime_ms,...
                ~TimeoutChk)))
            errorSound();
            answer = questdlg(...
                'Sample time is too short, timeout will occur when there is no memory left (1000 points). What do you want to do?',...
                'There is a problem with the configuration.',...
                'Start experience','Do not start','Start experience');
            switch answer
                case 'Start experience'
                case 'Do not start'
                    start = 0;
                    allInteractivity(handles,'on');
                    handles.psbStartExperience.Enable = 'on';
                    handles.phbSaveResults.Enable = 'on';
            end
        end
        if(start)
            PotentiometryRequested = 0; 
            rxState(handles,'sending');
            sendHermesMessage('setPotentiometryConfiguration',0,handles);
            rxState(handles,'waiting');
            PotentiometryWaveform3V = 0;
        end
    end
elseif(stateFSM==1)
    rxState(handles,'sending');
    sendHermesMessage('startExperience',0,handles);
    rxState(handles,'waiting');
    CurrentRequest = 0; VRequest = 0;
elseif(stateFSM==2)
    rxState(handles,'sending');
    if(strcmp(ExperienceMode,'Active'))
        if(EQ1ES0)
            dataCEndCurrentReception(handles);   
            plotActiveExperience(handles); 
        else
            if(strcmp(ActiveExperience,'Gradient'))
                if(~CurrentRequest)
                    sendHermesMessage('requestCurrentData',0,handles);
                    rxState(handles,'waiting'); 
                    CurrentRequest = 1;
                else
                    currentWaveformReception(handles);
                end
            else
                if(~VRequest)
                    sendHermesMessage('requestCounterData',0,handles);
                    rxState(handles,'waiting'); 
                    VRequest = 1;
                else
                    voltageCEWaveformReception(handles);
                end
            end
            plotActiveExperience(handles); 
        end
    elseif(strcmp(ExperienceMode,'Potentiometry'))
        if(~PotentiometryRequested)
            sendHermesMessage('requestPotentiometryData',0,handles);
            rxState(handles,'waiting');
        else
            potentiometryWaveformReception(handles);
        end
        plotPotentiometry(handles);
    end
end