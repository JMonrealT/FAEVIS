function ActiveTimeTimer_Callback(hObject, eventdata, handles)
global AliveTimer EndedActiveTimeFlag
EndedActiveTimeFlag = 1;
stop(hObject);
delete(hObject);
clear AliveTimer