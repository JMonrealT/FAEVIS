function InitialTimerCallback(hObject, eventdata, handles)
global InitialTimer cnt
axes(handles.pltMainPlot);
xlabel(handles.pltMainPlot,'Time (ms)')
ylabel(handles.pltMainPlot,'Voltage (mV)')
xlim(handles.pltMainPlot,[0 1])
ylim(handles.pltMainPlot,[0 1])
grid(handles.pltMainPlot, 'on')
cnt = 1;
pause(0) 
stop(hObject);
delete(hObject);
clear InitialTimer