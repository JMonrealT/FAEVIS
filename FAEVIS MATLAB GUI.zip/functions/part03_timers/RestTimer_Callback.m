function RestTimer_Callback(hObject, eventdata, handles)
global RestTimer rxWaiting PORT
if(~rxWaiting)
    stateMachine(handles); 
end
stop(hObject);
delete(hObject);
clear RestTimer
