function StartInitialTimer(handles)
global InitialTimer 
InitialTimer = timer;
set(InitialTimer,'startDelay',1e-3);
set(InitialTimer,'ExecutionMode','singleShot');
set(InitialTimer,'TimerFcn',{@InitialTimerCallback,handles}) 
start(InitialTimer)
initialSound();