function StartRUAliveTimer(handles)
global TimerRUA RUA
RUA = 0;
TimerRUA = timer;
%set(Timer_1s,'Period',0.5)
%set(Timer_1s,'ExecutionMode','fixedRate')
set(TimerRUA,'startDelay',1.0);
set(TimerRUA,'ExecutionMode','singleShot');
set(TimerRUA,'TimerFcn',{@TimerRUA_Callback,handles}) 
start(TimerRUA)