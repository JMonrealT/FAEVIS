function StartRestTimer(handles,restTime_s)
global RestTimer
try
    RestTimer = timer;
    %set(RestTimer,'Period',0.5)
    %set(RestTimer,'ExecutionMode','fixedRate')
    set(RestTimer,'startDelay',restTime_s);%1.0);
    set(RestTimer,'ExecutionMode','singleShot');
    set(RestTimer,'TimerFcn',{@RestTimer_Callback,handles}) 
    start(RestTimer) 
catch
end