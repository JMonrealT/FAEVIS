function StartTimer_1s(handles)
global Timer_1s
try
    Timer_1s = timer;
    %set(Timer_1s,'Period',0.5)
    %set(Timer_1s,'ExecutionMode','fixedRate')
    set(Timer_1s,'startDelay',0.1);
    set(Timer_1s,'ExecutionMode','singleShot');
    set(Timer_1s,'TimerFcn',{@Timer_1s_Callback,handles}) 
    start(Timer_1s) 
catch
end