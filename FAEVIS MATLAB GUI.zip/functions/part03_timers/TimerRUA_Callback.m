function TimerRUA_Callback(hObject, eventdata, handles)
global TimerRUA RUA PORT openedCOM
if(~RUA)
    fclose(PORT); % Opens port
    delete(PORT)
    clear PORT
    openedCOM = 0;
    handles.phbConnectCOM.ForegroundColor = [0 0 0];
    handles.indSerial.BackgroundColor = [0 0.3 0];
    errorSound(); warndlg('The selectec COM port does not belong to FAEVIS or FAEVIS is not connected.'); 
end
stop(hObject);
delete(hObject);
clear TimerRUA