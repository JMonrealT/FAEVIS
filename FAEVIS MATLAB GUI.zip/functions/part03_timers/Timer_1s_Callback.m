function Timer_1s_Callback(hObject, eventdata, handles)
global Timer_1s rxWaiting PORT txBuffer
% if(rxWaiting)
%     %stateMachine(handles);
%     rxState(handles,'sending');
%     fwrite(PORT,txBuffer);
%     rxState(handles,'waiting');
%     stop(hObject);
%     delete(hObject);
%     clear Timer_1s
%     StartTimer_1s(handles)
% else
%     stop(hObject);
%     delete(hObject);
%     clear Timer_1s
% end
if(~rxWaiting)
    %stateMachine(handles);
    rxState(handles,'sending');
    fwrite(PORT,txBuffer);
    rxState(handles,'waiting');
end
stop(hObject);
delete(hObject);
clear Timer_1s

