function startActiveTimeTimer(handles)
global AliveTimer EndedActiveTimeFlag SampleTime 
EndedActiveTimeFlag = 0;
AliveTimer = timer;
%set(Timer_1s,'Period',0.5)
%set(Timer_1s,'ExecutionMode','fixedRate')
set(AliveTimer,'startDelay',double(SampleTime)/1e6*1e4);
set(AliveTimer,'ExecutionMode','singleShot');
set(AliveTimer,'TimerFcn',{@ActiveTimeTimer_Callback,handles}) 
start(AliveTimer)
