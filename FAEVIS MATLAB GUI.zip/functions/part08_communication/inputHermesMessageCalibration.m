%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief handles reception of Hermes protocol.  	 %
%   @version 01st February 2020                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function inputHermesMessageCalibration(hObject, eventdata, handles)
global PORT rxBuffer rxWaiting waveformNsequence PotEnded AEEnded
global pointsToSend WAVEFORM_ptr ExperienceMode txStopTransmission
global PotentiometryRequested PotentiometryTimeout PotentiometryTimeout_250ms
global PotentiometryWaveform_ptr CurrentWaveform_ptr CEVoltageWaveform_ptr
global CurrentWaveform CEVoltageWaveform PotentiometryWaveform RUA
global tp tv tc stateFSM WaveformLoadRequested WaveformSent ActiveExperienceEnd
global NumberOfPeriods PeriodNumberOfPoints SampleTime eqTransmission
global CERequest CurrentRequest PotentiometrySampleTime limitPotSampleTime_ms

if(rxWaiting)
    N = PORT.BytesAvailable;
    if N>=20
        rxState(handles,'idle');
        rxBuffer=fread(PORT,20);
        calcChecksum = sum(rxBuffer(1:18));
        calcChecksum = mod(calcChecksum,256);
        if(calcChecksum ~= rxBuffer(19))
            rxState(handles,'sending');
            sendHermesMessage('error');
            rxState(handles,'waiting');
        end
        if(calcChecksum == rxBuffer(19))
            switch rxBuffer(2)
                case hex2dec('11')
                    RUA = 1;
                    handles.phbConnectCOM.ForegroundColor = [0 0.7 0];
                    handles.pumAvailableCOMs.Enable = 'off';
                    handles.phbScanCOMs.Enable = 'off';
                    handles.phbSet0256.Enable = 'on';
                case hex2dec('C1')
                    handles.indExperienceStatus.BackgroundColor = [0 0.3 0];
                    stateFSM = 1;
                    stateMachine(handles)
                case hex2dec('C2')
                    if(WaveformLoadRequested)
                        WaveformLoadRequested = 0;
                        rxState(handles,'sending');
                        sendHermesMessage('setWaveform',0,handles);
                        rxState(handles,'waiting');
                    else
                        handles.indExperienceStatus.BackgroundColor = [0 0.3 0];
                        stateFSM = 1;
                        stateMachine(handles)
                    end
                case hex2dec('58')
                    inputNsequence = bitand(rxBuffer(3),hex2dec('0F'));
                    if(inputNsequence == waveformNsequence)
                        rxState(handles,'sending');
                        waveformTransmision(handles);
                        if(~WaveformSent)
                            rxState(handles,'waiting');
                        else
                            rxState(handles,'idle');
                        end
                    else
                        waveformNsequence = waveformNsequence - 1;
                        WAVEFORM_ptr = WAVEFORM_ptr - pointsToSend;
                        rxState(handles,'sending');
                        waveformTransmision(handles);
                        rxState(handles,'waiting');
                    end
                    handles.indExperienceStatus.BackgroundColor = [0 0.3 0];
                case hex2dec('77')
                    rxState(handles,'idle');
                    stateFSM = 0; txStopTransmission = 0;
                    if(WaveformLoadRequested)
                        rxState(handles,'sending');
                        sendHermesMessage('setVoltammetryConfiguration',0,handles);
                        rxState(handles,'waiting');
                        handles.indYellowLoading.Visible = 'off';
                        handles.indWaveformLoaded.BackgroundColor = [0 0.3 0];
                        handles.psbStartExperience.Enable = 'off';
                        handles.phbSaveResults.Enable = 'off';
                        handles.rdbPotentiometryMode.Enable = 'off';
                        handles.rdbVoltageApplication.Enable = 'off';                      
                    else
                        allInteractivity(handles,'on');
                        handles.psbStartExperience.Enable = 'on';
                        handles.phbSaveResults.Enable = 'on';
                    end
                    pause(0.2);
                case hex2dec('55')                   
                    rxState(handles,'sending');
                    handles.indExperienceStatus.BackgroundColor = [0 1 0];
                    if(strcmp(ExperienceMode,'Active'))
                        time = double(SampleTime)/1e6*PeriodNumberOfPoints*NumberOfPeriods;
                        tv = 0; tc = 0;
                        CurrentWaveform_ptr = 1; CEVoltageWaveform_ptr = 1;
                        % CurrentWaveform = 0; CEVoltageWaveform = 0;
                        CurrentWaveform = zeros(1,1e6);
                        CurrentWaveform(:) = NaN;
                        CEVoltageWaveform = zeros(1,1e6);
                        CEVoltageWaveform(:) = NaN;
                    else
                        time = PotentiometryTimeout;
                        tp = 0; PotentiometryWaveform_ptr = 1;
                        % PotentiometryWaveform = 0;
                        PotentiometryWaveform = zeros(1,1e5);
                        PotentiometryWaveform(:) = NaN;
                        PotentiometryRequested = 0;
                    end
                    handles.lblTimeToEnd.String = ...
                    strcat(datestr(clock,'dd/mm'),{' '},datestr(addtodate(datenum(datestr(...
                    clock,'HH:MM:SS'),'HH:MM:SS'),time,'second'),'HH:MM:SS')); 
                    stateFSM = 2;
                    stateMachine(handles);
                case hex2dec('BB')
                    rxState(handles,'idle');
                    handles.indExperienceStatus.BackgroundColor = [0 0.3 0];
                    handles.lblTimeToEnd.String = ' ';
                    sendHermesMessage('stopTransmission',0,handles);
                    rxWaiting = 1;
                case hex2dec('17')
                    PotEnded = 0;
                    PotentiometryRequested = 1;
                    stateMachine(handles);
                case hex2dec('27')
                    AEEnded = 0;
                    eqTransmission = 1; 
                    stateMachine(handles);
                case hex2dec('37')
                    AEEnded = 0;
                    eqTransmission = 1;                
                    stateMachine(handles);
                case hex2dec('DD')
                    stateMachineDACCalibration(handles);
                case hex2dec('A1')
                    potentiometryAutocalibrationTreatment(handles);
                case hex2dec('A2')
                    CECMAutocalibrationTreatment(handles);
                case hex2dec('B2')
                    CECMAutocalibrationTreatment(handles);
                case hex2dec('A3')
                    CECMAutocalibrationTreatment(handles);
                case hex2dec('EE')
                    switch rxBuffer(3)
                        case hex2dec('55')
                            handles.psbStartExperience.Enable = 'on';
                            handles.phbSaveResults.Enable = 'on';
                            handles.rdbPotentiometryMode.Enable = 'on';
                            handles.rdbVoltageApplication.Enable = 'on';
                            allInteractivity(handles,'on');
                            handles.phbLoadWaveform.Enable = 'on';
                            errorSound(); warndlg('First, load experience.');
                        case hex2dec('C1')   
                            rxState(handles,'idle');
                        case hex2dec('C2')   
                            rxState(handles,'idle');
                        case hex2dec('58')
                            waveformNsequence = 0;
                            WAVEFORM_ptr = 1;
                            rxState(handles,'idle');
                        case hex2dec('1D')
                            rxState(handles,'idle');
                            StartTimer_1s(handles);
                        case hex2dec('2D')
                            rxState(handles,'idle');
                            StartTimer_1s(handles);
                        case hex2dec('3D')
                            rxState(handles,'idle');
                            StartTimer_1s(handles);
                        case hex2dec('17')
                            rxState(handles,'idle');
                            StartTimer_1s(handles);
                        case hex2dec('27')
                            rxState(handles,'idle');
                            StartTimer_1s(handles);
                        case hex2dec('37')
                            rxState(handles,'idle');
                            StartTimer_1s(handles);
                        case hex2dec('1E')
                            PotEnded = 1;
                            PotentiometryRequested = 0;
                            rxState(handles,'idle');
                            stateFSM = 0;
                            if(and(and(PotentiometryWaveform_ptr==1000+1,...
                                    PotentiometrySampleTime<limitPotSampleTime_ms),...
                                    (PotentiometryWaveform_ptr-1)*...
                                    PotentiometrySampleTime<...
                                    PotentiometryTimeout_250ms*250))
                                errorSound(); warndlg('FAEVIS internal memory full.');
                            end
                            allInteractivity(handles,'on');
                            handles.psbStartExperience.Enable = 'on';
                            handles.phbSaveResults.Enable = 'on';
                            t = 1:0.33:1000; sound(flip(t-1)/800.*sin(t));
                        case hex2dec('2E')
                            AEEnded = 1;
                            ActiveExperienceEnd = 1;
                            plotActiveExperience(handles);
                            eqTransmission = 0;
                            CurrentRequest = 0;
                            rxState(handles,'idle');
                            stateFSM = 0;
                            allInteractivity(handles,'on');
                            handles.psbStartExperience.Enable = 'on';
                            handles.phbSaveResults.Enable = 'on';
                        case hex2dec('3E')
                            AEEnded = 1;
                            ActiveExperienceEnd = 1;
                            plotActiveExperience(handles);
                            eqTransmission = 0;
                            CERequest = 0;
                            rxState(handles,'idle');
                            stateFSM = 0; 
                            allInteractivity(handles,'on');
                            handles.psbStartExperience.Enable = 'on';
                            handles.phbSaveResults.Enable = 'on';
                        otherwise
                            rxState(handles,'idle');
                    end
                otherwise
                    sendHermesMessage('error');
                    rxState(handles,'waiting');
            end
        end
    end    
end