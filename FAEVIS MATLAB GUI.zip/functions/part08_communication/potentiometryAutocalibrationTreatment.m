%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief treats the potentiometry calibration      %
%       values received.                      	 	 %
%   @version 04th February 2020                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function potentiometryAutocalibrationTreatment(handles)
    global PotentiometryCalibrationValues rxBuffer

    PotentiometryCalibrationValues(1) = rxBuffer(3)*(2^4)+...
        bitand(rxBuffer(4),hex2dec('F0'))*(2^(-4));

    PotentiometryCalibrationValues(2) = ...
        bitand(rxBuffer(4),hex2dec('0F'))*(2^8)+rxBuffer(5);

    PotentiometryCalibrationValues(3) = rxBuffer(6)*(2^4)+...
        bitand(rxBuffer(7),hex2dec('F0'))*(2^(-4));

    PotentiometryCalibrationValues(4) = ...
        bitand(rxBuffer(7),hex2dec('0F'))*(2^8)+rxBuffer(8);

    PotentiometryCalibrationValues(5) = rxBuffer(9)*(2^4)+...
        bitand(rxBuffer(10),hex2dec('F0'))*(2^(-4));

    PotentiometryCalibrationValues(6) = ...
        bitand(rxBuffer(10),hex2dec('0F'))*(2^8)+rxBuffer(11);

    PotentiometryCalibrationValues(7) = rxBuffer(12)*(2^4)+...
        bitand(rxBuffer(13),hex2dec('F0'))*(2^(-4));

    PotentiometryCalibrationValues(8) = ...
        bitand(rxBuffer(13),hex2dec('0F'))*(2^8)+rxBuffer(14);

    PotentiometryCalibrationValues(9) = rxBuffer(15)*(2^4)+...
        bitand(rxBuffer(16),hex2dec('F0'))*(2^(-4));
    
    handles.phbSavePotAutocalib.Enable = 'on';
    plotCalibration('Potentiometry',handles);
end

