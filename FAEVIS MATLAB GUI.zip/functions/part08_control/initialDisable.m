%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief IDM UPV PhD. Disables unneeded buttons at %
%      the begining.                                 %
%   @version 03rd February 2020                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function initialDisable(handles)
    handles.rdbOtherCalibration.Enable = 'off';
    
    handles.phbSet0000.Enable = 'off';
    handles.phbSet0256.Enable = 'off';
    handles.phbSet0768.Enable = 'off';
    handles.phbSet1280.Enable = 'off';
    handles.phbSet1792.Enable = 'off';
    handles.phbSet2048.Enable = 'off';
    handles.phbSet2304.Enable = 'off';
    handles.phbSet2816.Enable = 'off';
    handles.phbSet3328.Enable = 'off';
    handles.phbSet3840.Enable = 'off';
    handles.phbSet4095.Enable = 'off';
    
    handles.edtSet0000.Enable = 'off';
    handles.edtSet0256.Enable = 'off';
    handles.edtSet0768.Enable = 'off';
    handles.edtSet1280.Enable = 'off';
    handles.edtSet1792.Enable = 'off';
    handles.edtSet2048.Enable = 'off';
    handles.edtSet2304.Enable = 'off';
    handles.edtSet2816.Enable = 'off';
    handles.edtSet3328.Enable = 'off';
    handles.edtSet3840.Enable = 'off';
    handles.edtSet4095.Enable = 'off';
    
    handles.phbSaveDACCalibration.Enable = 'off';
    
    handles.uibCurrentScale.Enable = 'off';
    
    handles.phbSavePotentiometryCalibration.Enable = 'off';
    
    handles.phbSavePotAutocalib.Enable = 'off';
    handles.phbSaveCECMLargeScale.Enable = 'off';
    handles.phbSaveCECMPrecisionScale.Enable = 'off';
    handles.phbSaveCIAutocalib.Enable = 'off';
    
    handles.phbCIAutocalibration.Enable = 'off';
    
    handles.rdbCE.Enable = 'off';
    handles.rdbCM.Enable = 'off';
end

