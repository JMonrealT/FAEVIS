%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief IDM UPV PhD. Calibration plot.            %
%   @version 04th February 2020                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function plotCalibration(plotKind, handles)
    global DACValues PotentiometryCalibrationValues CMLargeCalibrationValues
    global CECalibrationValues CMPrecisionCalibrationValues lastPlot
    digitalValues = [0256 0768 1280 1792 2048 2304 2816 3328 3840];
    switch plotKind
        case 'DAC'
            idealVoltageValues = digitalValues/4095*5-2.5;
            hold(handles.pltMainPlot,'off')
            plot(handles.pltMainPlot,[0 digitalValues 4095],[-2.5 idealVoltageValues 2.5]);
            hold(handles.pltMainPlot,'on')
            plot(handles.pltMainPlot,digitalValues(1:length(DACValues)),DACValues);
            plot(handles.pltMainPlot,digitalValues(1:length(DACValues)),DACValues, ...
                'o', 'Color', 'red');
            hold(handles.pltMainPlot,'off')
            xlabel(handles.pltMainPlot,'Digital value (bits)')
            ylabel(handles.pltMainPlot,'Voltage (V)')
            xlim(handles.pltMainPlot,[0 4095])
            ylim(handles.pltMainPlot,[-2.5 2.5])
        case 'Potentiometry'
            lastPlot = plotKind;
            hold(handles.pltMainPlot,'off')
            plot(handles.pltMainPlot,[0 digitalValues 4095],[0 digitalValues 4095]);
            hold(handles.pltMainPlot,'on')
            plot(handles.pltMainPlot,digitalValues,PotentiometryCalibrationValues);
            plot(handles.pltMainPlot,digitalValues,PotentiometryCalibrationValues, ...
                'o', 'Color', 'red');
            hold(handles.pltMainPlot,'off')
            xlabel(handles.pltMainPlot,'DAC value (bits)')
            ylabel(handles.pltMainPlot,'Potentiometry ADC value (bits)')
            xlim(handles.pltMainPlot,[0 4095])
            ylim(handles.pltMainPlot,[0 4095])
        case 'CMPrecision'
            lastPlot = plotKind;
            hold(handles.pltMainPlot,'off')
            plot(handles.pltMainPlot,[0 digitalValues 4095],[0 digitalValues 4095]);
            hold(handles.pltMainPlot,'on')
            plot(handles.pltMainPlot,digitalValues,CMPrecisionCalibrationValues);
            plot(handles.pltMainPlot,digitalValues,CMPrecisionCalibrationValues, ...
                'o', 'Color', 'red');
            hold(handles.pltMainPlot,'off')
            xlabel(handles.pltMainPlot,'Ideal value (bits)')
            ylabel(handles.pltMainPlot,'Current precision scale ADC value (bits)')
            xlim(handles.pltMainPlot,[0 4095])
            ylim(handles.pltMainPlot,[0 4095])
        case 'CMLarge'
            lastPlot = plotKind;
            hold(handles.pltMainPlot,'off')
            plot(handles.pltMainPlot,[0 digitalValues 4095],[0 digitalValues 4095]);
            hold(handles.pltMainPlot,'on')
            plot(handles.pltMainPlot,digitalValues,CMLargeCalibrationValues);
            plot(handles.pltMainPlot,digitalValues,CMLargeCalibrationValues, ...
                'o', 'Color', 'red');
            hold(handles.pltMainPlot,'off')
            xlabel(handles.pltMainPlot,'Ideal value (bits)')
            ylabel(handles.pltMainPlot,'Current large scale ADC value (bits)')
            xlim(handles.pltMainPlot,[0 4095])
            ylim(handles.pltMainPlot,[0 4095])
            handles.rdbCM.Value = 1;
        case 'CE'
            lastPlot = plotKind;
            hold(handles.pltMainPlot,'off')
            plot(handles.pltMainPlot,flip([0 digitalValues 4095]),[0 digitalValues 4095]);
            hold(handles.pltMainPlot,'on')
            plot(handles.pltMainPlot,digitalValues,CECalibrationValues);
            plot(handles.pltMainPlot,digitalValues,CECalibrationValues, ...
                'o', 'Color', 'red');
            hold(handles.pltMainPlot,'off')
            xlabel(handles.pltMainPlot,'Ideal value (bits)')
            ylabel(handles.pltMainPlot,'CE ADC value (bits)')
            xlim(handles.pltMainPlot,[0 4095])
            ylim(handles.pltMainPlot,[0 4095])
    end
    grid(handles.pltMainPlot, 'on')
end

