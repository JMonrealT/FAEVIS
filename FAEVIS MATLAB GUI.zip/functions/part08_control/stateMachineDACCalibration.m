%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief IDM UPV PhD. Handles the enabling of      %
%      different fields to progressively fill them.  %
%   @version 01st February 2020                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function stateMachineDACCalibration(handles)
    global DACValue
    handles.edtDACValue.String = num2str(DACValue);
    switch DACValue
        case 0000
            handles.edtSet0000.Enable = 'on';
        case 0256
            handles.edtSet0256.Enable = 'on';
        case 0768
            handles.edtSet0768.Enable = 'on';
        case 1280
            handles.edtSet1280.Enable = 'on';
        case 1792
            handles.edtSet1792.Enable = 'on';
        case 2048
            handles.edtSet2048.Enable = 'on';
        case 2304
            handles.edtSet2304.Enable = 'on';
        case 2816
            handles.edtSet2816.Enable = 'on';
        case 3328
            handles.edtSet3328.Enable = 'on';
        case 3840
            handles.edtSet3840.Enable = 'on';
        case 4095
            handles.edtSet4095.Enable = 'on';
    end
end

