function closeSound()
    t = 1:0.3:750; sound(flip(t-1)/4000/2.*sin(t)); pause(0.2);
    t = 1:0.2:500; sound(flip(t-1)/2400/2.*sin(t));
end