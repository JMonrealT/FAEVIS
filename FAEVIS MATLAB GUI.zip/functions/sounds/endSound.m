function endSound()
    t = 1:0.33:1000; sound(flip(t-1)/800.*sin(t));  
end

