function errorSound()
    t = 1:1.5:1000; sound(flip(t-1)/4000.*sin(t)); pause(0.1);
    t = 1:1.5:1000; sound(flip(t-1)/4000.*sin(t)); pause(0.1);
    t = 1:1.5:2500; sound(flip(t-1)/5500.*sin(t)); 
end

