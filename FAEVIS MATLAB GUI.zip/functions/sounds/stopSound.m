function stopSound()
    t = 0:0.1:50; sound(flip(t-1)/10.*sin(t));
end
