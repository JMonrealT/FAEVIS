%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief IDM UPV PhD. Voltammetric techniques      %
%          device waveform main menu.                %
%   @version 09th July 2020                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function varargout = part01_general(varargin)
% PART01_GENERAL MATLAB code for part01_general.fig
%      PART01_GENERAL, by itself, creates a new PART01_GENERAL or raises the existing
%      singleton*.
%
%      H = PART01_GENERAL returns the handle to a new PART01_GENERAL or the handle to
%      the existing singleton*.
%
%      PART01_GENERAL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PART01_GENERAL.M with the given input arguments.
%
%      PART01_GENERAL('Property','Value',...) creates a new PART01_GENERAL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before part01_general_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to part01_general_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help part01_general

% Last Modified by GUIDE v2.5 09-Jul-2020 14:32:12

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @part01_general_OpeningFcn, ...
                   'gui_OutputFcn',  @part01_general_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before part01_general is made visible.
function part01_general_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to part01_general (see VARARGIN)

% Choose default command line output for part01_general
handles.output = hObject;

global appFreeFlag
appFreeFlag = 1;

% Update handles structure
guidata(hObject, handles);
initialSound();

% UIWAIT makes part01_general wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = part01_general_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pbSimpleExperienceElectrostimulation.
function pbSimpleExperienceElectrostimulation_Callback(hObject, eventdata, handles)
% hObject    handle to pbSimpleExperienceElectrostimulation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global appFreeFlag
if(appFreeFlag)
    part05_ES_App;
    appFreeFlag = 0;
else
    errorSound(); warndlg('Application window currently open!');
end

% --- Executes on button press in pbExperienceDesignerElectrostimulation.
function pbExperienceDesignerElectrostimulation_Callback(hObject, eventdata, handles)
% hObject    handle to pbExperienceDesignerElectrostimulation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pbExperienceDesignerElectrochemistry.
function pbExperienceDesignerElectrochemistry_Callback(hObject, eventdata, handles)
% hObject    handle to pbExperienceDesignerElectrochemistry (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
part02_EQ_WC;


% --- Executes on button press in pbSimpleExperienceElectrochemistry.
function pbSimpleExperienceElectrochemistry_Callback(hObject, eventdata, handles)
% hObject    handle to pbSimpleExperienceElectrochemistry (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global appFreeFlag
if(appFreeFlag)
    part03_EQ_App;
    appFreeFlag = 0;
else
    errorSound(); warndlg('Application window currently open!');
end

% --- Executes on button press in pbExecuteComplexExperience.
function pbExecuteComplexExperience_Callback(hObject, eventdata, handles)
% hObject    handle to pbExecuteComplexExperience (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global appFreeFlag
if(appFreeFlag)
    part07_Combined_App;
    appFreeFlag = 0;
else
    errorSound(); warndlg('Application window currently open!');
end

% --- Executes on button press in pbComplexExperienceDesigner.
function pbComplexExperienceDesigner_Callback(hObject, eventdata, handles)
% hObject    handle to pbComplexExperienceDesigner (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
closeSound();
% Hint: delete(hObject) closes the figure
delete(hObject);


% --- Executes on button press in phbCalibration.
function phbCalibration_Callback(hObject, eventdata, handles)
% hObject    handle to phbCalibration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global appFreeFlag
if(appFreeFlag)
    part08_Calibration;
    appFreeFlag = 0;
else
    errorSound(); warndlg('Application window currently open!');
end
