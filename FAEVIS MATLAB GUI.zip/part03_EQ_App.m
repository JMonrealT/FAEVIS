%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief IDM UPV PhD. Electrochemical techniques   %
%          application control interface.            %
%   @version 09th July 2020                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function varargout = part03_EQ_App(varargin)
% part03_EQ_App MATLAB code for part03_EQ_App.fig
%      part03_EQ_App, by itself, creates a new part03_EQ_App or raises the existing
%      singleton*.
%
%      H = part03_EQ_App returns the handle to a new part03_EQ_App or the handle to
%      the existing singleton*.
%
%      part03_EQ_App('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in part03_EQ_App.M with the given input arguments.
%
%      part03_EQ_App('Property','Value',...) creates a new part03_EQ_App or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before part03_EQ_App_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to part03_EQ_App_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help part03_EQ_App

% Last Modified by GUIDE v2.5 10-Feb-2020 15:35:57

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @part03_EQ_App_OpeningFcn, ...
                   'gui_OutputFcn',  @part03_EQ_App_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before part03_EQ_App is made visible.
function part03_EQ_App_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to part03_EQ_App (see VARARGIN)

% Choose default command line output for part03_EQ_App
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

format long;

global EQ1ES0
EQ1ES0 = 1;

StartInitialTimer(handles)

% UIWAIT makes part03_EQ_App wait for user response (see UIRESUME)
% uiwait(handles.Framework);


% --- Outputs from this function are returned to the command line.
function varargout = part03_EQ_App_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in pumAvailableCOMs.
function pumAvailableCOMs_Callback(hObject, eventdata, handles)
% hObject    handle to pumAvailableCOMs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pumAvailableCOMs contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pumAvailableCOMs
% Close ports that might be open

global COM openedCOM
ActivePorts = instrfind; % Read active ports
if isempty(ActivePorts)==0 % Check if there are active ports
    if ~openedCOM
        fclose(ActivePorts); % Close active ports
        delete(ActivePorts) % Erase variable
        clear ActivePorts % Destroy variable
    end
end

COMs = get(hObject,'String');
sizeCOM = size(COMs);
sizeCOM = sizeCOM(1);
if(sizeCOM == 1)
    COM = COMs;
else
    COM = string(COMs{get(hObject,'Value')});
end
clearvars COMs % Clear variable


% --- Executes during object creation, after setting all properties.
function pumAvailableCOMs_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pumAvailableCOMs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

if(~isempty(seriallist))
    set(hObject,'String',seriallist);
    COMs = get(hObject,'String');
else
    set(hObject,'String','[none]');
    COMs = [];
end
global COM openedCOM 
if(~isempty(COMs))
    if(iscell(COMs))
        COM = string(COMs{get(hObject,'Value')});
    else
        COM = COMs;
    end
end
clearvars COMs % Clear variable
openedCOM = 0;

global stateFSM
stateFSM = 0;


% --- Executes on button press in phbConnectCOM.
function phbConnectCOM_Callback(hObject, eventdata, handles)
% hObject    handle to phbConnectCOM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

pumAvailableCOMs_Callback(handles.pumAvailableCOMs, eventdata, handles)

global COM PORT openedCOM

if(~openedCOM)
    % Config serial port
    if(strcmp(COM,'[none]')<=0)
        PORT=serial(COM); % Generate a serial object linked to COM              
        set(PORT,'BaudRate',115200); 
        set(PORT,'DataBits',8); 
        set(PORT,'Parity','none'); 
        set(PORT,'StopBits',1); 
        set(PORT,'FlowControl','none'); % RTS and DTS manually controlled
        set(PORT,'DataTerminalReady','off'); 
        set(PORT,'RequestToSend','on'); 
        PORT.BytesAvailableFcnCount = 20;  % Trigger of reception event when 1 byte received
        PORT.BytesAvailableFcnMode = 'byte'; % Trigger for number of bytes and not for enders
        set(PORT,'BytesAvailableFcn',{@inputHermesMessage,handles}); % Event triggers inputHermesMessage to treat it 
        fopen(PORT); % Opens port
        openedCOM = 1;
        rxState(handles,'sending');
        sendHermesMessage('areYouAlive',0,handles);
        rxState(handles,'waiting');
    else
        errorSound(); warndlg('No COM port detected or chosen.');
    end
else
    fclose(PORT); % Opens port
    delete(PORT)
    clear PORT
    openedCOM = 0;
    handles.phbConnectCOM.ForegroundColor = [0 0 0];
    handles.indWaveformLoaded.BackgroundColor = [0 0.3 0];
    handles.indSerial.BackgroundColor = [0 0.3 0];
    handles.pumAvailableCOMs.Enable = 'on';
    handles.phbScanCOMs.Enable = 'on';
    handles.psbStartExperience.Enable = 'on';
    handles.phbSaveResults.Enable = 'on';
    handles.rdbPotentiometryMode.Enable = 'on';
    handles.rdbVoltageApplication.Enable = 'on';
    allInteractivity(handles,'on');
    handles.phbLoadWaveform.Enable = 'on';
end


% --- Executes when user attempts to close Framework.
function Framework_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to Framework (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global PORT openedCOM appFreeFlag

if(openedCOM == 1)
    fclose(PORT);
    delete(PORT)
    clear PORT
    openedCOM = 0;
end

% Hint: delete(hObject) closes the figure
closeSound();
delete(hObject);
clc
% clear
appFreeFlag = 1;


% --- Executes on button press in psbStartExperience.
function psbStartExperience_Callback(hObject, eventdata, handles)
% hObject    handle to psbStartExperience (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global openedCOM
if(openedCOM)
    stateMachine(handles); 
else
    errorSound(); warndlg('First, click on green button CONNECT to connect with the USB.'); 
end


% --- Executes on selection change in pumPotentiometrySelection.
function pumPotentiometrySelection_Callback(hObject, eventdata, handles)
% hObject    handle to pumPotentiometrySelection (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pumPotentiometrySelection contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pumPotentiometrySelection
global PotentiometryExperience tp
ExperienceOptions = get(hObject,'String');
PotentiometryExperience = string(ExperienceOptions{get(hObject,'Value')});


% --- Executes during object creation, after setting all properties.
function pumPotentiometrySelection_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pumPotentiometrySelection (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global PotentiometryExperience
ExperienceOptions = get(hObject,'String');
PotentiometryExperience = string(ExperienceOptions{get(hObject,'Value')});


% --- Executes on button press in rdbLargeScale.
function rdbLargeScale_Callback(hObject, eventdata, handles)
% hObject    handle to rdbLargeScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rdbLargeScale
global CurrentScale
CurrentScale = hex2dec('11');


% --- Executes on button press in rdbPrecisionScale.
function rdbPrecisionScale_Callback(hObject, eventdata, handles)
% hObject    handle to rdbPrecisionScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rdbPrecisionScale
global CurrentScale 
CurrentScale = hex2dec('22');


% --- Executes during object creation, after setting all properties.
function rdbLargeScale_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rdbLargeScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
global CurrentScale
if(get(hObject,'Value'))
    CurrentScale = hex2dec('11');
else
    CurrentScale = hex2dec('22');
end


function edtPotentiometryTimeout_Callback(hObject, eventdata, handles)
% hObject    handle to edtPotentiometryTimeout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtPotentiometryTimeout as text
%        str2double(get(hObject,'String')) returns contents of edtPotentiometryTimeout as a double
global PotentiometryTimeout PotentiometryTimeout_250ms
PotentiometryTimeout = str2num(get(hObject,'String'));
if(PotentiometryTimeout>2^16*0.25) 
    PotentiometryTimeout = 2^16*0.25;
    set(hObject,'String',num2str(PotentiometryTimeout));
end
if(PotentiometryTimeout<0.25) 
    PotentiometryTimeout = 0.25;
    set(hObject,'String',num2str(PotentiometryTimeout));
end
PotentiometryTimeout_250ms = PotentiometryTimeout/0.25;

% --- Executes during object creation, after setting all properties.
function edtPotentiometryTimeout_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtPotentiometryTimeout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global PotentiometryTimeout PotentiometryTimeout_250ms 
PotentiometryTimeout = str2num(get(hObject,'String'));
if(PotentiometryTimeout>2^16*0.25) 
    PotentiometryTimeout = 2^16*0.25;
    set(hObject,'String',num2str(PotentiometryTimeout));
end
if(PotentiometryTimeout<0.25) 
    PotentiometryTimeout = 0.25;
    set(hObject,'String',num2str(PotentiometryTimeout));
end
PotentiometryTimeout_250ms = PotentiometryTimeout/0.25;


function edtVoltageVariation_Callback(hObject, eventdata, handles)
% hObject    handle to edtVoltageVariation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtVoltageVariation as text
%        str2double(get(hObject,'String')) returns contents of edtVoltageVariation as a double
global VoltageVariationPotentiometry 
VoltageVariationPotentiometry = str2num(get(hObject,'String'));
if(VoltageVariationPotentiometry>255) 
    VoltageVariationPotentiometry = 255;
    set(hObject,'String',num2str(VoltageVariationPotentiometry));
end
if(VoltageVariationPotentiometry<=0) 
    VoltageVariationPotentiometry = 1;
    set(hObject,'String',num2str(VoltageVariationPotentiometry));
end


% --- Executes during object creation, after setting all properties.
function edtVoltageVariation_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtVoltageVariation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global VoltageVariationPotentiometry 
VoltageVariationPotentiometry = str2num(get(hObject,'String'));
if(VoltageVariationPotentiometry>255) 
    VoltageVariationPotentiometry = 255;
    set(hObject,'String',num2str(VoltageVariationPotentiometry));
end
if(VoltageVariationPotentiometry<=0) 
    VoltageVariationPotentiometry = 1;
    set(hObject,'String',num2str(VoltageVariationPotentiometry));
end


function edtAveraginSamples_Callback(hObject, eventdata, handles)
% hObject    handle to edtAveraginSamples (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtAveraginSamples as text
%        str2double(get(hObject,'String')) returns contents of edtAveraginSamples as a double
global AveragingSamplesPotentiometry
AveragingSamplesPotentiometry = str2num(get(hObject,'String'));
if(AveragingSamplesPotentiometry>255) 
    AveragingSamplesPotentiometry = 255;
    set(hObject,'String',num2str(AveragingSamplesPotentiometry));
end
if(AveragingSamplesPotentiometry<=0) 
    AveragingSamplesPotentiometry = 1;
    set(hObject,'String',num2str(AveragingSamplesPotentiometry));
end


% --- Executes during object creation, after setting all properties.
function edtAveraginSamples_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtAveraginSamples (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global AveragingSamplesPotentiometry 
AveragingSamplesPotentiometry = str2num(get(hObject,'String'));
if(AveragingSamplesPotentiometry>255) 
    AveragingSamplesPotentiometry = 255;
    set(hObject,'String',num2str(AveragingSamplesPotentiometry));
end
if(AveragingSamplesPotentiometry<=0) 
    AveragingSamplesPotentiometry = 1;
    set(hObject,'String',num2str(AveragingSamplesPotentiometry));
end


function edtSampleTime_Callback(hObject, eventdata, handles)
% hObject    handle to edtSampleTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtSampleTime as text
%        str2double(get(hObject,'String')) returns contents of edtSampleTime as a double
global PotentiometrySampleTime 
PotentiometrySampleTime = str2num(get(hObject,'String'));
if(PotentiometrySampleTime>65000) 
    PotentiometrySampleTime = 65000;
    set(hObject,'String',num2str(PotentiometrySampleTime));
end
if(PotentiometrySampleTime<1) 
    PotentiometrySampleTime = 1;
    set(hObject,'String',num2str(PotentiometrySampleTime));
end


% --- Executes during object creation, after setting all properties.
function edtSampleTime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtSampleTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global PotentiometrySampleTime 
PotentiometrySampleTime = str2num(get(hObject,'String'));
if(PotentiometrySampleTime>65000) 
    PotentiometrySampleTime = 65000;
    set(hObject,'String',num2str(PotentiometrySampleTime));
end
if(PotentiometrySampleTime<1) 
    PotentiometrySampleTime = 1;
    set(hObject,'String',num2str(PotentiometrySampleTime));
end


% --- Executes on button press in phbLoadWaveform.
function phbLoadWaveform_Callback(hObject, eventdata, handles)
% hObject    handle to phbLoadWaveform (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global WAVEFORM PeriodNumberOfPoints SampleTime NumberOfPeriods WaveformLoaded
global WAVEFORM_ptr WAVEFORM_DAC WaveformNumberOfPoints waveformNsequence
global WaveformLoadRequested WaveformSent AppliedWaveform
global LoadParameters CalibrationLoaded NumberOfPeriodsMultiplier
global DACValuesRead 
try
    [file,path] = uigetfile('*.ech', 'Pick active electrochemical experience file (.ech).');
    if(~contains(file,'.ech'))
        errorSound(); warndlg('Selected file is not .ech.'); 
    else
        file = strcat(path,'\',file);
        fd = fopen(file);
        if(fd==-1)
            errorSound(); warndlg('Impossible to open selected file.');
            handles.indWaveformLoaded.BackgroundColor = [0 0.3 0];
            WAVEFORM = 0; 
            PeriodNumberOfPoints = 0; 
            SampleTime = 0;
            NumberOfPeriods = 0;
            WaveformLoaded = 0;
        else
            SampleTime = textscan(fd,'%d',1,'Delimiter','\n');
            SampleTime = SampleTime{1};
            NumberOfPeriods = textscan(fd,'%d',1,'Delimiter','\n');
            NumberOfPeriods = NumberOfPeriods{1};
            NumberOfPeriodsMultiplier = textscan(fd,'%d',1,'Delimiter','\n');
            NumberOfPeriodsMultiplier = NumberOfPeriodsMultiplier{1};
            PeriodNumberOfPoints = textscan(fd,'%d',1,'Delimiter','\n');
            PeriodNumberOfPoints = PeriodNumberOfPoints{1};

            str = '';
            for i=4:(PeriodNumberOfPoints+3)
                str = strcat(str,'%d ');
            end
            WAVEFORM = textscan(fd,str,'Delimiter',',');
            WaveformLoaded = 1;
            handles.indWaveformLoaded.BackgroundColor = [0 0 1]; 
            fclose(fd);

            AppliedWaveform = repmat(WAVEFORM,NumberOfPeriods); 
            AppliedWaveform = AppliedWaveform(1,:)';
            AppliedWaveform = cell2mat(AppliedWaveform(:))';

            WAVEFORM_ptr = 1;
            WaveformNumberOfPoints = length(WAVEFORM);
            WAVEFORM_DAC = (cell2mat(WAVEFORM) + 2500)/(5000/4095);
            WAVEFORM_mV = double(cell2mat(WAVEFORM))/1e3;
            waveformNsequence = 0;
            WaveformSent = 0;
            
            if(CalibrationLoaded)
                x = [256,768,1280,1792,2048,2304,2816,3328,3840];
                v = DACValuesRead;
                xq = 256:3840;
                vq = interp1(x,v,xq,'spline');
                xq = [1:255 xq]; vq = [(1:255)*0-2.5 vq]; 
                % plot(x,v,'o',xq,vq,':.');
                for i = 1:WaveformNumberOfPoints
                    if(and(WAVEFORM_DAC(i)>256,WAVEFORM_DAC(i)<3840))
                        dist = abs(vq - WAVEFORM_mV(i));
                        minDist = min(dist);
                        WAVEFORM_DAC(i) = find(dist == minDist);
                    end
                end
            end
            
            handles.phbLoadWaveform.Enable = 'off';
            previewLoadingWaveform(handles);
            if(LoadParameters)             
                rxState(handles,'sending');
                sendHermesMessage('stopExperience',0,handles);
                rxState(handles,'waiting');
                WaveformLoadRequested = 1;
                handles.psbStartExperience.Enable = 'off';
                handles.phbSaveResults.Enable = 'off';  
            else
                handles.indWaveformLoaded.BackgroundColor = [0 0.3 0];
                handles.psbStartExperience.Enable = 'on';
                handles.phbSaveResults.Enable = 'on';
                handles.rdbPotentiometryMode.Enable = 'on';
                handles.rdbVoltageApplication.Enable = 'on';
                handles.phbLoadWaveform.Enable = 'on';
            end
        end
    end
catch
    handles.psbStartExperience.Enable = 'on';
    handles.phbSaveResults.Enable = 'on';
    handles.rdbPotentiometryMode.Enable = 'on';
    handles.rdbVoltageApplication.Enable = 'on';
end

% --- Executes during object creation, after setting all properties.
function phbLoadWaveform_CreateFcn(hObject, eventdata, handles)
% hObject    handle to chkCorrectOCP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
global WAVEFORM PeriodNumberOfPoints SampleTime NumberOfPeriods 
global WaveformLoaded WaveformSent eqTransmission txStopTransmission
global CERequest CurrentRequest alternationFlag AEEnded PotEnded
WAVEFORM = 0; 
PeriodNumberOfPoints = 0; 
SampleTime = 0;
NumberOfPeriods = 0;
WaveformLoaded = 0;
WaveformSent = 0;
eqTransmission = 0;
txStopTransmission = 0;
CERequest = 0;
CurrentRequest = 0;
alternationFlag = 0;
AEEnded = 0;
PotEnded = 0;


% --- Executes on button press in psbStopExperience.
function psbStopExperience_Callback(hObject, eventdata, handles)
% hObject    handle to psbStopExperience (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Timer_1s openedCOM
if(~isempty(Timer_1s))   
    if(isvalid(Timer_1s))
        stop(Timer_1s); delete(Timer_1s); 
        clear Timer_1s
    else
        clear Timer_1s
    end
end
if(openedCOM)
    stopSound();
    rxState(handles,'sending');
    sendHermesMessage('stopExperience',0,handles);
    rxState(handles,'waiting');
else
    errorSound(); warndlg('First, click on green button CONNECT to connect with the USB.'); 
end


% --- Executes on button press in phbSaveResults.
function phbSaveResults_Callback(hObject, eventdata, handles)
% hObject    handle to phbSaveResults (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global PotentiometryExperience PotentiometrySampleTime tp tc 
global CurrentScale ActiveExperience AppliedWaveform ExperienceMode
global PotentiometryWaveform3V CEVoltageWaveform3V CurrentWaveform3V
global SampleTime NumberOfPeriods WaveformNumberOfPoints AEEnded PotEnded
if(strcmp(ExperienceMode,'Potentiometry'))   
    txtend = '*.per';
else
    txtend = '*.aer';
end
if(or(and(strcmp(ExperienceMode,'Potentiometry'),PotEnded),...
        and(strcmp(ExperienceMode,'Active'),AEEnded)))
    [file,path,flag] = uiputfile(txtend, 'Set direction to save the results.');
    if(flag == 1)
        file = strcat(path,'\',file);
        fd = fopen(file,'w+');
        if(fd==-1)
            errorSound(); vwarndlg('Impossible to open selected file.'); 
        else
            fprintf(fd,'%s.\r\n',datestr(clock));
            fprintf(fd,'\r\n');
        if(strcmp(ExperienceMode,'Potentiometry'))    
            if(~isempty(tp))
                fprintf(fd,'POTENTIOMETRY: %s.\r\n',PotentiometryExperience);
                fprintf(fd,'\tSample time (ms): %d.\r\n',PotentiometrySampleTime);
                fprintf(fd,'\tNumber of samples: %d.\r\n',length(PotentiometryWaveform3V));
                fprintf(fd,'Measurements (V): ');
                for i=1:length(PotentiometryWaveform3V)
                    if(i<length(PotentiometryWaveform3V))
                        fprintf(fd,'%.3f,',double(PotentiometryWaveform3V(i))/1000);
                    else
                        fprintf(fd,'%.3f.',double(PotentiometryWaveform3V(i))/1000);
                    end
                end
            end
        else
            if(~isempty(tc))
                fprintf(fd,'ACTIVE EXPERIENCE: %s.\r\n',ActiveExperience);
                fprintf(fd,'\tSample time (us): %d.\r\n',SampleTime); 
                fprintf(fd,'\tNumber of points: %d.\r\n',WaveformNumberOfPoints);
                fprintf(fd,'\tNumber of cycles: %d.\r\n',NumberOfPeriods);
                if(CurrentScale==17)
                    fprintf(fd,'\tCurrent Scale: Large (+-2.5mA).\r\n');
                else
                    fprintf(fd,'\tCurrent Scale: Precision (+-25uA).\r\n');
                end
                fprintf(fd,'Waveform applied (V): ');
                for i=1:length(AppliedWaveform)
                    if(i<length(AppliedWaveform))
                        fprintf(fd,'%.3f,',double(AppliedWaveform(i))/1000);
                    else
                        fprintf(fd,'%.3f.',double(AppliedWaveform(i))/1000);
                    end
                end
                fprintf(fd,'\r\n\r\n');
                if(CurrentScale==17)
                    fprintf(fd,'Current measurements (mA): ');
                else
                    fprintf(fd,'Current measurements (uA): ');
                end
                for i=1:length(CurrentWaveform3V)
                    if(i<length(CurrentWaveform3V))
                        fprintf(fd,'%.3f,',double(CurrentWaveform3V(i)));
                    else
                        fprintf(fd,'%.3f.',double(CurrentWaveform3V(i)));
                    end
                end
                fprintf(fd,'\r\n\r\n');
                fprintf(fd,'CE Voltage (V): ');
                for i=1:length(CEVoltageWaveform3V)
                    if(i<length(CEVoltageWaveform3V))
                        fprintf(fd,'%.3f,',double(CEVoltageWaveform3V(i))/1000);
                    else
                        fprintf(fd,'%.3f.',double(CEVoltageWaveform3V(i))/1000);
                    end
                end
            end
        end    
            fprintf(fd,'\r\n\nEOF');
            fclose(fd);
        end
    end
else
    if(strcmp(ExperienceMode,'Potentiometry'))
        errorSound(); warndlg('No potentiometry data to save.'); 
    else
        errorSound(); warndlg('No active experience data to save.'); 
    end
end

% --- Executes on button press in chkCorrectOCP.
function chkCorrectOCP_Callback(hObject, eventdata, handles)
% hObject    handle to chkCorrectOCP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkCorrectOCP
global CorrectOCP
if(get(hObject,'Value'))
    CorrectOCP = '1';
else
    CorrectOCP = '0';
end


% --- Executes during object creation, after setting all properties.
function chkCorrectOCP_CreateFcn(hObject, eventdata, handles)
% hObject    handle to chkCorrectOCP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
global CorrectOCP
CorrectOCP = '0';


% --- Executes on selection change in pumActiveExperienceSelection.
function pumActiveExperienceSelection_Callback(hObject, eventdata, handles)
% hObject    handle to pumActiveExperienceSelection (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pumActiveExperienceSelection contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pumActiveExperienceSelection
global ActiveExperience
ExperienceOptions = get(hObject,'String');
ActiveExperience = string(ExperienceOptions{get(hObject,'Value')});


% --- Executes during object creation, after setting all properties.
function pumActiveExperienceSelection_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pumActiveExperienceSelection (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global ActiveExperience 
ExperienceOptions = get(hObject,'String');
ActiveExperience = string(ExperienceOptions{get(hObject,'Value')});


% --- Executes on button press in rdbPotentiometryMode.
function rdbPotentiometryMode_Callback(hObject, eventdata, handles)
% hObject    handle to rdbPotentiometryMode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rdbPotentiometryMode
global ExperienceMode PotEnded 
if(get(hObject,'Value')==1)
    handles.uipActiveEQExperience.Visible = 'off';
    handles.uipPotentiometryConfiguration.Visible = 'on';
    ExperienceMode = 'Potentiometry';
else
    handles.uipActiveEQExperience.Visible = 'on';
    handles.uipPotentiometryConfiguration.Visible = 'off';
    ExperienceMode = 'Active';
end
if(PotEnded)
    plotPotentiometry(handles);
end


% --- Executes on button press in rdbVoltageApplication.
function rdbVoltageApplication_Callback(hObject, eventdata, handles)
% hObject    handle to rdbVoltageApplication (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rdbVoltageApplication
global ExperienceMode AEEnded
if(get(hObject,'Value')==1)
    handles.uipActiveEQExperience.Visible = 'on';
    handles.uipPotentiometryConfiguration.Visible = 'off';
    ExperienceMode = 'Active';
else
    handles.uipActiveEQExperience.Visible = 'off';
    handles.uipPotentiometryConfiguration.Visible = 'on';
    ExperienceMode = 'Potentiometry';
end
if(AEEnded)
    plotActiveExperience(handles);
end


% --- Executes during object creation, after setting all properties.
function rdbVoltageApplication_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rdbVoltageApplication (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
global ExperienceMode
ExperienceMode = 'Potentiometry';


% --- Executes on button press in phbScanCOMs.
function phbScanCOMs_Callback(hObject, eventdata, handles)
% hObject    handle to phbScanCOMs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% if ispc && isequal(get(hObject,'BackgroundColor'), ...
%         get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
global COM openedCOM PORT
try
    port = PORT.Port;
catch
    port = [];
end
if(isempty(port))
    if(~openedCOM)
        if(~isempty(seriallist))
            set(handles.pumAvailableCOMs,'String',seriallist);
            COMs = get(handles.pumAvailableCOMs,'String');
        else
            set(handles.pumAvailableCOMs,'String','[none]');
            COMs = [];
        end
        if(~isempty(COMs))
            if(iscell(COMs))
                COM = string(COMs{get(handles.pumAvailableCOMs,'Value')});
            else
                COM = COMs;
            end
            set(handles.pumAvailableCOMs,'Value',1);
        end
    end
else
    errorSound(); warndlg('First, click on green button CONNECT to disconnect.'); 
end


% --- Executes on button press in chkTimeout.
function chkTimeout_Callback(hObject, eventdata, handles)
% hObject    handle to chkTimeout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkTimeout
global TimeoutChk
TimeoutChk = get(hObject,'Value');
if(TimeoutChk)
    handles.edtPotentiometryTimeout.Enable = 'on';
else
    handles.edtPotentiometryTimeout.Enable = 'off';
end


% --- Executes on button press in chkVoltageVariation.
function chkVoltageVariation_Callback(hObject, eventdata, handles)
% hObject    handle to chkVoltageVariation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkVoltageVariation
global AverageChk
AverageChk = get(hObject,'Value');
if(AverageChk)
    handles.edtVoltageVariation.Enable = 'on';
    handles.edtAveraginSamples.Enable = 'on';
else
    handles.edtVoltageVariation.Enable = 'off';
    handles.edtAveraginSamples.Enable = 'off';
end


% --- Executes during object creation, after setting all properties.
function chkTimeout_CreateFcn(hObject, eventdata, handles)
% hObject    handle to chkTimeout (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
global TimeoutChk
TimeoutChk = get(hObject,'Value');


% --- Executes during object creation, after setting all properties.
function chkVoltageVariation_CreateFcn(hObject, eventdata, handles)
% hObject    handle to chkVoltageVariation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
global AverageChk
AverageChk = get(hObject,'Value');


% --- Executes on button press in phbLoadPastResults.
function phbLoadPastResults_Callback(hObject, eventdata, handles)
% hObject    handle to phbLoadPastResults (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try
    [file,path] = uigetfile({'*.per';'*.aer'}, 'Pick results to be plotted (.per or .aer).');
    if(contains(file,'.per'))
        file = strcat(path,'\',file);
        fd = fopen(file);
        if(fd==-1)
            errorSound(); warndlg('Impossible to open selected file.');
        else
            textscan(fd,'%s',1,'Delimiter','.'); 
            textscan(fd,'%s',1,'Delimiter',':');
            PotentiometryExperience = textscan(fd,'%s',1,'Delimiter','.');
            PotentiometryExperience = PotentiometryExperience{1};
            textscan(fd,'%s',1,'Delimiter',':');
            SampleTime_ms = textscan(fd,'%d',1,'Delimiter','.');
            SampleTime_ms = SampleTime_ms{1};
            textscan(fd,'%s',1,'Delimiter',':');
            NumberOfSamples = textscan(fd,'%d',1,'Delimiter','.');
            NumberOfSamples = NumberOfSamples{1};
            textscan(fd,'%s',1,'Delimiter',':');

            str = '';
            for i=1:NumberOfSamples
                str = strcat(str,'%f,');
            end
            str = strcat(str,'\n');
            PotentiometryWaveform = textscan(fd,str,'Delimiter','\n');
            PotentiometryWaveform = PotentiometryWaveform(1,:)';
            PotentiometryWaveform = cell2mat(PotentiometryWaveform(:))';
            
            fclose(fd);
            
            tp = SampleTime_ms:SampleTime_ms:(NumberOfSamples)*SampleTime_ms;
            timeUnits = 'Time (ms)';        
            if(max(tp)>1e4)
                tp = double(tp) / 1000; timeUnits = 'Time (s)';
                if(max(tp)>600)
                    tp = double(tp) / 60; timeUnits = 'Time (min)';
                end
            end
            potFigh = figure(1); potAxesh = axes(potFigh);
            plot(potAxesh,tp,PotentiometryWaveform,'Color','b');
                potAxesh.XLim = [0 max(tp)];
                potAxesh.YLim = ...
                    [min(PotentiometryWaveform)-0.005 ...
                    max(PotentiometryWaveform)+0.005];
            xlabel(potAxesh,timeUnits);
            title(potAxesh,PotentiometryExperience)
            ylabel(potAxesh,'Voltage (V)')
            legend(potAxesh,'Potentiometry (V)','Location','nortwest')
            grid(potAxesh, 'on')
        end
    elseif(contains(file,'.aer'))
        file = strcat(path,'\',file);
        fd = fopen(file);
        if(fd==-1)
            errorSound(); warndlg('Impossible to open selected file.');
        else
            textscan(fd,'%s',1,'Delimiter','.'); 
            textscan(fd,'%s',1,'Delimiter',':');
            ActiveExperience = textscan(fd,'%s',1,'Delimiter','.');
            ActiveExperience = ActiveExperience{1};
            textscan(fd,'%s',1,'Delimiter',':');
            SampleTime_us = textscan(fd,'%d',1,'Delimiter','.');
            SampleTime_us = SampleTime_us{1};
            textscan(fd,'%s',1,'Delimiter',':');
            NumberOfSamples = textscan(fd,'%d',1,'Delimiter','.');
            NumberOfSamples = NumberOfSamples{1};
            textscan(fd,'%s',1,'Delimiter',':');
            NumberOfCycles = textscan(fd,'%d',1,'Delimiter','.');
            NumberOfCycles = NumberOfCycles{1};
            textscan(fd,'%s',1,'Delimiter',':');
            CurrentScale = textscan(fd,'%s',1,'Delimiter','\n');
            CurrentScale = CurrentScale{1};
            textscan(fd,'%s',1,'Delimiter',':');
            
            str = '';
            for i=1:NumberOfSamples*NumberOfCycles
                str = strcat(str,'%f,');
            end
            str = strcat(str,'\n');
            AppliedWaveform = textscan(fd,str,'Delimiter','\n');
            AppliedWaveform = AppliedWaveform(1,:)';
            AppliedWaveform = cell2mat(AppliedWaveform(:))';
            
            textscan(fd,'%s',1,'Delimiter','.');
            textscan(fd,'%s',1,'Delimiter',':');
            
            CurrentWaveform = textscan(fd,str,'Delimiter','\n');
            CurrentWaveform = CurrentWaveform(1,:)';
            CurrentWaveform = cell2mat(CurrentWaveform(:))';
            
            textscan(fd,'%s',1,'Delimiter','.');
            textscan(fd,'%s',1,'Delimiter',':');
            
            CEWaveform = textscan(fd,str,'Delimiter','\n');
            CEWaveform = CEWaveform(1,:)';
            CEWaveform = cell2mat(CEWaveform(:))';
            
            fclose(fd);
            
            actFigh = figure(2); actAxesh = axes(actFigh);
            tv = SampleTime_us:SampleTime_us:NumberOfSamples*NumberOfCycles*SampleTime_us;
            if(tv(end)>1e4)
                tv = double(tv) / 1000; 
                xlabel(actAxesh,'Time (ms)')
                if(tv(end)>1e4)
                    tv = double(tv) / 1000; 
                    xlabel(actAxesh,'Time (s)')
                    if(tv(end)>600)
                        tv = tv / 1000; 
                        xlabel(actAxesh,'Time (minutes)')
                    end
                end
            end
            yyaxis(actAxesh,'left')
                plot(actAxesh,tv(1:length(CEWaveform)),CEWaveform,'Color','b');
                hold(actAxesh,'on');
                plot(actAxesh,tv(1:length(CEWaveform)),AppliedWaveform(1:length(CEWaveform)),'Color','g');
                hold(actAxesh,'off');
                title(actAxesh,ActiveExperience)
                ylabel(actAxesh,'Voltage (V)')
            yyaxis(actAxesh,'right')
                plot(actAxesh,tv(1:length(CurrentWaveform)),CurrentWaveform,'Color','r');               
            if(strcmp(CurrentScale,'Large (+-2.5mA)')) % large scale
                ylabel(actAxesh,'Current (mA)') 
                currentLegend = 'Current (mA)';
            else
                ylabel(actAxesh,'Current (uA)') 
                currentLegend = 'Current (uA)';
            end
            legend(actAxesh,'CE Voltage (V)', 'Applied Voltage (V)',...
                currentLegend,'Location','northwest')
            actAxesh.YAxis(2).Color = [0 0 0];%[0.85 0.325 0.098];
            actAxesh.YAxis(1).Color = [0 0 0];
            grid(actAxesh, 'on')
        end
    else
        errorSound(); warndlg('Selected file is not .per neither .aer.');    
    end
catch
end


% --- Executes on button press in phbLoadCalibration.
function phbLoadCalibration_Callback(hObject, eventdata, handles)
% hObject    handle to phbLoadCalibration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global CalibrationLoaded
global DACValuesRead POTValuesRead
global CEValuesRead CMLValuesRead RWEREL RCEREL
global CMPValuesRead RWEREP RCEREP
global CIValuesRead RCI xCalibrated
try
    [file,path] = uigetfile('*.mcf', 'Pick a mixed calibration file (.mcf).');
    if(~contains(file,'.mcf'))
        errorSound(); warndlg('Selected file is not .dcf.'); 
    else
        fd = fopen(strcat(path,'\',file));
        if(fd==-1)
            errorSound(); warndlg('Impossible to open selected file.');
        else
            textscan(fd,'%s\n','Delimiter','\n');
            DACValuesRead = [];
            tmp = cell2mat(textscan(fd,'%f\n','Delimiter','\n'));
            if(tmp ~= -1)
                DACValuesRead(1) = tmp;
                for i=2:9
                    DACValuesRead(i) = cell2mat(textscan(fd,'%f\n','Delimiter','\n'));
                end
            end
            
            textscan(fd,'%s\n','Delimiter','\n');
            POTValuesRead = [];
            tmp = cell2mat(textscan(fd,'%d\n','Delimiter','\n'));
            if(tmp ~= -1)
                POTValuesRead(1) = tmp;
                for i=2:9
                    POTValuesRead(i) = cell2mat(textscan(fd,'%d\n','Delimiter','\n'));
                end
            end
            
            textscan(fd,'%s\n','Delimiter','\n');
            CEValuesRead = [];
            tmp = cell2mat(textscan(fd,'%f\n','Delimiter','\n'));
            if(tmp ~= -1)
                RWEREL = tmp;
                RCEREL = cell2mat(textscan(fd,'%f\n','Delimiter','\n'));
                for i=1:9
                    CEValuesRead(i) = cell2mat(textscan(fd,'%d\n','Delimiter','\n'));
                end
            end
            
            textscan(fd,'%s\n','Delimiter','\n');
            CMLValuesRead = [];
            tmp = cell2mat(textscan(fd,'%d\n','Delimiter','\n'));
            if(tmp ~= -1)
                CMLValuesRead(1) = tmp;
                for i=2:9
                    CMLValuesRead(i) = cell2mat(textscan(fd,'%d\n','Delimiter','\n'));
                end
            end
            
            textscan(fd,'%s\n','Delimiter','\n');
            CMPValuesRead = [];
            tmp = cell2mat(textscan(fd,'%f\n','Delimiter','\n'));
            if(tmp ~= -1)
                RWEREP = tmp;
                RCEREP = cell2mat(textscan(fd,'%f\n','Delimiter','\n'));
                for i=1:9
                    CMPValuesRead(i) = cell2mat(textscan(fd,'%d\n','Delimiter','\n'));
                end
            end
            
            textscan(fd,'%s\n','Delimiter','\n');
            CIValuesRead = [];
            tmp = cell2mat(textscan(fd,'%f\n','Delimiter','\n'));
            if(tmp ~= -1)
                RCI(1) = tmp;
                for i=1:9
                    CIValuesRead(i) = cell2mat(textscan(fd,'%f\n','Delimiter','\n'));
                end
            end
        end
        CalibrationLoaded = 1;
        handles.indLoadCalibration.BackgroundColor = [0 1 0];
        fclose(fd);
        
        x = [256,768,1280,1792,2048,2304,2816,3328,3840];
        v = DACValuesRead;
        xq = 256:3840;
        vq = interp1(x,v,xq,'spline');
        xq = [1:255 xq]; vq = [(1:255)*0-2.5 vq]; 
  
        xCalibrated = [];
        for i = 1:9
            dist = abs(vq - (double(x(i))/4095*5-2.5));
            minDist = min(dist);
            xCalibrated(i) = find(dist == minDist);
        end
    end
catch 
end


% --- Executes during object creation, after setting all properties.
function phbLoadCalibration_CreateFcn(hObject, eventdata, handles)
% hObject    handle to phbLoadCalibration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
global CalibrationLoaded
CalibrationLoaded = 0;
