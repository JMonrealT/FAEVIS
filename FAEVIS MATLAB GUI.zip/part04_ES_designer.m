%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief IDM UPV PhD. FAEVIS electrostimulation    %
%      experiences creator interface.                %
%   @version 08th July 2020                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function varargout = part04_ES_designer(varargin)
% part04_ES_designer MATLAB code for part04_ES_designer.fig
%      part04_ES_designer, by itself, creates a new part04_ES_designer or raises the existing
%      singleton*.
%
%      H = part04_ES_designer returns the handle to a new part04_ES_designer or the handle to
%      the existing singleton*.
%
%      part04_ES_designer('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in part04_ES_designer.M with the given input arguments.
%
%      part04_ES_designer('Property','Value',...) creates a new part04_ES_designer or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before part04_ES_designer_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to part04_ES_designer_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help part04_ES_designer

% Last Modified by GUIDE v2.5 15-Jul-2020 10:24:03

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @part04_ES_designer_OpeningFcn, ...
                   'gui_OutputFcn',  @part04_ES_designer_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before part04_ES_designer is made visible.
function part04_ES_designer_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to part04_ES_designer (see VARARGIN)

% Choose default command line output for part04_ES_designer
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
initialSound();

% UIWAIT makes part04_ES_designer wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = part04_ES_designer_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in lstPoints.
function lstPoints_Callback(hObject, eventdata, handles)
% hObject    handle to lstPoints (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns lstPoints contents as cell array
%        contents{get(hObject,'Value')} returns selected item from lstPoints
global ChosenPoint TimeList
ChosenPoint = strsplit(hObject.String{get(hObject,'Value')});
ChosenPoint = ChosenPoint{1};

for k = 1:numel(TimeList)
  if(contains(ChosenPoint,'m'))
      s = split(ChosenPoint,'m'); s = s{1};
      num = str2double(s)*1e3;
  elseif(contains(ChosenPoint,'u'))
      s = split(ChosenPoint,'u'); s = s{1};
      num = str2double(s);
  else
      num = str2double(ChosenPoint)*1e6;
  end
  if(TimeList{k}==num)
      ind = k;
  end
end

try
    ChosenPoint = ind;
catch
    
end

if(isempty(ChosenPoint))
    ChosenPoint = 0;
end


% --- Executes during object creation, after setting all properties.
function lstPoints_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lstPoints (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pubRemovePoint.
function pubRemovePoint_Callback(hObject, eventdata, handles)
% hObject    handle to pubRemovePoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ChosenPoint VoltageList TimeList PeriodNumberOfPoints 
global NumberOfPeriods
if(ChosenPoint>0)
    VoltageList{ChosenPoint} = [];
    TimeList{ChosenPoint} = [];
    reorder_lstPoints(VoltageList, TimeList, PeriodNumberOfPoints, ...
        handles);
end


function reorder_lstPoints(VoltageLst, TimeList, PeriodNumberOfPoints, ...
    handles)
% VoltageList  cell array with amplitude in value in sample as cell
% handles    structure with handles and user data (see GUIDATA)
global sizelstPoints VoltageList NumberOfPeriodsMultiplier
global NumberOfPeriods SampleTime
cnt = 0;
[~,sizeVL] = size(VoltageLst);
for i=1:PeriodNumberOfPoints
    if(i<=sizeVL)
        if(not(isempty(VoltageLst{i})))
            cnt = cnt + 1;
            numberTimePoint = TimeList{i};
            if(numberTimePoint>=1e6)
                point2list = round(numberTimePoint/1e6,2);
                point2list = num2str(point2list);
            elseif(numberTimePoint>=1e3)
                point2list = round(numberTimePoint/1e3,2);
                point2list = strcat(num2str(point2list),'m');
            else
                point2list = round(numberTimePoint,2);
                if(point2list~=0)
                    point2list = strcat(num2str(point2list),'u');
                else
                    point2list = num2str(point2list);
                end
            end
            spaces_cnt = 6 - numel(point2list);
            spaces = {' '};
            for j = 1:spaces_cnt
                spaces = strcat(spaces,{' '});
            end
            if(VoltageLst{i}>=0)
                spaces = strcat(spaces,{' '});
            end
            spaces = string(spaces);
            handles.lstPoints.String{cnt+1} = ...
                point2list + spaces + num2str(VoltageLst{i});
        end
    end
end
sizelstPoints = size(handles.lstPoints.String);
sizelstPoints = sizelstPoints(1);
if(sizelstPoints>cnt+1)
    if(handles.lstPoints.Value == sizelstPoints)
        handles.lstPoints.Value = 1;
    end
    for i=cnt+2:sizelstPoints
        if(sizelstPoints>2)
            handles.lstPoints.String(i)=[];
        else
            handles.lstPoints.String(2)={'...'};
        end
    end
end
VoltageList = VoltageLst;
if(sizelstPoints>2)
    PlotWaveform(handles); 
end
setTxtTotalTime(handles, PeriodNumberOfPoints, NumberOfPeriods, NumberOfPeriodsMultiplier, SampleTime);
setTxtSampleTime(handles, PeriodNumberOfPoints, SampleTime);
generalPlot(handles);


function PlotWaveform(handles)
% handles    structure with handles and user data (see GUIDATA)
global VoltageList PeriodNumberOfPoints NumberOfPeriods Point_pos
global vector SampleTime Interpolation PointTimeUnits TimeList UnitsmVuAmA

VoltageLst = VoltageList;
[~,sizeVL] = size(VoltageLst);

if(sizeVL>1)
    if(sizeVL<PeriodNumberOfPoints)
        [Point_pos, TimeList, VoltageList, SampleTime] = recalculateLists(max(cell2mat(TimeList)), TimeList, VoltageList, PeriodNumberOfPoints);
        VoltageLst{PeriodNumberOfPoints} = {};
    end

    if(not(or(isempty(VoltageLst{PeriodNumberOfPoints}),isempty(VoltageLst{1}))))
        if(isempty(VoltageLst{1}))
            VoltageLst{1} = 0;
        end

        cnt = 0;
        for i = 1:PeriodNumberOfPoints%*NumberOfPeriods
            x(i) = i;
            if(not(isempty(VoltageLst{i})))
                cnt = cnt + 1;
                PositionsList(cnt) = i;
                VoltagesList(cnt) = VoltageLst{i};
            end
        end

        if(not(isempty(PositionsList)))
            if(strcmp(Interpolation,'Linear'))
                vector = interp1(PositionsList,VoltagesList,x,'linear');
            elseif(strcmp(Interpolation,'Piecewise'))
                vector = interp1(PositionsList,VoltagesList,x,'previous');
            else
                vector = interp1(PositionsList,VoltagesList,x,'spline');
                sizeVector = size(vector); sizeVector = sizeVector(2);
                for i = 1:sizeVector
                    if(vector(i)>2500)
                        vector(i)=2500;
                    end
                    if(vector(i)<-2500)
                        vector(i)=-2500;
                    end
                end
            end
            
            for i = 1:(PeriodNumberOfPoints)%*NumberOfPeriods+1)
                x(i) = i;
                plt_x(i) = (i-1)*SampleTime;
                vector(i) = vector(mod(i-1,PeriodNumberOfPoints)+1);
            end
            
            %figure;
            if(plt_x(end)>1e6)
                plot(handles.plotWaveform,plt_x/1e6,vector);
                xlabel(handles.plotWaveform,'Time (s)');
            elseif(plt_x(end)>1e3)
                plot(handles.plotWaveform,plt_x/1e3,vector);
                xlabel(handles.plotWaveform,'Time (ms)');
            else
                plot(handles.plotWaveform,plt_x,vector);
                xlabel(handles.plotWaveform,'Time (us)');
            end
            if(strcmp(UnitsmVuAmA,'mV'))
                ylabel(handles.plotWaveform,'Voltage (mV)');
            elseif(strcmp(UnitsmVuAmA,'nA'))
                ylabel(handles.plotWaveform,'Current (nA)');
            else
                ylabel(handles.plotWaveform,'Current (uA)');
            end
            grid(handles.plotWaveform,'on');
        end
        
    else
        plot(handles.plotWaveform,[0 0],[0 0]);
        xlabel(handles.plotWaveform,'Time (us)');
        if(strcmp(UnitsmVuAmA,'mV'))
            ylabel(handles.plotWaveform,'Voltage (mV)');
        elseif(strcmp(UnitsmVuAmA,'nA'))
            ylabel(handles.plotWaveform,'Current (nA)');
        else
            ylabel(handles.plotWaveform,'Current (uA)');
        end
        grid(handles.plotWaveform,'on');
        plot(handles.plotGeneral,[0 0],[0 0]);
        xlabel(handles.plotGeneral,'');
        ylabel(handles.plotGeneral,'');
        grid(handles.plotGeneral,'on');
    end
end


% --- Executes on button press in pubSave.
function pubSave_Callback(hObject, eventdata, handles)
% hObject    handle to pubSave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global vector
global NumberOfPeriods NumberOfPeriodsMultiplier
global PeriodNumberOfPoints 
global SampleTime RestTime Iterations
global UnitsmVuAmA
try
    if(isempty(vector))
        errorSound(); warndlg('Plot waveform has to be generated before saving it!'); 
    else
        prompt = {'Input file name to save:'};
        title = 'FAEVIS';
        dims = [1 35];
        definput = {''};
        file = inputdlg(prompt,title,dims,definput);
        file = file{1};
        if(file~=0)
            file = sprintf('%s.est',file);
            fileID = fopen(file,'w');

            fprintf(fileID,'%d\n',SampleTime);
            fprintf(fileID,'%d\n',NumberOfPeriods);
            fprintf(fileID,'%d\n',NumberOfPeriodsMultiplier);
            fprintf(fileID,'%d\n',PeriodNumberOfPoints);
            fprintf(fileID,'%s\n',UnitsmVuAmA);
            fprintf(fileID,'%d\n',RestTime);
            fprintf(fileID,'%d\n',Iterations);

            for i=1:PeriodNumberOfPoints
                fprintf(fileID,'%d',int16(vector(i)));
                if(i<PeriodNumberOfPoints)
                    fprintf(fileID,',');
                end
            end
            fclose(fileID);
        end
    end
catch
end

% --- Executes on selection change in pumInterpolationSelector.
function pumInterpolationSelector_Callback(hObject, eventdata, handles)
% hObject    handle to pumInterpolationSelector (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pumInterpolationSelector contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pumInterpolationSelector
global Interpolation sizelstPoints
InterpolationOptions = get(hObject,'String');
Interpolation = string(InterpolationOptions{get(hObject,'Value')});
if(sizelstPoints>2)
    PlotWaveform(handles); generalPlot(handles);
end


% --- Executes during object creation, after setting all properties.
function pumInterpolationSelector_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pumInterpolationSelector (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global Interpolation
Interpolation = 'Piecewise';


function edtPointTime_Callback(hObject, eventdata, handles)
% hObject    handle to edtPointTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtPointTime as text
%        str2double(get(hObject,'String')) returns contents of edtPointTime as a double
global Point_Time PointTimeUnits

Point_Time = str2double(get(hObject,'String'));

if(strcmp(PointTimeUnits,'ms'))
    Point_Time = round(Point_Time*1000);
elseif(strcmp(PointTimeUnits,'s'))
    Point_Time = round(Point_Time*1000*1000);
else
    Point_Time = round(Point_Time);
end
% if(strcmp(PointTimeUnits,'ms'))
%     set(hObject,'String',num2str(Point_Time/1000));
% elseif(strcmp(PointTimeUnits,'s'))
%     set(hObject,'String',num2str(Point_Time/1000/1000));
% else
%     set(hObject,'String',num2str(Point_Time));
% end


% --- Executes during object creation, after setting all properties.
function edtPointTime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtPointTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global Point_Time
Point_Time = 0;


function edtVInput_Callback(hObject, eventdata, handles)
% hObject    handle to edtVInput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtVInput as text
%        str2double(get(hObject,'String')) returns contents of edtVInput as a double
global Point_mV
Point_mV = str2num(get(hObject,'String'));


% --- Executes during object creation, after setting all properties.
function edtVInput_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtVInput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global Point_mV SampleTime
Point_mV = 0;
SampleTime = 1000;


% --- Executes on button press in pubAddPoint.
function pubAddPoint_Callback(hObject, eventdata, handles)
% hObject    handle to pubAddPoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Point_mV Point_Time PeriodNumberOfPoints NumberOfPeriods
global VoltageList TimeList SampleTime PointTimeUnits 
if(isnan(Point_Time))
    Point_Time = str2double(handles.edtPointTime.String);

    if(strcmp(PointTimeUnits,'ms'))
        Point_Time = round(Point_Time*1000);
    elseif(strcmp(PointTimeUnits,'s'))
        Point_Time = round(Point_Time*1000*1000);
    else
        Point_Time = round(Point_Time);
    end
end
if(Point_Time>=0)
    if(Point_mV>2500)
        Point_mV = 2500;
    end
    if(Point_mV<-2500)
        Point_mV = -2500;
    end
    [Point_pos, TimeList, VoltageList, SampleTime] = ...
        recalculateLists(Point_Time, TimeList, VoltageList, ...
        PeriodNumberOfPoints);
    VoltageList{Point_pos} = Point_mV; 
    reorder_lstPoints(VoltageList, TimeList, PeriodNumberOfPoints, handles)
end


function [Point_pos, TimeList, VoltageList, SampleTime] = ...
    recalculateLists(Point_Time, TimeList, VoltageList, ...
    PeriodNumberOfPoints)
if(Point_Time==0)
    Point_pos = 1;
    TimeList{Point_pos} = 0;
    SampleTime = 0;
else
    m = max(cell2mat(TimeList));
    if(Point_Time >= m)
        if(m~=0)
            [~,sizeT] = size(TimeList);
            if(sizeT~=PeriodNumberOfPoints)
                reductionScale = (PeriodNumberOfPoints-1)/(sizeT-1);
            else
                reductionScale = m/Point_Time;
            end
            TimeList_{PeriodNumberOfPoints} = [];
            TimeList_{1} = TimeList{1};
            VoltageList_{1} = VoltageList{1};
            anterior = 1;
            for i = 1:sizeT
                if(ceil(i*reductionScale)>anterior)
                    TimeList_{ceil((i-1)*reductionScale)+1} = TimeList{i}; %ceil(i*reductionScale)
                    VoltageList_{ceil((i-1)*reductionScale)+1} = VoltageList{i};
                    anterior = anterior + 1;
                    if(isempty(TimeList{i}))
                        anterior = anterior - 1;
                        if(and(sizeT==PeriodNumberOfPoints,i<sizeT))
                            if(TimeList_{ceil((i+1)*reductionScale)}>TimeList_{ceil(i*reductionScale)})
                                anterior = anterior + 1;
                            end
                        end
                    end
                end
            end
            
            TimeList_{PeriodNumberOfPoints} = Point_Time;
%             if(and(Point_Time == m,sizeT==PeriodNumberOfPoints))
%                 TimeList_{sizeT} = [];
%                 VoltageList_{PeriodNumberOfPoints} = VoltageList_{sizeT};
%                 VoltageList_{sizeT} = [];
%             end
            redTimeList_ = TimeList_(~cellfun('isempty',TimeList_));
            redTimeList = TimeList(~cellfun('isempty',TimeList));
            for i = 1:size(redTimeList,2)
                if(isempty(find([redTimeList_{:}]==[redTimeList{i}])))
                    msg = sprintf(['The last point addition is impossible to accomplish.\n'...
                    'It has been readapted to fit the best way possible.']);
                    errorSound(); warndlg(msg); 
                end
            end
            TimeList = TimeList_;
            VoltageList = VoltageList_;
            Point_pos = PeriodNumberOfPoints;
        else
            TimeList{PeriodNumberOfPoints} = Point_Time;
            Point_pos = PeriodNumberOfPoints;
        end
    else
        ind = 0;
        for k = 1:numel(TimeList)
          if(TimeList{k}==Point_Time)
              ind = k;
          end
        end
        if(ind~=0)
            Point_pos = ind;
        else
            inferior = 0; i_inf = 1;
            superior = 0; i_sup = 1;
            for i = 1:PeriodNumberOfPoints
                if(~isempty(TimeList{i}))
                    if(TimeList{i}<Point_Time)
                        inferior = TimeList{i};
                        i_inf = i;
                    else
                        superior = TimeList{i};
                        i_sup = i;
                    end
                end
            end
            r = i_sup-i_inf;
            p = Point_Time/(inferior+superior);
            Point_pos = i_inf+round(r*p);
            TimeList{Point_pos} = Point_Time;
        end
    end
    m = max(cell2mat(TimeList));
    SampleTime = m/PeriodNumberOfPoints;
end


function edtNumberOfPoints_Callback(hObject, eventdata, handles)
% hObject    handle to edtNumberOfPoints (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtNumberOfPoints as text
%        str2double(get(hObject,'String')) returns contents of edtNumberOfPoints as a double
global PeriodNumberOfPoints NumberOfPeriods SampleTime TimeList VoltageList
PeriodNumberOfPoints = str2num(get(hObject,'String'));
if(PeriodNumberOfPoints<1)
    PeriodNumberOfPoints = 1;
    set(hObject,'String','1');
elseif(PeriodNumberOfPoints*NumberOfPeriods>10000)
    PeriodNumberOfPoints = floor((10000/NumberOfPeriods));
    set(hObject,'String',num2str(PeriodNumberOfPoints));
elseif(PeriodNumberOfPoints>1000)
    PeriodNumberOfPoints = 1000;
    set(hObject,'String',num2str(PeriodNumberOfPoints));
end
% if(max(cell2mat(TimeList))>2)
%     [Point_pos, TimeList, VoltageList, SampleTime] = recalculateLists(max(cell2mat(TimeList)), TimeList, VoltageList, PeriodNumberOfPoints);
%     setTxtTotalTime(handles,PeriodNumberOfPoints,SampleTime);
%     PlotWaveform(handles);
% end
reorder_lstPoints(VoltageList, TimeList, PeriodNumberOfPoints, ...
    handles);

% --- Executes during object creation, after setting all properties.
function edtNumberOfPoints_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtNumberOfPoints (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global VoltageList
VoltageList = [];
global TimeList
TimeList = [];
global PeriodNumberOfPoints 
PeriodNumberOfPoints = 1000;


function edtNumberOfPeriods_Callback(hObject, eventdata, handles)
% hObject    handle to edtNumberOfPeriods (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtNumberOfPeriods as text
%        str2double(get(hObject,'String')) returns contents of edtNumberOfPeriods as a double
global SampleTime NumberOfPeriods PeriodNumberOfPoints
global TimeList VoltageList
NumberOfPeriods = str2num(get(hObject,'String'));
if(NumberOfPeriods<1)
    NumberOfPeriods = 1;
    set(hObject,'String','1');
elseif(NumberOfPeriods>=1000)
    NumberOfPeriods = 1000;
    set(hObject,'String',num2str(NumberOfPeriods));
end
reorder_lstPoints(VoltageList, TimeList, PeriodNumberOfPoints, ...
    handles);


function setTxtSampleTime(handles, PeriodNumberOfPoints, SampleTime)
% handles               structure with handles and user data (see GUIDATA)
% PeriodNumberOfPoints  number of samples per waveform period
% NumberOfPeriods       number of periods that waveform will be repeated
% SampleTime            time between samples in microseconds
t = SampleTime;
if(t<1000)
    units = 'us';
    set(handles.txtSampleTime, 'String', strcat(num2str(t),{' '},...
        units));
elseif(t<1e6)
    units = 'ms';
    set(handles.txtSampleTime, 'String', strcat(num2str(t/1e3),{' '},...
        units));
else
    units = 's';
    set(handles.txtSampleTime, 'String', strcat(num2str(t/1e6),{' '},...
        units));
end


% --- Executes during object creation, after setting all properties.
function edtNumberOfPeriods_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtNumberOfPeriods (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global NumberOfPeriods
NumberOfPeriods = 1;


% --- Executes on selection change in pumTimePoint.
function pumTimePoint_Callback(hObject, eventdata, handles)
% hObject    handle to pumTimePoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pumTimePoint contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pumTimePoint
global PointTimeUnits
PointTimeUnitsOptions = get(hObject,'String');
PointTimeUnits = string(PointTimeUnitsOptions{get(hObject,'Value')});
edtPointTime_Callback(hObject, eventdata, handles);


% --- Executes during object creation, after setting all properties.
function pumTimePoint_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pumTimePoint (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global PointTimeUnits
PointTimeUnits = 'us';


% function setTxtTotalTime(handles,PeriodNumberOfPoints,SampleTime)
% % handles               structure with handles and user data (see GUIDATA)
% % PeriodNumberOfPoints  number of samples per waveform period
% % NumberOfPeriods       number of periods that waveform will be repeated
% % SampleTime            time between samples in microseconds
% global NumberOfPeriods TotalActiveTime
% t = SampleTime/1e6*PeriodNumberOfPoints*NumberOfPeriods;
% TotalActiveTime = t;
% if(SampleTime>0)
%     hms = sec2hms(t); splithms = split(hms,':'); splitsecs = splithms{3};
%     splitsecs = str2num(splitsecs); 
%     if(splitsecs<10)
%         secs = sprintf('0%2.3f',splitsecs);
%     else
%         secs = sprintf('%2.3f',splitsecs);
%     end
%     time = strcat(splithms{1},':',splithms{2},':',secs);
%     set(handles.txtTotalTime, 'String', time);
% end


% --- Executes during object creation, after setting all properties.
function plotWaveform_CreateFcn(hObject, eventdata, handles)
% hObject    handle to plotWaveform (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
closeSound();
% Hint: delete(hObject) closes the figure
delete(hObject);


% --- Executes on selection change in pumUnits.
function pumUnits_Callback(hObject, eventdata, handles)
% hObject    handle to pumUnits (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pumUnits contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pumUnits
global UnitsmVuAmA sizelstPoints
UnitsmVuAmAOptions = get(hObject,'String');
UnitsmVuAmA = string(UnitsmVuAmAOptions{get(hObject,'Value')});
if(sizelstPoints>2)
    PlotWaveform(handles); generalPlot(handles);
end


% --- Executes during object creation, after setting all properties.
function pumUnits_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pumUnits (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global UnitsmVuAmA
UnitsmVuAmAOptions = get(hObject,'String');
UnitsmVuAmA = string(UnitsmVuAmAOptions{get(hObject,'Value')});



function edtRestTime_Callback(hObject, eventdata, handles)
% hObject    handle to edtRestTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtRestTime as text
%        str2double(get(hObject,'String')) returns contents of edtRestTime as a double
global RestTimeSec RestTime RestTimeMin RestTimeHour
RestTimeSec = str2num(get(hObject,'String'));
if(RestTimeSec<0)
    RestTimeSec = 0;
    set(hObject,'String','0');
else
    RestTime = RestTimeMin*60+RestTimeSec+RestTimeHour*3600;
end
generalPlot(handles)



% --- Executes during object creation, after setting all properties.
function edtRestTime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtRestTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global RestTimeSec RestTime RestTimeMin RestTimeHour
RestTimeSec = str2num(get(hObject,'String'));
if(RestTimeSec<0)
    RestTimeSec = 0;
    set(hObject,'String','0');
else
    RestTime = RestTimeMin*60+RestTimeSec+RestTimeHour*3600;
end



function edtIterations_Callback(hObject, eventdata, handles)
% hObject    handle to edtIterations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtIterations as text
%        str2double(get(hObject,'String')) returns contents of edtIterations as a double
global Iterations
Iterations = str2num(get(hObject,'String'));
if(Iterations<1)
    Iterations = 1;
    set(hObject,'String','1');
end
generalPlot(handles)



% --- Executes during object creation, after setting all properties.
function edtIterations_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtIterations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global Iterations
Iterations = str2num(get(hObject,'String'));
if(Iterations<1)
    Iterations = 1;
    set(hObject,'String','1');
end


function generalPlot(handles)
global Iterations RestTime TotalActiveTime SampleTime

t = (TotalActiveTime+RestTime)*Iterations;
t_ = mod(t,86400);
dd = (t - t_)/86400;
t = t_;
if(SampleTime>0)
    hms = sec2hms(t); splithms = split(hms,':'); splitsecs = splithms{3};
    splitsecs = str2num(splitsecs); 
    if(splitsecs<10)
        secs = sprintf('0%2.3f',splitsecs);
    else
        secs = sprintf('%2.3f',splitsecs);
    end
    time = strcat(num2str(dd),'ds,',{' '},splithms{1},':',splithms{2},':',secs);
    set(handles.txtTotalTimeTOTAL, 'String', time);
end

x = 0;
y = 'r';
if(RestTime==0)
    iters = 1:(Iterations);
    for i = iters
        x(i) = TotalActiveTime*i;
        y(i) = 'r';
    end
else
    iters = 1:(Iterations*2);
    for i = iters
        if(mod(i,2)==1)
            x(i) = TotalActiveTime;
            y(i) = 'r';
        else
            x(i) = RestTime;
            y(i) = 'w';
        end
    end
end

plt_x = 0;
if(sum(x)>300)
    x = x/60;
    plt_x = 1;
    if(sum(x)>120)
        x = x/60;
        plt_x = 2;
    end
end

h = barh(handles.plotGeneral,0,x,'stacked');
for i = iters
    if(strcmp(y(i),'r'))
        col = [1 0 0];
    else
        col = [1 1 1];
    end
    set(h(i),'facecolor',col)
end

if(plt_x == 0)
    xlabel(handles.plotGeneral,'Total time (s)');
elseif(plt_x == 1)
    xlabel(handles.plotGeneral,'Total time (min)');
else
    xlabel(handles.plotGeneral,'Total time (h)');
end
ylabel(handles.plotGeneral,'');
set(handles.plotGeneral,'YTickLabel',[]);
grid(handles.plotGeneral,'on');

function edtRestTimeMin_Callback(hObject, eventdata, handles)
% hObject    handle to edtRestTimeMin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtRestTimeMin as text
%        str2double(get(hObject,'String')) returns contents of edtRestTimeMin as a double
global RestTime RestTimeMin RestTimeHour RestTimeSec
RestTimeMin = str2num(get(hObject,'String'));
if(RestTimeMin<0)
    set(hObject,'String','0');
    RestTimeMin = 0;
else
    RestTime = RestTimeHour*3600 + RestTimeMin*60 + RestTimeSec; 
end
generalPlot(handles)

% --- Executes during object creation, after setting all properties.
function edtRestTimeMin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtRestTimeMin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global RestTime RestTimeSec RestTimeMin RestTimeHour
RestTimeMin = str2num(get(hObject,'String'));
if(RestTimeMin<0)
    set(hObject,'String','0');
    RestTimeMin = 0;
else
    RestTime = RestTimeHour * 3600 + RestTimeMin*60 + RestTimeSec; 
end


function edtRestTimeHour_Callback(hObject, eventdata, handles)
% hObject    handle to edtRestTimeHour (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtRestTimeHour as text
%        str2double(get(hObject,'String')) returns contents of edtRestTimeHour as a double
global RestTime RestTimeMin RestTimeHour RestTimeSec
RestTimeHour = str2num(get(hObject,'String'));
if(RestTimeHour<0)
    set(hObject,'String','0');
    RestTimeHour = 0;
else
    RestTime = RestTimeHour*3600 + RestTimeMin*60 + RestTimeSec; 
end
generalPlot(handles)


% --- Executes during object creation, after setting all properties.
function edtRestTimeHour_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtRestTimeHour (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global RestTime RestTimeMin RestTimeHour RestTimeSec
RestTimeHour = str2num(get(hObject,'String'));
if(RestTimeHour<0)
    set(hObject,'String','0');
    RestTimeHour = 0;
else
    RestTime = RestTimeHour*3600 + RestTimeMin*60 + RestTimeSec; 
end


function edtNumberOfPeriodsMultiplier_Callback(hObject, eventdata, handles)
% hObject    handle to edtNumberOfPeriodsMultiplier (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtNumberOfPeriodsMultiplier as text
%        str2double(get(hObject,'String')) returns contents of edtNumberOfPeriodsMultiplier as a double
global NumberOfPeriodsMultiplier PeriodNumberOfPoints TimeList VoltageList
NumberOfPeriodsMultiplier = str2double(get(hObject,'String'));
if(NumberOfPeriodsMultiplier<0)
    NumberOfPeriodsMultiplier = 0;
    set(hObject,'String','0');
elseif(NumberOfPeriodsMultiplier>5)
    NumberOfPeriodsMultiplier = 5;
    set(hObject,'String','5');
end
reorder_lstPoints(VoltageList, TimeList, PeriodNumberOfPoints, ...
    handles);

% --- Executes during object creation, after setting all properties.
function edtNumberOfPeriodsMultiplier_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtNumberOfPeriodsMultiplier (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global NumberOfPeriodsMultiplier
NumberOfPeriodsMultiplier = str2double(get(hObject,'String'));
if(NumberOfPeriodsMultiplier<0)
    NumberOfPeriodsMultiplier = 0;
    set(hObject,'String','0');
elseif(NumberOfPeriodsMultiplier>5)
    NumberOfPeriodsMultiplier = 5;
    set(hObject,'String','5');
end
