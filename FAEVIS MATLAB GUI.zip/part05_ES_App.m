%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief IDM UPV PhD. Electrostimulation           %
%          application control interface.            %
%   @version 09th July 2020                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function varargout = part05_ES_App(varargin)
% part05_ES_App MATLAB code for part05_ES_App.fig
%      part05_ES_App, by itself, creates a new part05_ES_App or raises the existing
%      singleton*.
%
%      H = part05_ES_App returns the handle to a new part05_ES_App or the handle to
%      the existing singleton*.
%
%      part05_ES_App('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in part05_ES_App.M with the given input arguments.
%
%      part05_ES_App('Property','Value',...) creates a new part05_ES_App or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before part05_ES_App_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to part05_ES_App_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help part05_ES_App

% Last Modified by GUIDE v2.5 09-Jul-2020 12:15:02

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @part05_ES_App_OpeningFcn, ...
                   'gui_OutputFcn',  @part05_ES_App_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before part05_ES_App is made visible.
function part05_ES_App_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to part05_ES_App (see VARARGIN)

% Choose default command line output for part05_ES_App
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

format long;

global EQ1ES0 CorrectOCP CurrentScale
EQ1ES0 = 0; CorrectOCP = '0'; CurrentScale = hex2dec('11');

StartInitialTimer(handles)

% UIWAIT makes part05_ES_App wait for user response (see UIRESUME)
% uiwait(handles.Framework);


% --- Outputs from this function are returned to the command line.
function varargout = part05_ES_App_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in pumAvailableCOMs.
function pumAvailableCOMs_Callback(hObject, eventdata, handles)
% hObject    handle to pumAvailableCOMs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pumAvailableCOMs contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pumAvailableCOMs
% Close ports that might be open

global COM openedCOM
ActivePorts = instrfind; % Read active ports
if isempty(ActivePorts)==0 % Check if there are active ports
    if ~openedCOM
        fclose(ActivePorts); % Close active ports
        delete(ActivePorts) % Erase variable
        clear ActivePorts % Destroy variable
    end
end

COMs = get(hObject,'String');
sizeCOM = size(COMs);
sizeCOM = sizeCOM(1);
if(sizeCOM == 1)
    COM = COMs;
else
    COM = string(COMs{get(hObject,'Value')});
end
clearvars COMs % Clear variable


% --- Executes during object creation, after setting all properties.
function pumAvailableCOMs_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pumAvailableCOMs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), ...
        get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

if(~isempty(seriallist))
    set(hObject,'String',seriallist);
    COMs = get(hObject,'String');
else
    set(hObject,'String','[none]');
    COMs = [];
end
global COM openedCOM 
if(~isempty(COMs))
    if(iscell(COMs))
        COM = string(COMs{get(hObject,'Value')});
    else
        COM = COMs;
    end
end
clearvars COMs % Clear variable
openedCOM = 0;

global stateFSM
stateFSM = 0;


% --- Executes on button press in phbConnectCOM.
function phbConnectCOM_Callback(hObject, eventdata, handles)
% hObject    handle to phbConnectCOM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

pumAvailableCOMs_Callback(handles.pumAvailableCOMs, eventdata, handles)

global COM PORT openedCOM

if(~openedCOM)
    % Config serial port
    if(strcmp(COM,'[none]')<=0)
        PORT=serial(COM); % Generate a serial object linked to COM              
        set(PORT,'BaudRate',115200); 
        set(PORT,'DataBits',8); 
        set(PORT,'Parity','none'); 
        set(PORT,'StopBits',1); 
        set(PORT,'FlowControl','none'); % RTS and DTS manually controlled
        set(PORT,'DataTerminalReady','off'); 
        set(PORT,'RequestToSend','on'); 
        PORT.BytesAvailableFcnCount = 20;  % Trigger of reception event when 1 byte received
        PORT.BytesAvailableFcnMode = 'byte'; % Trigger for number of bytes and not for enders
        set(PORT,'BytesAvailableFcn',{@inputHermesMessage,handles}); % Event triggers inputHermesMessage to treat it 
        fopen(PORT); % Opens port
        openedCOM = 1;
        rxState(handles,'sending');
        sendHermesMessage('areYouAlive',0,handles);
        rxState(handles,'waiting');
    else
        errorSound(); warndlg('No COM port detected or chosen.');
    end
else
    fclose(PORT); % Opens port
    delete(PORT)
    clear PORT
    openedCOM = 0;
    handles.phbConnectCOM.ForegroundColor = [0 0 0];
    handles.indWaveformLoaded.BackgroundColor = [0 0.3 0];
    handles.indSerial.BackgroundColor = [0 0.3 0];
    handles.pumAvailableCOMs.Enable = 'on';
    handles.phbScanCOMs.Enable = 'on';
    handles.psbStartExperience.Enable = 'on';
    handles.phbSaveResults.Enable = 'on';
    allInteractivity(handles,'on');
    handles.phbLoadWaveform.Enable = 'on';
end


% --- Executes when user attempts to close Framework.
function Framework_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to Framework (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global PORT openedCOM appFreeFlag

if(openedCOM == 1)
    fclose(PORT);
    delete(PORT)
    clear PORT
    openedCOM = 0;
end

% Hint: delete(hObject) closes the figure
closeSound();
delete(hObject);
clc
% clear
appFreeFlag = 1;


% --- Executes on button press in psbStartExperience.
function psbStartExperience_Callback(hObject, eventdata, handles)
% hObject    handle to psbStartExperience (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global openedCOM Iterations_cnt 
if(openedCOM)
    Iterations_cnt = 0;
    stateMachine(handles); 
else
    errorSound(); warndlg('First, click on green button CONNECT to connect with the USB.'); 
end


% --- Executes on button press in phbLoadWaveform.
function phbLoadWaveform_Callback(hObject, eventdata, handles)
% hObject    handle to phbLoadWaveform (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global WAVEFORM PeriodNumberOfPoints SampleTime NumberOfPeriods WaveformLoaded
global WAVEFORM_ptr WAVEFORM_DAC WaveformNumberOfPoints waveformNsequence
global WaveformLoadRequested WaveformSent AppliedWaveform NumberOfPeriodsMultiplier
global LoadParameters CalibrationLoaded ActiveExperience CurrentScale
global DACValuesRead Stimulation RestTime ActiveTime Iterations AppliedWaveformRep
try
    [file,path] = uigetfile('*.est', 'Pick electrostimulation experience file (.est).');
    if(~contains(file,'.est'))
        errorSound(); warndlg('Selected file is not .est.'); 
    else
        file = strcat(path,'\',file);
        fd = fopen(file);
        if(fd==-1)
            errorSound(); warndlg('Impossible to open selected file.');
            handles.indWaveformLoaded.BackgroundColor = [0 0.3 0];
            WAVEFORM = 0; 
            PeriodNumberOfPoints = 0; 
            SampleTime = 0;
            NumberOfPeriods = 0;
            WaveformLoaded = 0;
        else
            SampleTime = textscan(fd,'%d',1,'Delimiter','\n');
            SampleTime = SampleTime{1};
            NumberOfPeriods = textscan(fd,'%d',1,'Delimiter','\n');
            NumberOfPeriods = NumberOfPeriods{1};
            NumberOfPeriodsMultiplier = textscan(fd,'%d',1,'Delimiter','\n');
            NumberOfPeriodsMultiplier = NumberOfPeriodsMultiplier{1};
            PeriodNumberOfPoints = textscan(fd,'%d',1,'Delimiter','\n');
            PeriodNumberOfPoints = PeriodNumberOfPoints{1};
            Stimulation = textscan(fd,'%s',1,'Delimiter','\n');
            Stimulation = Stimulation{1};
            if(strcmp(Stimulation,'mV'))
                ActiveExperience = 'Gradient';
            else
                ActiveExperience = 'Current Injection';
            end
            RestTime = textscan(fd,'%d',1,'Delimiter','\n');
            RestTime = RestTime{1};
            Iterations = textscan(fd,'%d',1,'Delimiter','\n');
            Iterations = Iterations{1};

            str = '';
            for i=4:(PeriodNumberOfPoints+3)
                str = strcat(str,'%d ');
            end
            WAVEFORM = textscan(fd,str,'Delimiter',',');
            WaveformLoaded = 1;
            handles.indWaveformLoaded.BackgroundColor = [0 0 1]; 
            fclose(fd);
            
            AppliedWaveform = cell2mat(WAVEFORM(:))';

            WAVEFORM_ptr = 1;
            WaveformNumberOfPoints = length(WAVEFORM);
            if(strcmp(Stimulation,'mV'))
                WAVEFORM_DAC = (cell2mat(WAVEFORM) + 2500)/(5000/4095);
                WAVEFORM_mV = double(cell2mat(WAVEFORM))/1e3;
            else
                WAVEFORM_DAC = (cell2mat(WAVEFORM) + 208)/(416/4095)...
                    -70; % HANDMADE
                WAVEFORM_mV = double(cell2mat(WAVEFORM))*12e-3;
            end
            waveformNsequence = 0;
            WaveformSent = 0;
            
            if(CalibrationLoaded)
                x = [256,768,1280,1792,2048,2304,2816,3328,3840];
                v = DACValuesRead;
                xq = 256:3840;
                vq = interp1(x,v,xq,'spline');
                xq = [1:255 xq]; vq = [(1:255)*(2.5+vq(256))/510-2.5 vq]; 
                % plot(x,v,'o',xq,vq,':.');
                for i = 1:WaveformNumberOfPoints
                    if(and(WAVEFORM_DAC(i)>256,WAVEFORM_DAC(i)<3840))
                        dist = abs(vq - WAVEFORM_mV(i));
                        minDist = min(dist);
                        WAVEFORM_DAC(i) = find(dist == minDist,1,'first');
                    end
                end
            end
            
            handles.phbLoadWaveform.Enable = 'off';
            previewLoadingWaveform(handles);
            if(LoadParameters)             
                rxState(handles,'sending');
                sendHermesMessage('stopExperience',0,handles);
                rxState(handles,'waiting');
                WaveformLoadRequested = 1;
                handles.psbStartExperience.Enable = 'off';
                handles.phbSaveResults.Enable = 'off';  
                
                set(handles.txtStimulation, 'String', Stimulation);
                
                t = double(SampleTime)/1e6*PeriodNumberOfPoints*NumberOfPeriods;
                hms = sec2hms(t); splithms = split(hms,':'); splitsecs = splithms{3};
                splitsecs = str2num(splitsecs); 
                if(splitsecs<10)
                    secs = sprintf('0%2.3f',splitsecs);
                else
                    secs = sprintf('%2.3f',splitsecs);
                end
                time = strcat(splithms{1},':',splithms{2},':',secs);
                set(handles.txtActiveTime, 'String', time);
                
                t = RestTime;
                hms = sec2hms(t); splithms = split(hms,':'); splitsecs = splithms{3};
                time = strcat(splithms{1},':',splithms{2},':',splithms{3});
                set(handles.txtRestTime, 'String', time);
                
                t = (RestTime+double(SampleTime)/1e6*PeriodNumberOfPoints*NumberOfPeriods)*Iterations;
                t_ = mod(t,86400);
                dd = (t - t_)/86400;
                t = t_;
                hms = sec2hms(t); splithms = split(hms,':'); splitsecs = splithms{3};
                splitsecs = str2num(splitsecs); 
                if(splitsecs<10)
                    secs = sprintf('%2.0f0',splitsecs);
                    secs = secs(2:3);
                else
                    secs = sprintf('%2.0f',splitsecs);
                end
                time = strcat(num2str(dd),'ds,',{' '},splithms{1},':',splithms{2},':',secs);
                set(handles.txtTotalTime, 'String', time);
            else
                handles.indWaveformLoaded.BackgroundColor = [0 0.3 0];
                handles.psbStartExperience.Enable = 'on';
                handles.phbSaveResults.Enable = 'on';
                handles.phbLoadWaveform.Enable = 'on';
                handles.txtStimulation.String = 'Not loaded';
                handles.txtActiveTime.String = 'Not loaded';
                handles.txtRestTime.String = 'Not loaded';
                handles.txtTotalTime.String = 'Not loaded';
            end
            
            AppliedWaveformRep = repmat(cell2mat(WAVEFORM),1,NumberOfPeriods*10^NumberOfPeriodsMultiplier*(Iterations+1)); 
        end
    end
catch
    handles.psbStartExperience.Enable = 'on';
    handles.phbSaveResults.Enable = 'on';
end

% --- Executes during object creation, after setting all properties.
function phbLoadWaveform_CreateFcn(hObject, eventdata, handles)
% hObject    handle to chkCorrectOCP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
global WAVEFORM PeriodNumberOfPoints SampleTime NumberOfPeriods 
global WaveformLoaded WaveformSent eqTransmission txStopTransmission
global CERequest CurrentRequest alternationFlag AEEnded 
WAVEFORM = 0; 
PeriodNumberOfPoints = 0; 
SampleTime = 0;
NumberOfPeriods = 0;
WaveformLoaded = 0;
WaveformSent = 0;
eqTransmission = 0;
txStopTransmission = 0;
CERequest = 0;
CurrentRequest = 0;
alternationFlag = 0;
AEEnded = 0;
% HEREGOESTHINGS


% --- Executes on button press in psbStopExperience.
function psbStopExperience_Callback(hObject, eventdata, handles)
% hObject    handle to psbStopExperience (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Timer_1s openedCOM
if(~isempty(Timer_1s))   
    if(isvalid(Timer_1s))
        stop(Timer_1s); delete(Timer_1s); 
        clear Timer_1s
    else
        clear Timer_1s
    end
end
if(openedCOM)
    stopSound();
    rxState(handles,'sending');
    sendHermesMessage('stopExperience',0,handles);
    rxState(handles,'waiting');
else
    errorSound(); warndlg('First, click on green button CONNECT to connect with the USB.'); 
end


% --- Executes on button press in phbSaveResults.
function phbSaveResults_Callback(hObject, eventdata, handles)
% hObject    handle to phbSaveResults (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global PotentiometryExperience PotentiometrySampleTime tp tc 
global CurrentScale ActiveExperience AppliedWaveform ExperienceMode
global PotentiometryWaveform3V CEVoltageWaveform3V CurrentWaveform3V
global SampleTime NumberOfPeriods WaveformNumberOfPoints AEEnded RestTime 
global Iterations
% HEREGOESTHINGS
txtend = '*.esr';
if(and(strcmp(ExperienceMode,'Active'),AEEnded))
    [file,path,flag] = uiputfile(txtend, 'Set direction to save the results.');
    if(flag == 1)
        file = strcat(path,'\',file);
        fd = fopen(file,'w+');
        if(fd==-1)
            errorSound(); vwarndlg('Impossible to open selected file.'); 
        else
            fprintf(fd,'%s.\r\n',datestr(clock));
            fprintf(fd,'\r\n');
        end
        if(~isempty(tc))
            fprintf(fd,'ACTIVE EXPERIENCE: %s.\r\n',ActiveExperience);
            fprintf(fd,'\tSample time (us): %d.\r\n',SampleTime); 
            fprintf(fd,'\tNumber of points: %d.\r\n',WaveformNumberOfPoints);
            fprintf(fd,'\tNumber of cycles: %d.\r\n',NumberOfPeriods);
            fprintf(fd,'\tRest time (s): %d.\r\n',RestTime);
            fprintf(fd,'\tNumber of iterations: %d.\r\n',Iterations);
            if(CurrentScale==17)
                fprintf(fd,'\tCurrent Scale: Large (+-2.5mA).\r\n');
            else
                fprintf(fd,'\tCurrent Scale: Precision (+-25uA).\r\n');
            end
            fprintf(fd,'Waveform applied (V): ');
            for i=1:length(AppliedWaveform)
                if(i<length(AppliedWaveform))
                    fprintf(fd,'%.3f,',double(AppliedWaveform(i))/1000);
                else
                    fprintf(fd,'%.3f.',double(AppliedWaveform(i))/1000);
                end
            end
            fprintf(fd,'\r\n\r\n');
            if(CurrentScale==17)
                fprintf(fd,'Current measurements (mA): ');
            else
                fprintf(fd,'Current measurements (uA): ');
            end
            for i=1:length(CurrentWaveform3V)
                if(i<length(CurrentWaveform3V))
                    fprintf(fd,'%.3f,',double(CurrentWaveform3V(i)));
                else
                    fprintf(fd,'%.3f.',double(CurrentWaveform3V(i)));
                end
            end
            fprintf(fd,'\r\n\r\n');
            fprintf(fd,'CE Voltage (V): ');
            for i=1:length(CEVoltageWaveform3V)
                if(i<length(CEVoltageWaveform3V))
                    fprintf(fd,'%.3f,',double(CEVoltageWaveform3V(i))/1000);
                else
                    fprintf(fd,'%.3f.',double(CEVoltageWaveform3V(i))/1000);
                end
            end
        end    
        fprintf(fd,'\r\n\nEOF');
        fclose(fd);
    end
else
    errorSound(); warndlg('No active experience data to save.'); 
end


% --- Executes on button press in phbScanCOMs.
function phbScanCOMs_Callback(hObject, eventdata, handles)
% hObject    handle to phbScanCOMs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% if ispc && isequal(get(hObject,'BackgroundColor'), ...
%         get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end
global COM openedCOM PORT
try
    port = PORT.Port;
catch
    port = [];
end
if(isempty(port))
    if(~openedCOM)
        if(~isempty(seriallist))
            set(handles.pumAvailableCOMs,'String',seriallist);
            COMs = get(handles.pumAvailableCOMs,'String');
        else
            set(handles.pumAvailableCOMs,'String','[none]');
            COMs = [];
        end
        if(~isempty(COMs))
            if(iscell(COMs))
                COM = string(COMs{get(handles.pumAvailableCOMs,'Value')});
            else
                COM = COMs;
            end
            set(handles.pumAvailableCOMs,'Value',1);
        end
    end
else
    errorSound(); warndlg('First, click on green button CONNECT to disconnect.'); 
end


% --- Executes on button press in phbLoadPastResults.
function phbLoadPastResults_Callback(hObject, eventdata, handles)
% hObject    handle to phbLoadPastResults (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% HEREGOESTHINGS
try
    [file,path] = uigetfile({'*.per';'*.aer'}, 'Pick results to be plotted (.per or .aer).');
    if(contains(file,'.per'))
        file = strcat(path,'\',file);
        fd = fopen(file);
        if(fd==-1)
            errorSound(); warndlg('Impossible to open selected file.');
        else
            textscan(fd,'%s',1,'Delimiter','.'); 
            textscan(fd,'%s',1,'Delimiter',':');
            PotentiometryExperience = textscan(fd,'%s',1,'Delimiter','.');
            PotentiometryExperience = PotentiometryExperience{1};
            textscan(fd,'%s',1,'Delimiter',':');
            SampleTime_ms = textscan(fd,'%d',1,'Delimiter','.');
            SampleTime_ms = SampleTime_ms{1};
            textscan(fd,'%s',1,'Delimiter',':');
            NumberOfSamples = textscan(fd,'%d',1,'Delimiter','.');
            NumberOfSamples = NumberOfSamples{1};
            textscan(fd,'%s',1,'Delimiter',':');

            str = '';
            for i=1:NumberOfSamples
                str = strcat(str,'%f,');
            end
            str = strcat(str,'\n');
            PotentiometryWaveform = textscan(fd,str,'Delimiter','\n');
            PotentiometryWaveform = PotentiometryWaveform(1,:)';
            PotentiometryWaveform = cell2mat(PotentiometryWaveform(:))';
            
            fclose(fd);
            
            tp = SampleTime_ms:SampleTime_ms:(NumberOfSamples)*SampleTime_ms;
            timeUnits = 'Time (ms)';        
            if(max(tp)>1e4)
                tp = double(tp) / 1000; timeUnits = 'Time (s)';
                if(max(tp)>600)
                    tp = double(tp) / 60; timeUnits = 'Time (min)';
                end
            end
            potFigh = figure(1); potAxesh = axes(potFigh);
            plot(potAxesh,tp,PotentiometryWaveform,'Color','b');
                potAxesh.XLim = [0 max(tp)];
                potAxesh.YLim = ...
                    [min(PotentiometryWaveform)-0.005 ...
                    max(PotentiometryWaveform)+0.005];
            xlabel(potAxesh,timeUnits);
            title(potAxesh,PotentiometryExperience)
            ylabel(potAxesh,'Voltage (mV)')
            legend(potAxesh,'Potentiometry (mV)','Location','nortwest')
            grid(potAxesh, 'on')
        end
    elseif(contains(file,'.aer'))
        file = strcat(path,'\',file);
        fd = fopen(file);
        if(fd==-1)
            errorSound(); warndlg('Impossible to open selected file.');
        else
            textscan(fd,'%s',1,'Delimiter','.'); 
            textscan(fd,'%s',1,'Delimiter',':');
            ActiveExperience = textscan(fd,'%s',1,'Delimiter','.');
            ActiveExperience = ActiveExperience{1};
            textscan(fd,'%s',1,'Delimiter',':');
            SampleTime_us = textscan(fd,'%d',1,'Delimiter','.');
            SampleTime_us = SampleTime_us{1};
            textscan(fd,'%s',1,'Delimiter',':');
            NumberOfSamples = textscan(fd,'%d',1,'Delimiter','.');
            NumberOfSamples = NumberOfSamples{1};
            textscan(fd,'%s',1,'Delimiter',':');
            NumberOfCycles = textscan(fd,'%d',1,'Delimiter','.');
            NumberOfCycles = NumberOfCycles{1};
            textscan(fd,'%s',1,'Delimiter',':');
            CurrentScale = textscan(fd,'%s',1,'Delimiter','.');
            CurrentScale = CurrentScale{1};
            textscan(fd,'%s',1,'Delimiter',':');
            
            str = '';
            for i=1:NumberOfSamples*NumberOfCycles
                str = strcat(str,'%f,');
            end
            str = strcat(str,'\n');
            AppliedWaveform = textscan(fd,str,'Delimiter','\n');
            AppliedWaveform = AppliedWaveform(1,:)';
            AppliedWaveform = cell2mat(AppliedWaveform(:))';
            
            textscan(fd,'%s',1,'Delimiter','.');
            textscan(fd,'%s',1,'Delimiter',':');
            
            CurrentWaveform = textscan(fd,str,'Delimiter','\n');
            CurrentWaveform = CurrentWaveform(1,:)';
            CurrentWaveform = cell2mat(CurrentWaveform(:))';
            
            textscan(fd,'%s',1,'Delimiter','.');
            textscan(fd,'%s',1,'Delimiter',':');
            
            CEWaveform = textscan(fd,str,'Delimiter','\n');
            CEWaveform = CEWaveform(1,:)';
            CEWaveform = cell2mat(CEWaveform(:))';
            
            fclose(fd);
            
            actFigh = figure(2); actAxesh = axes(actFigh);
            tv = SampleTime_us:SampleTime_us:NumberOfSamples*NumberOfCycles*SampleTime_us;
            if(tv(end)>1e4)
                tv = double(tv) / 1000; 
                xlabel(actAxesh,'Time (ms)')
                if(tv(end)>1e4)
                    tv = double(tv) / 1000; 
                    xlabel(actAxesh,'Time (s)')
                    if(tv(end)>600)
                        tv = tv / 1000; 
                        xlabel(actAxesh,'Time (minutes)')
                    end
                end
            end
            yyaxis(actAxesh,'left')
                plot(actAxesh,tv(1:length(CEWaveform)),CEWaveform,'Color','b');
                hold(actAxesh,'on');
                plot(actAxesh,tv(1:length(CEWaveform)),AppliedWaveform(1:length(CEWaveform)),'Color','g');
                hold(actAxesh,'off');
                title(actAxesh,ActiveExperience)
                ylabel(actAxesh,'Voltage (mV)')
            yyaxis(actAxesh,'right')
                plot(actAxesh,tv(1:length(CurrentWaveform)),CurrentWaveform,'Color','r');               
            if(strcmp(CurrentScale,'Large (+-2.5mA)')) % large scale
                ylabel(actAxesh,'Current (mA)') 
                currentLegend = 'Current (mA)';
            else
                ylabel(actAxesh,'Current (uA)') 
                currentLegend = 'Current (uA)';
            end
            legend(actAxesh,'CE Voltage (mV)', 'Applied Voltage (mV)',...
                currentLegend,'Location','northwest')
            actAxesh.YAxis(2).Color = [0 0 0];%[0.85 0.325 0.098];
            actAxesh.YAxis(1).Color = [0 0 0];
            grid(actAxesh, 'on')
        end
    else
        errorSound(); warndlg('Selected file is not .per neither .aer.');    
    end
catch
end


% --- Executes on button press in phbLoadCalibration.
function phbLoadCalibration_Callback(hObject, eventdata, handles)
% hObject    handle to phbLoadCalibration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global CalibrationLoaded
global DACValuesRead POTValuesRead
global CEValuesRead CMLValuesRead RWEREL RCEREL
global CMPValuesRead RWEREP RCEREP
global CIValuesRead RCI xCalibrated
% HEREGOESTHINGS
try
    [file,path] = uigetfile('*.mcf', 'Pick a mixed calibration file (.mcf).');
    if(~contains(file,'.mcf'))
        errorSound(); warndlg('Selected file is not .dcf.'); 
    else
        fd = fopen(strcat(path,'\',file));
        if(fd==-1)
            errorSound(); warndlg('Impossible to open selected file.');
        else
            textscan(fd,'%s\n','Delimiter','\n');
            DACValuesRead = [];
            tmp = cell2mat(textscan(fd,'%f\n','Delimiter','\n'));
            if(tmp ~= -1)
                DACValuesRead(1) = tmp;
                for i=2:9
                    DACValuesRead(i) = cell2mat(textscan(fd,'%f\n','Delimiter','\n'));
                end
            end
            
            textscan(fd,'%s\n','Delimiter','\n');
            POTValuesRead = [];
            tmp = cell2mat(textscan(fd,'%d\n','Delimiter','\n'));
            if(tmp ~= -1)
                POTValuesRead(1) = tmp;
                for i=2:9
                    POTValuesRead(i) = cell2mat(textscan(fd,'%d\n','Delimiter','\n'));
                end
            end
            
            textscan(fd,'%s\n','Delimiter','\n');
            CEValuesRead = [];
            tmp = cell2mat(textscan(fd,'%f\n','Delimiter','\n'));
            if(tmp ~= -1)
                RWEREL = tmp;
                RCEREL = cell2mat(textscan(fd,'%f\n','Delimiter','\n'));
                for i=1:9
                    CEValuesRead(i) = cell2mat(textscan(fd,'%d\n','Delimiter','\n'));
                end
            end
            
            textscan(fd,'%s\n','Delimiter','\n');
            CMLValuesRead = [];
            tmp = cell2mat(textscan(fd,'%d\n','Delimiter','\n'));
            if(tmp ~= -1)
                CMLValuesRead(1) = tmp;
                for i=2:9
                    CMLValuesRead(i) = cell2mat(textscan(fd,'%d\n','Delimiter','\n'));
                end
            end
            
            textscan(fd,'%s\n','Delimiter','\n');
            CMPValuesRead = [];
            tmp = cell2mat(textscan(fd,'%f\n','Delimiter','\n'));
            if(tmp ~= -1)
                RWEREP = tmp;
                RCEREP = cell2mat(textscan(fd,'%f\n','Delimiter','\n'));
                for i=1:9
                    CMPValuesRead(i) = cell2mat(textscan(fd,'%d\n','Delimiter','\n'));
                end
            end
            
            textscan(fd,'%s\n','Delimiter','\n');
            CIValuesRead = [];
            tmp = cell2mat(textscan(fd,'%f\n','Delimiter','\n'));
            if(tmp ~= -1)
                RCI(1) = tmp;
                for i=1:9
                    CIValuesRead(i) = cell2mat(textscan(fd,'%f\n','Delimiter','\n'));
                end
            end
        end
        CalibrationLoaded = 1;
        handles.indLoadCalibration.BackgroundColor = [0 1 0];
        fclose(fd);
        
        x = [256,768,1280,1792,2048,2304,2816,3328,3840];
        v = DACValuesRead;
        xq = 256:3840;
        vq = interp1(x,v,xq,'spline');
        xq = [1:255 xq]; vq = [(1:255)*0-2.5 vq]; 
  
        xCalibrated = [];
        for i = 1:9
            dist = abs(vq - (double(x(i))/4095*5-2.5));
            minDist = min(dist);
            xCalibrated(i) = find(dist == minDist);
        end
    end
catch 
end


% --- Executes during object creation, after setting all properties.
function phbLoadCalibration_CreateFcn(hObject, eventdata, handles)
% hObject    handle to phbLoadCalibration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
global CalibrationLoaded
CalibrationLoaded = 0;


% --- Executes on button press in rdbLargeScale.
function rdbLargeScale_Callback(hObject, eventdata, handles)
% hObject    handle to rdbLargeScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rdbLargeScale
global CurrentScale WaveformLoaded
CurrentScale = hex2dec('11');
if(WaveformLoaded)
    handles.indYellowLoading.Visible = 'off';
    handles.indWaveformLoaded.BackgroundColor = [0 0.3 0];
    handles.psbStartExperience.Enable = 'off';
    handles.phbSaveResults.Enable = 'off';
end

% --- Executes on button press in rdbPrecisionScale.
function rdbPrecisionScale_Callback(hObject, eventdata, handles)
% hObject    handle to rdbPrecisionScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rdbPrecisionScale
global CurrentScale WaveformLoaded
CurrentScale = hex2dec('22');
if(WaveformLoaded)
    handles.indYellowLoading.Visible = 'off';
    handles.indWaveformLoaded.BackgroundColor = [0 0.3 0];
    handles.psbStartExperience.Enable = 'off';
    handles.phbSaveResults.Enable = 'off';
end

% --- Executes during object creation, after setting all properties.
function rdbLargeScale_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rdbLargeScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
global CurrentScale
CurrentScale = hex2dec('11');


% --- Executes during object creation, after setting all properties.
function uipSelectorCurrent_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipSelectorCurrent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
