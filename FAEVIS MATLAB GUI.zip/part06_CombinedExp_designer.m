%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief IDM UPV PhD. Voltammetric techniques      %
%          device electroestimulation experience     %
%          designer interface.                       %
%   @version 02nd March 2020                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function varargout = part06_CombinedExp_designer(varargin)
% PART06_COMBINEDEXP_DESIGNER MATLAB code for part06_CombinedExp_designer.fig
%      PART06_COMBINEDEXP_DESIGNER, by itself, creates a new PART06_COMBINEDEXP_DESIGNER or raises the existing
%      singleton*.
%
%      H = PART06_COMBINEDEXP_DESIGNER returns the handle to a new PART06_COMBINEDEXP_DESIGNER or the handle to
%      the existing singleton*.
%
%      PART06_COMBINEDEXP_DESIGNER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PART06_COMBINEDEXP_DESIGNER.M with the given input arguments.
%
%      PART06_COMBINEDEXP_DESIGNER('Property','Value',...) creates a new PART06_COMBINEDEXP_DESIGNER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before part06_CombinedExp_designer_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to part06_CombinedExp_designer_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help part06_CombinedExp_designer

% Last Modified by GUIDE v2.5 03-Jul-2020 13:22:18

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @part06_CombinedExp_designer_OpeningFcn, ...
                   'gui_OutputFcn',  @part06_CombinedExp_designer_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before part06_CombinedExp_designer is made visible.
function part06_CombinedExp_designer_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to part06_CombinedExp_designer (see VARARGIN)

% Choose default command line output for part06_CombinedExp_designer
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
initialSound();

% UIWAIT makes part06_CombinedExp_designer wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = part06_CombinedExp_designer_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in phbAddStep.
function phbAddStep_Callback(hObject, eventdata, handles)
% hObject    handle to phbAddStep (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global file1 Mode Step WaveformNumberOfPoints Time LastStep
global PeriodNumberOfPoints SampleTime NumberOfPeriods 
try
    if(handles.chkActiveStep.Value)
        if(isempty(LastStep))
            Step = 1; LastStep = 2;
        elseif(Step>LastStep)
            Step = LastStep + 1; LastStep = Step + 1;
        end
        handles.uitExperience.Data{1,Step} = file1;
        handles.uitExperience.Data{2,Step} = Mode;
        handles.uitExperience.Data{3,Step} = num2str(PeriodNumberOfPoints*SampleTime*NumberOfPeriods/1e6);
        handles.uitExperience.Data{4,Step} = num2str(WaveformNumberOfPoints);
        if(Step>1)
            handles.uitExperience.Data{1,Step-1} = 'IDLE';
            handles.uitExperience.Data{2,Step-1} = '-';
            handles.uitExperience.Data{3,Step-1} = '20';
            handles.uitExperience.Data{4,Step-1} = '-';
        end
        handles.uitExperience.Data{1,Step+1} = 'IDLE';
        handles.uitExperience.Data{2,Step+1} = '-';
        handles.uitExperience.Data{3,Step+1} = '20';
        handles.uitExperience.Data{4,Step+1} = '-';
    else
        if(Step>LastStep)
            Step = LastStep + 1; LastStep = Step;
        end
        handles.uitExperience.Data{1,Step} = 'IDLE';
        handles.uitExperience.Data{2,Step} = '-';
        handles.uitExperience.Data{3,Step} = num2str(Time);
        handles.uitExperience.Data{4,Step} = '-';
    end    
catch
end


% --- Executes on button press in phbSaveConfiguration.
function phbSaveConfiguration_Callback(hObject, eventdata, handles)
% hObject    handle to phbSaveConfiguration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edtNumberOfRepetitions_Callback(hObject, eventdata, handles)
% hObject    handle to edtNumberOfRepetitions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtNumberOfRepetitions as text
%        str2double(get(hObject,'String')) returns contents of edtNumberOfRepetitions as a double


% --- Executes during object creation, after setting all properties.
function edtNumberOfRepetitions_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtNumberOfRepetitions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in pumVI.
function pumVI_Callback(hObject, eventdata, handles)
% hObject    handle to pumVI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Mode
Mode = get(hObject,'String');
Mode = Mode{get(hObject,'Value'),1};


% --- Executes during object creation, after setting all properties.
function pumVI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pumVI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global Mode
Mode = get(hObject,'String');
Mode = Mode{get(hObject,'Value'),1};


% --- Executes on button press in phbLoadWaveform.
function phbLoadWaveform_Callback(hObject, eventdata, handles)
% hObject    handle to phbLoadWaveform (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global WAVEFORM PeriodNumberOfPoints SampleTime NumberOfPeriods WaveformLoaded
global WAVEFORM_DAC WaveformNumberOfPoints AppliedWaveform file1
try
    [file1,path] = uigetfile('*.ech', 'Pick a .ech file.');
    if(~contains(file1,'.ech'))
        errorSound(); warndlg('Selected file is not .ech.'); 
    else
        file = strcat(path,'\',file1);
        fd = fopen(file);
        if(fd==-1)
            errorSound(); warndlg('Impossible to open selected file.');
            handles.indWaveformLoaded.BackgroundColor = [0 0.3 0];
            WAVEFORM = 0; 
            PeriodNumberOfPoints = 0; 
            SampleTime = 0;
            NumberOfPeriods = 0;
            WaveformLoaded = 0;
            handles.txtLoadIndicator.String = 'ERROR. Loading pending...';
            handles.txtLoadIndicator.ForegroundColor = [1 0 0];
        else
            SampleTime = textscan(fd,'%d',1,'Delimiter','\n');
            SampleTime = SampleTime{1};
            NumberOfPeriods = textscan(fd,'%d',1,'Delimiter','\n');
            NumberOfPeriods = NumberOfPeriods{1};
            PeriodNumberOfPoints = textscan(fd,'%d',1,'Delimiter','\n');
            PeriodNumberOfPoints = PeriodNumberOfPoints{1};

            str = '';
            for i=4:(PeriodNumberOfPoints+3)
                str = strcat(str,'%d ');
            end
            WAVEFORM = textscan(fd,str,'Delimiter',',');
            WaveformLoaded = 1;
            handles.indWaveformLoaded.BackgroundColor = [0 0 1]; 
            fclose(fd);

            AppliedWaveform = repmat(WAVEFORM,NumberOfPeriods); 
            AppliedWaveform = AppliedWaveform(1,:)';
            AppliedWaveform = cell2mat(AppliedWaveform(:))';

            WaveformNumberOfPoints = length(WAVEFORM);
            WAVEFORM_DAC = (cell2mat(WAVEFORM) + 2500)/(5000/4095);
            
            handles.txtLoadIndicator.String = sprintf('Loaded %s OK',file1);
            handles.txtLoadIndicator.ForegroundColor = [0 1 0];
        end
    end
catch
    handles.txtLoadIndicator.String = 'ERROR. Loading pending...';
    handles.txtLoadIndicator.ForegroundColor = [1 0 0];
end


% --- Executes on button press in phbCreateWaveform.
function phbCreateWaveform_Callback(hObject, eventdata, handles)
% hObject    handle to phbCreateWaveform (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
warndlg('In case of current injection: mV = mA. Do not exceed absolute 20 mA.');
part02_EQ_WC;


function edtStep_Callback(hObject, eventdata, handles)
% hObject    handle to edtStep (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Step 
Step = str2double(get(hObject,'String'));
if(Step<1)
    Step = 1;
    set(hObject.String,double2str(Step));
end
if(Step>10)
    Step = 10;
    set(hObject.String,double2str(Step));
end


% --- Executes during object creation, after setting all properties.
function edtStep_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtStep (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global Step
Step = 1;


function edtTime_Callback(hObject, eventdata, handles)
% hObject    handle to edtTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Time 
Time = str2double(get(hObject,'String'));
if(Time<1e-3)
    Time = 1e-3;
    set(hObject.String,double2str(Time));
end
if(Time>1e4)
    Time = 1e4;
    set(hObject.String,double2str(Time));
end


% --- Executes during object creation, after setting all properties.
function edtTime_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtTime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global Time 
Time = 1;


% --- Executes on button press in chkActiveStep.
function chkActiveStep_Callback(hObject, eventdata, handles)
% hObject    handle to chkActiveStep (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(get(hObject,'Value'))
    handles.edtTime.Enable = 'off';
    handles.pumVI.Enable = 'on';
    handles.phbLoadWaveform.Enable = 'on';
    handles.phbCreateWaveform.Enable = 'on';
else
    handles.edtTime.Enable = 'on';
    handles.pumVI.Enable = 'off';
    handles.phbLoadWaveform.Enable = 'off';
    handles.phbCreateWaveform.Enable = 'off';
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

clear global
closeSound();
% Hint: delete(hObject) closes the figure
delete(hObject);


% --- Executes when entered data in editable cell(s) in uitExperience.
function uitExperience_CellEditCallback(hObject, eventdata, handles)
% hObject    handle to uitExperience (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
%	Indices: row and column indices of the cell(s) edited
%	PreviousData: previous data for the cell(s) edited
%	EditData: string(s) entered by the user
%	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
%	Error: error string when failed to convert EditData to appropriate value for Data
% handles    structure with handles and user data (see GUIDATA)
