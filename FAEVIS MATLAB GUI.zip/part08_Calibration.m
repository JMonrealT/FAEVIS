%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   @author Javier Monreal Trigo                     %
%   @project FAEVIS                                  %
%   @brief IDM UPV PhD. Device calibration interface.%
%   @version 04th February 2020                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function varargout = part08_Calibration(varargin)
%PART08_CALIBRATION MATLAB code file for part08_Calibration.fig
%      PART08_CALIBRATION, by itself, creates a new PART08_CALIBRATION or raises the existing
%      singleton*.
%
%      H = PART08_CALIBRATION returns the handle to a new PART08_CALIBRATION or the handle to
%      the existing singleton*.
%
%      PART08_CALIBRATION('Property','Value',...) creates a new PART08_CALIBRATION using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to part08_Calibration_OpeningFcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      PART08_CALIBRATION('CALLBACK') and PART08_CALIBRATION('CALLBACK',hObject,...) call the
%      local function named CALLBACK in PART08_CALIBRATION.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help part08_Calibration

% Last Modified by GUIDE v2.5 06-Feb-2020 20:52:04

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @part08_Calibration_OpeningFcn, ...
                   'gui_OutputFcn',  @part08_Calibration_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before part08_Calibration is made visible.
function part08_Calibration_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Choose default command line output for part08_Calibration
handles.output = hObject;
initialSound();

initialDisable(handles);

axes(handles.pltMainPlot);
xlabel(handles.pltMainPlot,'Digital value (bits)')
ylabel(handles.pltMainPlot,'Voltage (V)')
xlim(handles.pltMainPlot,[0 4095])
ylim(handles.pltMainPlot,[-2.5 2.5])
grid(handles.pltMainPlot, 'on')
pause(0)

global DACValues
DACValues = [];

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes part08_Calibration wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = part08_Calibration_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in pumAvailableCOMs.
function pumAvailableCOMs_Callback(hObject, eventdata, handles)
% hObject    handle to pumAvailableCOMs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pumAvailableCOMs contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pumAvailableCOMs

global COM openedCOM
ActivePorts = instrfind; % Read active ports
if isempty(ActivePorts)==0 % Check if there are active ports
    if ~openedCOM
        fclose(ActivePorts); % Close active ports
        delete(ActivePorts) % Erase variable
        clear ActivePorts % Destroy variable
    end
end

COMs = get(hObject,'String');
sizeCOM = size(COMs);
sizeCOM = sizeCOM(1);
if(sizeCOM == 1)
    COM = COMs;
else
    COM = string(COMs{get(hObject,'Value')});
end
clearvars COMs % Clear variable


% --- Executes during object creation, after setting all properties.
function pumAvailableCOMs_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pumAvailableCOMs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

if(~isempty(seriallist))
    set(hObject,'String',seriallist);
    COMs = get(hObject,'String');
else
    set(hObject,'String','[none]');
    COMs = [];
end
global COM openedCOM 
if(~isempty(COMs))
    if(iscell(COMs))
        COM = string(COMs{get(hObject,'Value')});
    else
        COM = COMs;
    end
end
clearvars COMs % Clear variable
openedCOM = 0;


% --- Executes on button press in phbConnectCOM.
function phbConnectCOM_Callback(hObject, eventdata, handles)
% hObject    handle to phbConnectCOM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

pumAvailableCOMs_Callback(handles.pumAvailableCOMs, eventdata, handles)

global COM PORT openedCOM

if(~openedCOM)
    % Config serial port
    if(strcmp(COM,'[none]')<=0)
        PORT=serial(COM); % Generate a serial object linked to COM              
        set(PORT,'BaudRate',115200); 
        set(PORT,'DataBits',8); 
        set(PORT,'Parity','none'); 
        set(PORT,'StopBits',1); 
        set(PORT,'FlowControl','none'); % RTS and DTS manually controlled
        set(PORT,'DataTerminalReady','off'); 
        set(PORT,'RequestToSend','on'); 
        PORT.BytesAvailableFcnCount = 20;  % Trigger of reception event when 1 byte received
        PORT.BytesAvailableFcnMode = 'byte'; % Trigger for number of bytes and not for enders
        set(PORT,'BytesAvailableFcn',{@inputHermesMessageCalibration,handles}); % Event triggers inputHermesMessage to treat it 
        fopen(PORT); % Opens port
        openedCOM = 1;
        rxState(handles,'sending');
        sendHermesMessage('areYouAlive',0,handles);
        rxState(handles,'waiting');
    else
        errorSound(); warndlg('No COM port detected or chosen.');
    end
else
    fclose(PORT); % Opens port
    delete(PORT)
    clear PORT
    openedCOM = 0;
    handles.phbConnectCOM.ForegroundColor = [0 0 0];
    handles.indSerial.BackgroundColor = [0 0.3 0];
    handles.pumAvailableCOMs.Enable = 'on';
    handles.phbScanCOMs.Enable = 'on';
end


% --- Executes on button press in phbScanCOMs.
function phbScanCOMs_Callback(hObject, eventdata, handles)
% hObject    handle to phbScanCOMs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global COM openedCOM PORT
try
    port = PORT.Port;
catch
    port = [];
end
if(isempty(port))
    if(~openedCOM)
        if(~isempty(seriallist))
            set(handles.pumAvailableCOMs,'String',seriallist);
            COMs = get(handles.pumAvailableCOMs,'String');
        else
            set(handles.pumAvailableCOMs,'String','[none]');
            COMs = [];
        end
        if(~isempty(COMs))
            if(iscell(COMs))
                COM = string(COMs{get(handles.pumAvailableCOMs,'Value')});
            else
                COM = COMs;
            end
            set(handles.pumAvailableCOMs,'Value',1);
        end
    end
else
    errorSound(); warndlg('First, click on green button CONNECT to disconnect.'); 
end



% --- Executes on button press in phbSet0256.
function phbSet0256_Callback(hObject, eventdata, handles)
% hObject    handle to phbSet0256 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rxState(handles,'sending');
sendHermesMessage('setDACValue',0256,handles);
rxState(handles,'waiting');


function edtDAC0256_Callback(hObject, eventdata, handles)
% hObject    handle to edtDAC0256 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtDAC0256 as text
%        str2double(get(hObject,'String')) returns contents of edtDAC0256 as a double


% --- Executes during object creation, after setting all properties.
function edtDAC0256_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtDAC0256 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in phbSet1792.
function phbSet1792_Callback(hObject, eventdata, handles)
% hObject    handle to phbSet1792 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rxState(handles,'sending');
sendHermesMessage('setDACValue',1792,handles);
rxState(handles,'waiting');


function edtSet1792_Callback(hObject, eventdata, handles)
% hObject    handle to edtSet1792 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtSet1792 as text
%        str2double(get(hObject,'String')) returns contents of edtSet1792 as a double
global DACValues
DACValues(4) = str2double(get(hObject,'String'));
if(DACValues(4)<-2.5)
    DACValues(4) = -2.5;
    handles.edtSet1792.String = '-2.5';
end
if(DACValues(4)>2.5)
    DACValues(4) = 2.5;
    handles.edtSet1792.String = '2.5';
end
handles.phbSet2048.Enable = 'on';
plotCalibration('DAC',handles);


% --- Executes during object creation, after setting all properties.
function edtSet1792_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtSet1792 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in phbSet2304.
function phbSet2304_Callback(hObject, eventdata, handles)
% hObject    handle to phbSet2304 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rxState(handles,'sending');
sendHermesMessage('setDACValue',2304,handles);
rxState(handles,'waiting');


function edtSet2304_Callback(hObject, eventdata, handles)
% hObject    handle to edtSet2304 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtSet2304 as text
%        str2double(get(hObject,'String')) returns contents of edtSet2304 as a double
global DACValues
DACValues(6) = str2double(get(hObject,'String'));
if(DACValues(6)<-2.5)
    DACValues(6) = -2.5;
    handles.edtSet2304.String = '-2.5';
end
if(DACValues(6)>2.5)
    DACValues(6) = 2.5;
    handles.edtSet2304.String = '2.5';
end
handles.phbSet2816.Enable = 'on';
plotCalibration('DAC',handles);


% --- Executes during object creation, after setting all properties.
function edtSet2304_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtSet2304 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in phbSet2816.
function phbSet2816_Callback(hObject, eventdata, handles)
% hObject    handle to phbSet2816 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rxState(handles,'sending');
sendHermesMessage('setDACValue',2816,handles);
rxState(handles,'waiting');


function edtSet2816_Callback(hObject, eventdata, handles)
% hObject    handle to edtSet2816 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtSet2816 as text
%        str2double(get(hObject,'String')) returns contents of edtSet2816 as a double
global DACValues
DACValues(7) = str2double(get(hObject,'String'));
if(DACValues(7)<-2.5)
    DACValues(7) = -2.5;
    handles.edtSet2816.String = '-2.5';
end
if(DACValues(7)>2.5)
    DACValues(7) = 2.5;
    handles.edtSet2816.String = '2.5';
end
handles.phbSet3328.Enable = 'on';
plotCalibration('DAC',handles);


% --- Executes during object creation, after setting all properties.
function edtSet2816_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtSet2816 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in phbSet3328.
function phbSet3328_Callback(hObject, eventdata, handles)
% hObject    handle to phbSet3328 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rxState(handles,'sending');
sendHermesMessage('setDACValue',3328,handles);
rxState(handles,'waiting');


function edtSet3328_Callback(hObject, eventdata, handles)
% hObject    handle to edtSet3328 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtSet3328 as text
%        str2double(get(hObject,'String')) returns contents of edtSet3328 as a double
global DACValues
DACValues(8) = str2double(get(hObject,'String'));
if(DACValues(8)<-2.5)
    DACValues(8) = -2.5;
    handles.edtSet3328.String = '-2.5';
end
if(DACValues(8)>2.5)
    DACValues(8) = 2.5;
    handles.edtSet3328.String = '2.5';
end
handles.phbSet3840.Enable = 'on';
plotCalibration('DAC',handles);


% --- Executes during object creation, after setting all properties.
function edtSet3328_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtSet3328 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in phbSet3840.
function phbSet3840_Callback(hObject, eventdata, handles)
% hObject    handle to phbSet3840 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rxState(handles,'sending');
sendHermesMessage('setDACValue',3840,handles);
rxState(handles,'waiting');


function edtSet3840_Callback(hObject, eventdata, handles)
% hObject    handle to edtSet3840 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtSet3840 as text
%        str2double(get(hObject,'String')) returns contents of edtSet3840 as a double
global DACValues
DACValues(9) = str2double(get(hObject,'String'));
if(DACValues(9)<-2.5)
    DACValues(9) = -2.5;
    handles.edtSet3840.String = '-2.5';
end
if(DACValues(9)>2.5)
    DACValues(9) = 2.5;
    handles.edtSet3840.String = '2.5';
end
handles.phbSaveDACCalibration.Enable = 'on';
plotCalibration('DAC',handles);


% --- Executes during object creation, after setting all properties.
function edtSet3840_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtSet3840 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in phbSet1280.
function phbSet1280_Callback(hObject, eventdata, handles)
% hObject    handle to phbSet1280 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rxState(handles,'sending');
sendHermesMessage('setDACValue',1280,handles);
rxState(handles,'waiting');


function edtSet1280_Callback(hObject, eventdata, handles)
% hObject    handle to edtSet1280 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtSet1280 as text
%        str2double(get(hObject,'String')) returns contents of edtSet1280 as a double
global DACValues
DACValues(3) = str2double(get(hObject,'String'));
if(DACValues(3)<-2.5)
    DACValues(3) = -2.5;
    handles.edtSet1280.String = '-2.5';
end
if(DACValues(3)>2.5)
    DACValues(3) = 2.5;
    handles.edtSet1280.String = '2.5';
end
handles.phbSet1792.Enable = 'on';
plotCalibration('DAC',handles);


% --- Executes during object creation, after setting all properties.
function edtSet1280_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtSet1280 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in phbSet0768.
function phbSet0768_Callback(hObject, eventdata, handles)
% hObject    handle to phbSet0768 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rxState(handles,'sending');
sendHermesMessage('setDACValue',0768,handles);
rxState(handles,'waiting');


function edtSet0768_Callback(hObject, eventdata, handles)
% hObject    handle to edtSet0768 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtSet0768 as text
%        str2double(get(hObject,'String')) returns contents of edtSet0768 as a double
global DACValues
DACValues(2) = str2double(get(hObject,'String'));
if(DACValues(2)<-2.5)
    DACValues(2) = -2.5;
    handles.edtSet0768.String = '-2.5';
end
if(DACValues(2)>2.5)
    DACValues(2) = 2.5;
    handles.edtSet0768.String = '2.5';
end
handles.phbSet1280.Enable = 'on';
plotCalibration('DAC',handles);


% --- Executes during object creation, after setting all properties.
function edtSet0768_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtSet0768 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in phbSet0000.
function phbSet0000_Callback(hObject, eventdata, handles)
% hObject    handle to phbSet0000 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rxState(handles,'sending');
sendHermesMessage('setDACValue',0000,handles);
rxState(handles,'waiting');


function edtSet0000_Callback(hObject, eventdata, handles)
% hObject    handle to edtSet0000 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtSet0000 as text
%        str2double(get(hObject,'String')) returns contents of edtSet0000 as a double

global DACValues
DACValues(1) = str2double(get(hObject,'String'));
if(DACValues(1)<-2.5)
    DACValues(1) = -2.5;
    handles.edtSet0000.String = '-2.5';
end
if(DACValues(1)>2.5)
    DACValues(1) = 2.5;
    handles.edtSet0000.String = '2.5';
end
handles.phbSet0256.Enable = 'on';
plotCalibration('DAC',handles);


% --- Executes during object creation, after setting all properties.
function edtSet0000_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtSet0000 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in phbSet4095.
function phbSet4095_Callback(hObject, eventdata, handles)
% hObject    handle to phbSet4095 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rxState(handles,'sending');
sendHermesMessage('setDACValue',3900,handles);
rxState(handles,'waiting');


function edtSet4095_Callback(hObject, eventdata, handles)
% hObject    handle to edtSet4095 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtSet4095 as text
%        str2double(get(hObject,'String')) returns contents of edtSet4095 as a double
global DACValues
DACValues(11) = str2double(get(hObject,'String'));
if(DACValues(11)<-2.5)
    DACValues(11) = -2.5;
    handles.edtSet4095.String = '-2.5';
end
if(DACValues(11)>2.5)
    DACValues(11) = 2.5;
    handles.edtSet4095.String = '2.5';
end
handles.phbSaveDACCalibration.Enable = 'on';
plotCalibration('DAC',handles);


% --- Executes during object creation, after setting all properties.
function edtSet4095_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtSet4095 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in phbSet2048.
function phbSet2048_Callback(hObject, eventdata, handles)
% hObject    handle to phbSet2048 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rxState(handles,'sending');
sendHermesMessage('setDACValue',2048,handles);
rxState(handles,'waiting');


function edtSet2048_Callback(hObject, eventdata, handles)
% hObject    handle to edtSet2048 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtSet2048 as text
%        str2double(get(hObject,'String')) returns contents of edtSet2048 as a double
global DACValues
DACValues(5) = str2double(get(hObject,'String'));
if(DACValues(5)<-2.5)
    DACValues(5) = -2.5;
    handles.edtSet2048.String = '-2.5';
end
if(DACValues(5)>2.5)
    DACValues(5) = 2.5;
    handles.edtSet2048.String = '2.5';
end
handles.phbSet2304.Enable = 'on';
plotCalibration('DAC',handles);


% --- Executes during object creation, after setting all properties.
function edtSet2048_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtSet2048 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in phbSaveDACCalibration.
function phbSaveDACCalibration_Callback(hObject, eventdata, handles)
% hObject    handle to phbSaveDACCalibration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global DACValues
[file,path,flag] = uiputfile('*.dcf', 'Set direction to save DAC Calibration.');
if(flag == 1)
    file = strcat(path,'\',file);
    fd = fopen(file,'w+');
    if(fd==-1)
        errorSound(); warndlg('Impossible to open selected file.'); 
    else
        for i = 1:9
            fprintf(fd,'%f\r\n',DACValues(i));
        end
        fprintf(fd,'EOF %s.',datestr(clock));
        fclose(fd);
        handles.indSaveDAC.BackgroundColor = [0 1 0];
    end
end


% --- Executes on button press in phbApplyDACCalibration.
function phbApplyDACCalibration_Callback(hObject, eventdata, handles)
% hObject    handle to phbApplyDACCalibration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global DACValues
try
    [file,path] = uigetfile('*.dcf', 'Pick a DAC calibration file (.dcf).');
    if(~contains(file,'.dcf'))
        errorSound(); warndlg('Selected file is not .dcf.'); 
    else
        file = strcat(path,'\',file);
        fd = fopen(file);
        if(fd==-1)
            errorSound(); warndlg('Impossible to open selected file.');
            handles.indAppliedDAC.BackgroundColor = [0 0.3 0];
        else
            str = '';
            for i=1:9
                str = strcat(str,'%f');
            end
            DACValues_str = textscan(fd,str,'Delimiter','\n');
            DACValues = cell2mat(DACValues_str);
            fclose(fd);
            handles.indAppliedDAC.BackgroundColor = [0 1 0];
            plotCalibration('DAC',handles);
            handles.rdbOtherCalibration.Enable = 'on';
        end
    end
catch
end

% --- Executes on button press in phbHelp.
function phbHelp_Callback(hObject, eventdata, handles)
% hObject    handle to phbHelp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
title = 'A few instructions to guide you in the use of this app.';
line1 = 'First, select the correct COM port and connect to FAEVIS.';
line2 = 'Then, set a calibration for the DAC subsystem. You may load a .dcf with the "Apply DAC calibration" button or set each of the voltage values measured with a multimeter between RE (w/ CE connected) and WE electrodes. The later is the only option if it is your first time.';
line3 = 'After that, other calibrations are posible. Check "Other calibrations" radiobutton and open the pop-up menu.';
msg = {line1;' ';line2;' ';line3};
f = warndlg(msg,title);


% --- Executes on selection change in pumOtherCalibrations.
function pumOtherCalibrations_Callback(hObject, eventdata, handles)
% hObject    handle to pumOtherCalibrations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pumOtherCalibrations contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pumOtherCalibrations


% --- Executes during object creation, after setting all properties.
function pumOtherCalibrations_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pumOtherCalibrations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edtSet0256_Callback(hObject, eventdata, handles)
% hObject    handle to edtSet0256 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtSet0256 as text
%        str2double(get(hObject,'String')) returns contents of edtSet0256 as a double
global DACValues
DACValues(1) = str2double(get(hObject,'String'));
if(DACValues(1)<-2.5)
    DACValues(1) = -2.5;
    handles.edtSet0256.String = '-2.5';
end
if(DACValues(1)>2.5)
    DACValues(1) = 2.5;
    handles.edtSet0256.String = '2.5';
end
handles.phbSet0768.Enable = 'on';
plotCalibration('DAC',handles);


% --- Executes during object creation, after setting all properties.
function edtSet0256_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtSet0256 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global PORT openedCOM

if(openedCOM == 1)
    fclose(PORT);
    delete(PORT)
    clear PORT
    openedCOM = 0;
end

% Hint: delete(hObject) closes the figure
closeSound();
delete(hObject);
clc
clear


% --- Executes during object creation, after setting all properties.
function pltMainPlot_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pltMainPlot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate pltMainPlot


% --- Executes on button press in rdbOtherCalibration.
function rdbOtherCalibration_Callback(hObject, eventdata, handles)
% hObject    handle to rdbOtherCalibration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rdbOtherCalibration
global lastPlot
if(isempty(lastPlot))
    lastPlot = 'DAC';
end
if(get(hObject,'Value'))
    handles.uipDAC.Visible = 'off';
    handles.uipOtherCalibs.Visible = 'on';
    handles.indSavePotAutocalib.Visible = 'on';
    handles.indSaveCECMLargeScale.Visible = 'on';
    handles.indSaveCECMPrecisionScale.Visible = 'on';
    handles.indSaveCIAutocalib.Visible = 'on';
end
plotCalibration(lastPlot,handles);

% --- Executes on button press in rdbDAC.
function rdbDAC_Callback(hObject, eventdata, handles)
% hObject    handle to rdbDAC (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rdbDAC
if(get(hObject,'Value'))
    handles.uipDAC.Visible = 'on';
    handles.uipOtherCalibs.Visible = 'off';
    handles.indSavePotAutocalib.Visible = 'off';
    handles.indSaveCECMLargeScale.Visible = 'off';
    handles.indSaveCECMPrecisionScale.Visible = 'off';
    handles.indSaveCIAutocalib.Visible = 'off';
end
plotCalibration('DAC', handles);


% --- Executes on button press in phbPotentiometryAutocalibration.
function phbPotentiometryAutocalibration_Callback(hObject, eventdata, handles)
% hObject    handle to phbPotentiometryAutocalibration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rxState(handles,'sending');
sendHermesMessage('potentiometryAutocalibration',0,handles);
rxState(handles,'waiting');
handles.rdbCE.Enable = 'off';
handles.rdbCM.Enable = 'off';


% --- Executes on button press in phbSavePotAutocalib.
function phbSavePotAutocalib_Callback(hObject, eventdata, handles)
% hObject    handle to phbSavePotAutocalib (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global PotentiometryCalibrationValues
[file,path,flag] = uiputfile('*.pcf', 'Set direction to save WE ADC Calibration.');
if(flag == 1)
    file = strcat(path,'\',file);
    fd = fopen(file,'w+');
    if(fd==-1)
        errorSound(); warndlg('Impossible to open selected file.'); 
    else
        for i = 1:9
            fprintf(fd,'%d\r\n',PotentiometryCalibrationValues(i));
        end
        fprintf(fd,'EOF %s.',datestr(clock));
        fclose(fd);
        handles.indSavePotAutocalib.BackgroundColor = [0 1 0];
    end
end


% --- Executes on button press in phbCECMLargeScale.
function phbCECMLargeScale_Callback(hObject, eventdata, handles)
% hObject    handle to phbCECMLargeScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global CECM_ptr 
CECM_ptr = 1;
rxState(handles,'sending');
sendHermesMessage('CECMAutocalibrationLargeScale',0,handles);
rxState(handles,'waiting');
handles.rdbCE.Enable = 'on';
handles.rdbCM.Enable = 'on';



% --- Executes on button press in phbSaveCECMLargeScale.
function phbSaveCECMLargeScale_Callback(hObject, eventdata, handles)
% hObject    handle to phbSaveCECMLargeScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global CECalibrationValues CMLargeCalibrationValues RWEREL RCEREL
[file,path,flag] = uiputfile('*.lscf', 'Set direction to save CE and large scale CM ADCs Calibration.');
if(flag == 1)
    file = strcat(path,'\',file);
    fd = fopen(file,'w+');
    if(fd==-1)
        errorSound(); warndlg('Impossible to open selected file.'); 
    else
        fprintf(fd,'RWERE(kohm): %f\n',RWEREL);
        fprintf(fd,'RCERE(kohm): %f\n',RCEREL);
        fprintf(fd,'CE:\n');
        for i = 1:9
            fprintf(fd,'%d\r\n',CECalibrationValues(i));
        end
        fprintf(fd,'CM Large:\n');
        for i = 1:9
            fprintf(fd,'%d\r\n',CMLargeCalibrationValues(i));
        end
        fprintf(fd,'EOF %s.',datestr(clock));
        fclose(fd);
        handles.indSaveCECMLargeScale.BackgroundColor = [0 1 0];
    end
end


function edtRWERELargeScale_Callback(hObject, eventdata, handles)
% hObject    handle to edtRWERELargeScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtRWERELargeScale as text
%        str2double(get(hObject,'String')) returns contents of edtRWERELargeScale as a double
global RWEREL
RWEREL = str2double(get(hObject,'String'));


% --- Executes during object creation, after setting all properties.
function edtRWERELargeScale_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtRWERELargeScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global RWEREL
RWEREL = str2double(get(hObject,'String'));


function edtRCERELargeScale_Callback(hObject, eventdata, handles)
% hObject    handle to edtRCERELargeScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtRCERELargeScale as text
%        str2double(get(hObject,'String')) returns contents of edtRCERELargeScale as a double
global RCEREL
RCEREL = str2double(get(hObject,'String'));


% --- Executes during object creation, after setting all properties.
function edtRCERELargeScale_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtRCERELargeScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global RCEREL
RCEREL = str2double(get(hObject,'String'));


function edtRg_Callback(hObject, eventdata, handles)
% hObject    handle to edtRg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtRg as text
%        str2double(get(hObject,'String')) returns contents of edtRg as a double


% --- Executes during object creation, after setting all properties.
function edtRg_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtRg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in phbVGAutocalibration.
function phbVGAutocalibration_Callback(hObject, eventdata, handles)
% hObject    handle to phbVGAutocalibration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in phbSaveVGAutocalib.
function phbSaveVGAutocalib_Callback(hObject, eventdata, handles)
% hObject    handle to phbSaveVGAutocalib (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in phbCIAutocalibration.
function phbCIAutocalibration_Callback(hObject, eventdata, handles)
% hObject    handle to phbCIAutocalibration (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.rdbCE.Enable = 'off';
handles.rdbCM.Enable = 'off';


% --- Executes on button press in phbSaveCIAutocalib.
function phbSaveCIAutocalib_Callback(hObject, eventdata, handles)
% hObject    handle to phbSaveCIAutocalib (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in phbCECMPrecisionScale.
function phbCECMPrecisionScale_Callback(hObject, eventdata, handles)
% hObject    handle to phbCECMPrecisionScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global CECM_ptr 
CECM_ptr = 1;
rxState(handles,'sending');
sendHermesMessage('CECMAutocalibrationPrecisionScale',0,handles);
rxState(handles,'waiting');
handles.rdbCE.Enable = 'off';
handles.rdbCM.Enable = 'off';


% --- Executes on button press in phbSaveCECMPrecisionScale.
function phbSaveCECMPrecisionScale_Callback(hObject, eventdata, handles)
% hObject    handle to phbSaveCECMPrecisionScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global CMPrecisionCalibrationValues RWEREP RCEREP
[file,path,flag] = uiputfile('*.pscf', 'Set direction to save precision scale CM ADCs Calibration.');
if(flag == 1)
    file = strcat(path,'\',file);
    fd = fopen(file,'w+');
    if(fd==-1)
        errorSound(); warndlg('Impossible to open selected file.'); 
    else
        fprintf(fd,'RWERE(kohm): %f\n',RWEREP);
        fprintf(fd,'RCERE(kohm): %f\n',RCEREP);
        fprintf(fd,'CM Precision:\n');
        for i = 1:9
            fprintf(fd,'%d\r\n',CMPrecisionCalibrationValues(i));
        end
        fprintf(fd,'EOF %s.',datestr(clock));
        fclose(fd);
        handles.indSaveCECMPrecisionScale.BackgroundColor = [0 1 0];
    end
end



function edtRWEREPrecisionScale_Callback(hObject, eventdata, handles)
% hObject    handle to edtRWEREPrecisionScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtRWEREPrecisionScale as text
%        str2double(get(hObject,'String')) returns contents of edtRWEREPrecisionScale as a double
global RWEREP
RWEREP = str2double(get(hObject,'String'));


% --- Executes during object creation, after setting all properties.
function edtRWEREPrecisionScale_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtRWEREPrecisionScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global RWEREP
RWEREP = str2double(get(hObject,'String'));


function edtRCEREPrecisionScale_Callback(hObject, eventdata, handles)
% hObject    handle to edtRCEREPrecisionScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtRCEREPrecisionScale as text
%        str2double(get(hObject,'String')) returns contents of edtRCEREPrecisionScale as a double
global RCEREP
RCEREP = str2double(get(hObject,'String'));


% --- Executes during object creation, after setting all properties.
function edtRCEREPrecisionScale_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtRCEREPrecisionScale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global RCEREP
RCEREP = str2double(get(hObject,'String'));


% --- Executes on button press in rdbCE.
function rdbCE_Callback(hObject, eventdata, handles)
% hObject    handle to rdbCE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rdbCE
plotCalibration('CE',handles);


% --- Executes on button press in rdbCM.
function rdbCM_Callback(hObject, eventdata, handles)
% hObject    handle to rdbCM (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rdbCM
plotCalibration('CMLarge',handles);


% --- Executes on button press in phbMergeCalibrations.
function phbMergeCalibrations_Callback(hObject, eventdata, handles)
% hObject    handle to phbMergeCalibrations (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
mergeCalibrationFiles;
